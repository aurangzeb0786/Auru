-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 02, 2020 at 01:13 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `english`
--

-- --------------------------------------------------------

--
-- Table structure for table `assistment`
--

CREATE TABLE `assistment` (
  `id` int(100) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `fname` varchar(255) DEFAULT NULL,
  `rcountry` varchar(255) DEFAULT NULL,
  `dcountry` varchar(255) DEFAULT NULL,
  `Isdcode` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `age` varchar(255) DEFAULT NULL,
  `hqualification` varchar(255) DEFAULT NULL,
  `experience` varchar(255) DEFAULT NULL,
  `pimmigrate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(100) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `heading` varchar(255) DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `blogcat`
--

CREATE TABLE `blogcat` (
  `id` int(100) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alt` varchar(255) DEFAULT NULL,
  `pmenu` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `contactenquary`
--

CREATE TABLE `contactenquary` (
  `id` int(100) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `message` longtext DEFAULT NULL,
  `course` varchar(255) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `sdate` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `contact_details`
--

CREATE TABLE `contact_details` (
  `id` int(100) NOT NULL,
  `addresshead` varchar(500) DEFAULT NULL,
  `address` longtext DEFAULT NULL,
  `map` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact_details`
--

INSERT INTO `contact_details` (`id`, `addresshead`, `address`, `map`) VALUES
(25, 'Head Office', '607, 6th Floor, Madhuban Building 55, Nehru Place, New Delhi- 110019,', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3504.6926440068123!2d77.25049331504903!3d28.548956694609426!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce3ec2df8a015%3A0xfe350c52c51a899a!2sRoman%20Networks%20Pvt.%20Ltd.%20-%20Laptop%2C%20Desktop%20are%20Available%20On%20Rent%20in%20Delhi%20NCR!5e0!3m2!1sen!2sin!4v1580881755178!5m2!1sen!2sin\" width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"\"></iframe>');

-- --------------------------------------------------------

--
-- Table structure for table `countrydemo`
--

CREATE TABLE `countrydemo` (
  `id` int(100) NOT NULL,
  `flag` varchar(500) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `bimage` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `heading` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alt` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `shomepage` varchar(255) DEFAULT NULL,
  `pmenu` varchar(255) DEFAULT NULL,
  `page_type` varchar(255) NOT NULL DEFAULT 'country',
  `spcountry` varchar(255) DEFAULT NULL,
  `scpnp` varchar(255) DEFAULT NULL,
  `orderby` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `countrydemo`
--

INSERT INTO `countrydemo` (`id`, `flag`, `image`, `bimage`, `name`, `heading`, `url`, `description`, `status`, `alt`, `location`, `shomepage`, `pmenu`, `page_type`, `spcountry`, `scpnp`, `orderby`) VALUES
(1, NULL, NULL, NULL, 'None', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'country', NULL, NULL, NULL),
(5, 'australia.png', 'aus.png', 'about.jpg', 'Australia Immigration', 'Australian Immigration', 'australian-immigration', '<p>&nbsp;Australia is known as a country with plenty of tourist destinations but is also widely known as a country with strict immigration regulations. One can obtain Visa to Australia only if it\'s permitted by law. With the help of the&nbsp;<strong>Australia Immigration</strong>&nbsp;as well as the visa services from the Visa Mount, you can easily manage these all sorts of lives you\'re hardly looking for and succeed in making your dreams a reality and live with your life expectancies in Australia.</p>\r\n<p>Australia offers a host of opportunities, particularly for working professionals. It attracts several immigrants from different parts of the world each year. Many Indians also apply for <strong>Australian Immigration</strong> and quite a few of them get through successfully. We at Visa Mount, are glad to help many among them embark on a journey to enjoy excellent job prospects and a great lifestyle in one of the best countries across the globe.</p>\r\n<p>If an applicant is the citizen of India, then in the Skilled Migration Point Test, the candidate should score quite well. The candidate should include all the documentation needed to apply for a PR Visa process. The following are a few required documents:</p>\r\n<ul>\r\n<li>Your educational certificates and other documents</li>\r\n<li>Your work experience letters</li>\r\n<li>Sufficient proficiency in the language</li>\r\n<li>The traveling documents</li>\r\n</ul>\r\n<p>When selecting the Visa from multiple Visas for&nbsp;<strong>immigration to Australia</strong>, it is advised that you choose the category as per your credentials. You could take consultancy support in this process.</p>\r\n<h2><strong>The categories of Skilled Immigration in Australia are mentioned below</strong></h2>\r\n<ul>\r\n<li>&nbsp; &nbsp; &nbsp;<strong>Skilled Regional Visa Subclass 489</strong></li>\r\n</ul>\r\n<p>The visa category allows you to live and work in Australia to obtain permanent residency in a particular region. The applicant must be nominated from the area in question, the state in which he has to work for one year and must stay in that region for a minimum of 2 years to obtain permanent residency.</p>\r\n<ul>\r\n<li>&nbsp; &nbsp; &nbsp;<strong>The Visa Subclass Nominated by the State 190</strong></li>\r\n</ul>\r\n<p>This visa category requires the nomination of the state or the government territory in Australia, having skills that are highly desirable in the Australian state or the region. You are required to score an additional five nomination points. The profile of the applicant must correspond to a list of STSOLs.</p>\r\n<ul>\r\n<li>&nbsp; &nbsp; &nbsp;<strong>The Independent Skilled Visa &ndash; Subclass 189</strong></li>\r\n</ul>\r\n<p>In this visa category, the applicants who are highly skilled and qualified those are in demand by a state or the territory of Australia could go for the subclass visas. The skilled Independent Visa doesn\'t require any sponsorship by the family or the state. One can also apply for a visa by submitting the EOI directly.</p>\r\n<p>In order to get permanent residency in Australia, you first need to identify as to which category you fall under. You may then collate the required documents and start with the visa application procedure.</p>\r\n<h3><strong>The process to apply for Australia immigration is given below:</strong></h3>\r\n<ul>\r\n<li>The applicant must have an excellent score in the IELTS examination.</li>\r\n<li>The minimum requirement for the IELTS score is 60 points if you score more than your chances of getting an invitation increases.</li>\r\n<li>Your work experience should match appropriately in the occupation list of STSOL.</li>\r\n<li>When you apply for any regional visa or the state visa, you get the nomination for that particular state.</li>\r\n<li>You need to submit the EOI.</li>\r\n<li>Once you get the invitation, one can go to the last step for the proper submission of documents.</li>\r\n<li>One must apply for the PR visa to Australia in 60 days once you receive the invitation.</li>\r\n</ul>\r\n<p>It\'s the process for applying for the Skilled&nbsp;<strong>South Australia Immigration</strong>; there have been categories of Visa for various purposes such as Australia Investor Visa for the business holder or the new business establishment in Australia, Australia Tourist Visa, Family Visa to Australia for immigration to the entire family, as a temporary visa.</p>\r\n<h3><strong>Before Consultants, always consider the following:</strong></h3>\r\n<ol>\r\n<li><strong>Your English language skills-&nbsp;</strong>If you do not possess proper English speaking skills, you\'ll be feeling inadequate for years in other countries. This would, in turn, affect your job, your family, your relationship with your kids.</li>\r\n<li><strong>If you do not have any friends or family in Australia, you might feel isolated-&nbsp;</strong>Even the towns within Australia are so vast where you generally need to drive. The older you are, the less likely to develop close friendships. You may feel incredibly lonely when you migrate alone, particularly during your holidays, your birthdays, or on special occasions, etc.</li>\r\n<li><strong>Are you employed in Australia?</strong>&nbsp;Firstly, you need to research the job market in Australia. See to that if you hit the ground running with skills you hold or you are required to get the degrees or diplomas recognized via further education and training.&nbsp;</li>\r\n</ol>\r\n<h3><strong>Easiest Ways of Migrating to Australia</strong></h3>\r\n<p><strong>Immigration to Australia</strong>&nbsp;will take several forms. The easiest way to move is through:</p>\r\n<ul>\r\n<li><strong>Skilled Immigration to Australia-&nbsp;</strong>IT Experts, Doctors, Engineers, etc. are primary professionals in&nbsp;<strong>Australia immigration</strong>. People can relocate with either a job offer or without the offer. For those willing to travel Australia without the job offer, you are required to go for the skill-select program. You should satisfy the Country\'s requirements or eligibility.</li>\r\n<li><strong>The Study Visa-&nbsp;</strong>If you have plans to study in Australia and have selected the study abroad scheme, then there are possibilities for you to get employment in Australia. You are offered a job based on your talent and skills.</li>\r\n<li><strong>Via Travel Visa-&nbsp;</strong>If you have plans to visit Australia through a travel visa, then you can attend the interviews. Once you get selected, you can then consider your&nbsp;<strong>immigration Australia&nbsp;</strong>based on the&nbsp;<strong>Australia immigration news</strong>.&nbsp;</li>\r\n<li><strong>Via Business Immigration-&nbsp;</strong>If you are planning to start some new business, then you can invest and raise the revenue of Australia, then the chances to get the PR is high.</li>\r\n<li><strong>Visa Family Migration-&nbsp;</strong>It can also be done utilizing a skill selection program, and even if one of your family members has the work visa role.</li>\r\n</ul>\r\n<h3><strong>The Benefits of Immigration to Australia</strong></h3>\r\n<ul>\r\n<li>You can stay as well as work in Australia without restrictions</li>\r\n<li>Complete mobility for traveling to and fro Australia for five years</li>\r\n<li>You get the freedom of working anywhere across Australia</li>\r\n<li>Pursue your higher studies at the subsidized rates</li>\r\n<li>You can also sponsor your relatives for the Permanent Residency in Australia</li>\r\n<li>The children of the residents having Permanent Residency who are born in Australia are the deemed citizens of Australia by birth.</li>\r\n<li>You have the health care privilege</li>\r\n</ul>\r\n<h3><strong>The Process Time</strong></h3>\r\n<p>The phase time depends on points a candidate will receive depending on the qualifying factors such as age, employment, job, language skills. It also relies on respective reviewing officials where they request additional documents during the review of the application. To get a Permanent Residency, one can take around six months to 1 year for completing the application process.</p>\r\n<p><strong>Get Australian Visa Easily and Quickly</strong></p>\r\n<div>\r\n<p>Though the Australian immigration procedure and visa documentation requirement are clearly mentioned online however you must refrain from filing the application on your own. It is best to assign the task to a professional and trustworthy immigration consultancy such as Visa Mount.</p>\r\n<p>We have years of experience in filing visa applications for Australia. We follow a step by step approach to file the visa applications. This includes identifying the right visa category for our clients, providing them complete information about the required documents, ensuring a smooth submission process and more.</p>\r\n<p align=\"center\">Visa Mount has helped several of its clients acquire an Australian visa. You could be next!</p>\r\n</div>', '1', '', NULL, 'Yes', '1', 'country', '1', '0', 2),
(6, 'canada.png', 'cana.png', 'Canada-Immigration.png', 'Canada', 'Canada Immigration', 'canada', '<p>Each year, lots of people look for&nbsp;<strong>Canada immigration&nbsp;</strong>from different parts of the world. Culturally diverse Canada represents the best migrant destinations in the world. The cosmopolitan cities, a strong economy, and a high standard of living render it to be the best country to live in. Canada also has an enormous demand for the migrants and has opened its doors to highly skilled people and talents for giving it the global edge. If you are someone looking for&nbsp;<strong>Canada immigration&nbsp;</strong>below are some details one should look for:</p>\r\n<h2><strong>Why is Canada Immigration the right option?</strong></h2>\r\n<p><strong>Immigration to Canada from India&nbsp;</strong>is exciting and also a life-changing decision for those having high aims for themselves and their families. Along with inviting people who are looking to move abroad, the country even attracts the tourists for good quality of life, a relaxed lifestyle and great weather.&nbsp;</p>\r\n<p>Are you wondering why&nbsp;<strong>Canada immigration?&nbsp;</strong>Then the answer is quite simple. Canada has a comprehensive set of various immigration policies. Irrespective of you being an entrepreneur, visitor, student, or a skilled worker, Canada has the migration program and the visa stream in one place for addressing all your needs.&nbsp;&nbsp;</p>\r\n<p>Canada is one of the top five countries throughout the world to live, depending on different factors. Here are a few reasons why people prefer relocation to Canada from India:</p>\r\n<ul>\r\n<li>A vibrant and widespread Indian community in Canada is one of the most important reasons why most of the Indians prefer&nbsp;<strong>immigration to Canada from India.</strong>&nbsp;Canada being a multicultural country, is rich in prosperity, traditions, and culture.</li>\r\n<li>Canada is also well known for its immigration policies that are quite lenient. Once you get your PR visa in Canada, you can live, study as well as work in Canada.</li>\r\n<li>The crime rate in Canada is quite less compared to those in other countries. Canada is a peaceful and safest place to live in when you compare it with other advanced countries.</li>\r\n<li>As per the&nbsp;<strong>Canada immigration news,&nbsp;</strong>it is found that Canada ranks to be the best country in the world, depending on the quality of your life.</li>\r\n<li>Canada also ranks amongst the top five countries in the World, depending on education and citizenship for women and raising the children.<a title=\"Round World Immigration\" href=\"https://www.roundworldimmigration.com\"><br /></a></li>\r\n</ul>\r\n<h4><strong>Several programs allow one to apply to migrate to Canada. Including:</strong></h4>\r\n<ol>\r\n<li>Immigration to Canada as an Investor</li>\r\n<li>Immigration to Canada for your family</li>\r\n<li>Migrating to Canada as an Entrepreneur or the self-employed person</li>\r\n<li>Migrating to Canada via any Provincial Nominee programs</li>\r\n<li>Immigration to Canada via workers program called Quebec</li>\r\n<li>Immigration to Canada via any Express Entry programs</li>\r\n</ol>\r\n<p>The program list is vibrant and, therefore, can change rapidly. Each of these programs comes with a set of application criteria and is intended for applicants of different kinds.</p>\r\n<h3><strong>Canada Immigration Eligibility</strong></h3>\r\n<p>Although each program seems to have different standards to relocate to Canada, there are some common interests. Canadian immigration authorities typically assess requests for migration depending on:</p>\r\n<ul>\r\n<li>The employment documentation of Canada</li>\r\n<li>Legal documentation and references</li>\r\n<li>The French language skills if you are migrating to the Quebec</li>\r\n<li>The IELTS score</li>\r\n<li>Your professional profile</li>\r\n<li>Your educational profile</li>\r\n</ul>\r\n<p>It is not the exhaustive list, as well as being subject to modification. You can communicate with the&nbsp;<strong>Canada immigration consultants</strong>&nbsp;and increase the chances of moving to Canada.</p>\r\n<h3><strong>Advantages of Immigrating to Canada from India</strong></h3>\r\n<p>Canada is indeed an advanced nation, far ahead from India at a possible expense in the quality of your life, the employment rate, infrastructure, fellow citizen&rsquo;s social security advantages, etc. While India is currently the fastest-growing economies across the world, it would still start taking a few more years to have it on a par with Canada.</p>\r\n<p><strong>A substantial Indian population has limited resources for both talented and skilled youths.</strong> That is the main reason why skilled workers consider countries such as Canada as the main destination for permanent living and working.&nbsp;</p>\r\n<p>Because of the enormous Indo-Canadian population residing in Canada, it shares a unique link with Indian and India. Indians find the level of comfort in living in a country in which they can contact and communicate with the individuals within their community. Therefore, always at the top of the list of Indians looking to move outside the country.</p>\r\n<h3><strong>Canada Immigration Process</strong></h3>\r\n<p>Canada Immigration offers a beautiful experience for many of the world\'s Indians and people. It is officially bilingual, and the most multicultural and ethnically diverse country in the world. Canada celebrates each and every immigrant as a precious gem for their country; Canadians offer a familiar appreciation for both the roles immigrants play in creating a better place to live in Canada.</p>\r\n<ol>\r\n<li><strong>The Canadian Student Visa-&nbsp;</strong>Canada\'s education system is filled with services of world-class quality. It has the highest of most colleges and systems with competitive tuition. Being a safe and beautiful place to live, Canada has become a new student terminal. And being a student visa, one will take advantage of the opportunity to work for a few fixed hours in a week at the same time. And in Canada, one can be trans-formational to permanent residence.</li>\r\n<li><strong>The Start-up Visa-&nbsp;</strong>For any experienced business person or an investor, the start-up visa is the business program that is designed by the Canadian Government to enable the migrated entrepreneurs to set up their business in Canada with the help of well experienced corporate sector organizations with their start-up expertise.</li>\r\n<li><strong>The Canadian Student Visa-&nbsp;</strong>Canada\'s education system is filled with the facilities of world-class nature. It also has the highest of most colleges and systems with competitive tuition. Staying in a secure and beautiful place has repeatedly proven a new terminal for the students. While being at a student visa, people can seize the opportunity of working for a few fixed hours within a week at the same time. And in Canada, one can be trans-formational to permanent residence.</li>\r\n</ol>\r\n<h3><strong>The Canada Immigration Process</strong></h3>\r\n<p>The minimum points for underlying FSWP eligibility are 67 out of 100. Those who rank under 67 won\'t qualify. It should be noted here that the necessary score for eligibility criteria and the CRS (Comprehensive Ranking System) score are different.&nbsp;In the Express Entry Program, all qualified candidates should set up a profile. For this reason, the ECA and IELTS score is compulsory. Afterward, the profile is provided ranking out of 1200 for various factors. It includes age, education, proficiency in a language, work experience, and so on.</p>\r\n<p>CIC maintains regular drawings from the Express Entry pool and sets minimum CRS score for picture. An ITA shall be given to all qualified candidates in the pool with scores above the minimum score stated by the CRS. They can apply for a PR Visa in Canada. The minimum score for CRS has remained at 450 and above in 2019 so far.</p>\r\n<p>Since&nbsp;<strong>Canada immigration</strong>&nbsp;is a point-based system, the experts at Round World Immigration would calculate the points, assist you with all your documentation, and also guide how and when to score more. We even guide the person about how to begin your life in Canada, in solving all your queries and planning your career.</p>', '1', 'canada', NULL, 'Yes', '1', 'country', '1', '0', 1),
(7, 'canada.png', '5df650ff250000516ad30384.jpg', '5df650ff250000516ad30384.jpg', 'Canada Family Visa', 'Canada Family Visa', 'canada-family-visa', '<h1><strong>Canada Family Visa</strong></h1>\r\n<p>Canada knows the importance of a family and is also committed to the reunification of the family, and thus allows its people and the permanent residents to get together with their families via&nbsp;<strong>Canada Family Visa</strong>.</p>\r\n<h2><strong>What is a Canadian family Visa?</strong></h2>\r\n<p>The family visa for Canada is another way of sponsoring your family for migrating to Canada as a permanent resident. With the help of this category, all the family members are capable of reuniting their loved ones to Canada.&nbsp;In other words, the&nbsp;<strong>family visa for Canada</strong>&nbsp;helps your family members to be the permanent residents of Canada. These family members could be anyone like your parents, your children, your spouse, or any adopted children.&nbsp;</p>\r\n<p>This, in turn, means that all your relatives can stay, work and also study in Canada after they get their PR visa to Canada. You can sponsor the family members or relatives via this family visa program for your permanent residency status in Canada.&nbsp;The CIC i.e., Citizenship and Immigration Canada, has a limited visa system known as a Family Visa as a part of their immigration programs. The citizens of Canada or the permanent residents at minimum 18 years of age have the right to support the below members of their family:</p>\r\n<ul>\r\n<li>Grandchildren&nbsp;</li>\r\n<li>Grandparents</li>\r\n<li>Conjugal partner, Common-law partner, Spouse</li>\r\n<li>Children dependent on parents</li>\r\n<li>Dependent parents</li>\r\n<li>Siblings</li>\r\n<li>Grandchildren</li>\r\n<li>Grandparents</li>\r\n<li>Other relatives like orphaned nephew or niece</li>\r\n</ul>\r\n<h3><strong>Benefits of Canada Family Visa</strong>&nbsp;</h3>\r\n<p>With the help of the&nbsp;<strong>Canada family Visa from India,</strong>&nbsp;the citizens of Canada and the permanent residents of Canada are given a lot of categories for sponsoring their family members:</p>\r\n<ul>\r\n<li>Visa sponsored for the family</li>\r\n<li>The provincial nominee visa based on family</li>\r\n<li>The Super visa for parent or grandparent</li>\r\n<li>The dependent visa</li>\r\n<li>The spouse visa, common-law partner visa or the Conjugal Partner Visa</li>\r\n</ul>\r\n<p>Each category does have its own set of expectations that somehow the applicant must meet in order for the CIC to appropriately approve the family sponsorship visa application.&nbsp;</p>\r\n<p>The sponsors must have:</p>\r\n<ul>\r\n<li>Send the invitation letter to family members whom they are sponsoring.</li>\r\n<li>Demonstrate the ability to financially supporting their family members who are sponsored during the initial living period.</li>\r\n<li>Signing the agreement which confirms that they would understand the mutual responsibilities and the obligations.</li>\r\n<li>Sign the undertaking which promises to provide the basic needs of your family members, which they have been sponsoring.</li>\r\n</ul>\r\n<h3><strong>The Super Visa for the Grandparents and Parents</strong></h3>\r\n<p>The Sponsorship Program for Parents and Grandparents is minimal. Interested families must file an online application form to show their interest in registering. Immigration, Refugees, and Citizenship Canada (IRCC) select 10,000 of all these forms in a sort of annual lottery and also invites the selected ones to apply.</p>\r\n<p>To compensate for the program\'s limited size, IRCC gives Parents and the Grandparents for Super Visa. This is a multi-entry visa which can be extended for up to ten years, which enables your parents or the grandparents to stay in Canada on their initial visit for up to two years. For all your parents or the grandparents to qualify for a Super Visa, you must be the permanent resident or a citizen of Canada.</p>\r\n<p>Unlike with the Parents and the Grandparents Sponsorship Program, the Parents and the Grandparent\' Super Visa would not lead their parents to the permanent resident status.</p>\r\n<h4><strong>Accompanying the Family</strong></h4>\r\n<p>You might be capable of bringing your family with you whether you relocate to Canada on the temporary permit, like the study permit or the work permit.</p>\r\n<h4><strong>Temporary Workers</strong></h4>\r\n<p>You are entitled to have the spouse and the dependent children follow you to Canada if you accept a legitimate job offer from any Canadian employer and then apply for the work permit.</p>\r\n<p>If your kids are in school, they would be able to attend the Canadian educational institutions without having to have separate study permits. Your spouse or the partner may also be eligible to apply for the open work permit, enabling him or her to work for any Canadian employer.</p>\r\n<h4><strong>The International Students</strong></h4>\r\n<p>If you\'re admitted into the Canadian program, you might include your spouse and the dependent kids based on the study permit application. As with the temporary workers, accompanying spouses of the international students could apply for an open work visa, and their dependent child can go to school in Canada.</p>\r\n<h4><strong>What does the sponsorship entail?</strong></h4>\r\n<p>You are the primary applicant who promises to take care of the well-being of your family member as a sponsor for the Canadian family sponsorship visa. Economic prosperity also requires this. If the family member has to seek government financial support for any cause, you must be responsible to pay the money back to the Government of Canada.</p>\r\n<h4><strong>The Spousal Sponsorships</strong></h4>\r\n<p>It is necessary to show in the Canadian family sponsorship visas that a spousal partner is migrating to Canada due to your desire to live and working in the country. You would, therefore, have to prove your partnership with your spouse, common-law partner, or the marital partner to be true. You will show evidence of the genuine relationship with the spousal partner through a marriage certificate or the below documentation:</p>\r\n<ul>\r\n<li>Frequent communication like phone calls, emails, and letters</li>\r\n<li>Images of your partners and yourself</li>\r\n<li>The joint agreements like the bank accounts or the lease agreement</li>\r\n</ul>\r\n<h4><strong>Partnerships with same-sex</strong></h4>\r\n<p>Underneath the Canadian family sponsorship program, the partners with same-sex are eligible for sponsorship as long as the marriage has been officially recognized throughout the country where it happened. This involves partnerships of the same sex within or outside Canada. You have to provide reports to Citizenship and Immigration Canada on whether or not your same-sex marriage has been legally recognized, and when and where this happened.</p>\r\n<h3><strong>The Eligibility Criteria</strong></h3>\r\n<p>Canada\'s governing authorities are lenient whenever it comes to moving to Canada with family members and offer liberal eligibility. Let us understand the particular immigration for various family members such as grandparents, parents, children, or spouses.</p>\r\n<h4><strong>The eligibility criteria for the dependent child</strong></h4>\r\n<ul>\r\n<li>Must be less than 22 years of age and should not have a common-law partner or the spouse</li>\r\n<li>If more than 22 years of age, you need to satisfy the below-mentioned conditions:&nbsp;</li>\r\n</ul>\r\n<ul>\r\n<li style=\"list-style-type: none;\">\r\n<ul>\r\n<li>Must be engaged in a full-time course</li>\r\n<li>Must be dependent financially on the parents before 22 years of age</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<ul>\r\n<li>If the child common-law partner or a spouse before they turn 22, they must\r\n<ul>\r\n<li>be engaged in any full-time course</li>\r\n<li>They must be dependent financially on the parents since they become the spouse or the common-law partner.</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<ul>\r\n<li>If children are more than 22 years, he or she must be dependent financially on the parents because of the mental and physical conditions.</li>\r\n</ul>\r\n<h4><strong>The eligibility criteria for your spouse</strong></h4>\r\n<p>Canada\'s government accepts another individual to be the spouse or the common-law partner if that person is been living with you for at least a year. The coolest part is there is no need to request a separate spousal&nbsp;<strong>Canada visa family information form</strong>.</p>\r\n<h3><strong>Advantages of Family Visa in Canada</strong></h3>\r\n<p>There are various advantages of the&nbsp;<strong>family visa for Canada</strong>. Those include:</p>\r\n<ul>\r\n<li><strong>Quality of education-&nbsp;</strong>Canada offers top quality of education in addition to a good quality of life. It means one can provide your children with good knowledge when you sponsor them in the&nbsp;<strong>Canada Family visa</strong>. It further suggests that your children would surely have a bright future in Canada.</li>\r\n<li><strong>Affordable-&nbsp;</strong>Whether you\'re a permanent resident or perhaps a tourist, staying in Canada isn\'t so expensive. Because Canada is rated to be number one in the standard of living, hence you can also have a good quality of life at a low cost.</li>\r\n<li><strong>Good quality of life-&nbsp;</strong>Canada is said to serve you and your family with a better quality of life. The family visa would help you in serving good quality of life to all your dear ones too.</li>\r\n<li><strong>Safe as well as healthy communities-&nbsp;</strong>Since Canada is rated number one in quality life, in comparison with other nations, there are fewer safety concerns. Being a visitor, you would be treated in the same way as being viewed as a Canadian citizen. Sponsoring your family, therefore, means providing your family with a safe and also a stable atmosphere.</li>\r\n<li><strong>The Multicultural society-&nbsp;</strong>You will have the quietest and most inclusive community in Canada. Canadian people are sincere, and you won\'t feel awkward with them. There are also plenty of multicultural groups and immigrant associations. So, you\'ll easily find ethnic food from diverse cultures.</li>\r\n</ul>\r\n<h3><strong>Final Thoughts</strong></h3>\r\n<p>If you are involved in a&nbsp;<strong>Canada Family Visa from India,&nbsp;</strong>Program, please contact Visa Mount if you are looking to learn more about the documentation and the other immigration procedure.&nbsp;Visa Mount is the growing Immigration consultancy having a large and also a dedicated team of professionals that offer trouble-free services to their applicants through different immigration programs.&nbsp;</p>', '1', 'Canada Family Immigration', NULL, 'No', '6', 'country', '0', '0', 0),
(10, '13.jpg', '12.jpg', 'about.jpg', 'Germany ', 'Germany Job Seeker Visa', 'germany-job-seeker-visa', '<p>Germany has emerged as one of the most powerful countries in Europe. It has great growth prospects. You can grow and flourish professionally and have a gleaming career if you choose to work in this part of the world. The country seeks highly qualified professionals from different parts of the world to fill positions in different industries. Several people around the globe have moved to Germany to cash in on the opportunities available here.</p>\r\n<p><strong><span style=\"text-decoration: underline;\">What is Germany Job Seeker Visa?</span></strong></p>\r\n<p>This is a long term residency permit. It allows immigrants to live in Germany for as long as six months and seek a suitable job here. If you acquire a job in the country during this period then you shall get Germany work permit. This will allow you to work and live there.</p>\r\n<p>So does that mean anyone can apply for this visa and go look for a job in Germany? NO! Here is a look at the eligibility criteria to apply for this visa:</p>\r\n<ul>\r\n<li>A Bachelor or Master&rsquo;s Degree from German University or an equivalent degree.</li>\r\n<li>A minimum 5 years of relevant work experience.</li>\r\n<li>Proof of funds to show you can take care of the expenses during your stay in Germany.</li>\r\n<li>Travel/ medical insurance until you acquire work permit</li>\r\n</ul>\r\n<p>It is essential to produce all the necessary documents to support your educational qualification, work experience, health cover, proof of funds and more. Valid passport, cover letter containing the objective of your visit, proof of accommodation in Germany, bank account statement and birth certificate are some of the documents you will be required to produce at the time of filing application for the Germany Job Seeker Visa.</p>\r\n<p><strong><span style=\"text-decoration: underline;\">Apply for Germany Job Seeker Visa Successfully</span></strong></p>\r\n<p>If you have made up your mind to get Germany Job Seeker Visa then let us help you with the task to get you through successfully. We have thorough knowledge about all the documents needed for the filing of the application. We also know how to smoothly sail through the application process and substantially increase the odds of acquiring the visa.</p>', '1', 'USA IMMIGRATION', NULL, 'Yes', '1', 'country', '1', '0', 4),
(11, 'hongkong.jpg', '11.jpg', 'about.jpg', 'Hong Kong', 'Hong Kong QMAS Visa', 'hong-kong-qmas-visa', '<p>Hong Kong Qmas Visa is drawing the attention of numerous immigrants from around the world. This is because of the numerous, lucrative career opportunities available in Hong Kong. The country seeks skilled professionals particularly in the field of IT, finance, creative arts and law to strengthen its economy. It is inviting qualified immigrants by way of Hong Kong Quality Migrant Admission Scheme.</p>\r\n<p><strong><span style=\"text-decoration: underline;\">Know More about Hong Kong Quality Migrant Admission Scheme</span></strong></p>\r\n<p>Hong Kong Quality Migrant Admission Scheme or QMAS Visa is basically a point based scheme. Points are given on the basis of different factors such as your age, qualification, work experience, language proficiency and dependants.</p>\r\n<p>In order to qualify for the same, you require 80/195 points in General Test or score 195 points in the Achievement Based Points Test. The candidates must also produce the required documents. These include a valid passport along with travel history, educational credentials, documents supporting professional experience and police clearance certificate among others.</p>\r\n<p>Those who qualify in the test and have all the required documents can:</p>\r\n<ul>\r\n<li>Entre Hong Kong without a job offer</li>\r\n<li>Work in their preferred industry in Hong Kong</li>\r\n<li>Bring their dependents to the country</li>\r\n<li>Settle in Hong Kong permanently</li>\r\n</ul>\r\n<p><strong><span style=\"text-decoration: underline;\">Seek Our Assistance to Acquire QMAS Visa</span></strong></p>\r\n<p>Though Hong Kong is inviting skilled professionals to work across industries in the country, however this does not mean anyone can go there. Hong Kong has a stringent procedure to screen the applications and allows only those who would truly be an asset to the country.</p>\r\n<p>We have been helping Indians immigrate to Hong Kong under this scheme since quite long and are well aware about the kind of applications that have a chance to get through and those that are likely to fail.</p>\r\n<p>We help our clients collate all the necessary documents by sharing an extensive immigration documents checklist with them. Next, we help them fill the application and forms appropriately. We also help in the submission of the application. The task to follow up with the embassy is ours when you opt for our service. You don&rsquo;t have to take out time from your busy schedule to visit the embassy or contact them to follow up on your application.</p>\r\n<p>Moreover, we also offer relocation and post landing support to our clients to ease the whole process them.</p>\r\n<p align=\"center\">All in all, we are there to help you with the complete application and migration process.</p>', '1', 'UK Immigration', NULL, 'Yes', '1', 'country', '1', '0', 5),
(12, 'CANADA-PNP.png', '', '', 'Canada PNP', 'Canada PNP', 'canada-pnp', '', '1', '', NULL, 'No', '6', 'country', '1', '0', 0),
(13, 'Manitoba-PNP-Programe.jpg', '', '', 'Manitoba PNP', 'Manitoba PNP', 'manitoba-pnp', '', '1', '', NULL, 'Yes', '12', 'country', '0', '1', 0),
(14, 'Ontario-PNP-Program.jpg', '', '', 'Ontario PNP', 'Ontario PNP', 'ontario-immigrant-nominee-program', '', '1', '', NULL, 'Yes', '12', 'country', '1', '1', 0),
(15, 'New-Brunswick-PNP-Program.jpg', '', '', 'New Brunswick PNP', 'New Brunswick PNP', 'new-brunswick-pnp', '', '1', '', NULL, 'Yes', '12', 'country', '0', '1', 0),
(17, 'Novascotia-PNP-Program.jpg', '', '', 'Nova Scotia', 'Nova Scotia', 'nova-scotia', '', '1', '', NULL, 'Yes', '12', 'country', '0', '1', 0),
(18, 'Saskathewan-PNP-Program.jpg', '', '', 'Saskatchewan PNP', 'Saskatchewan PNP', 'saskatchewan-pnp', '', '1', '', NULL, 'Yes', '12', 'country', '0', '1', 0),
(22, 'Alberta.png', '', 'about.jpg', 'Alberta PNP Program', ' Alberta PNP Program', 'alberta-pnp-program', '', '1', 'Alberta ', NULL, 'No', '12', 'country', '0', '1', 0),
(23, 'prince.png', '', 'about.jpg', 'Prince Edward Island', 'Prince Edward Island', 'prince-edward-island', '', '1', '', NULL, 'No', '12', 'country', '0', '1', 0),
(24, 'northwest-territories.png', '', 'about.jpg', 'Northwest Territories', 'Northwest Territories', 'northwest-territories', '', '1', '', NULL, 'No', '12', 'country', '1', '1', 0),
(25, 'british-columbia.png', '', 'about.jpg', 'British Columbia', 'British Columbia', 'british-columbia', '', '1', '', NULL, 'No', '12', 'country', '0', '1', 0),
(31, '', '', '', 'Australia Occupation In Demand', 'Australia Occupation In Demand', 'australia-occupation-in-demand', '', '1', '', NULL, 'No', '5', 'country', NULL, NULL, NULL),
(32, '', '', '', '65 Points Australian Immigration 2020', '65 Points Australian Immigration 2020', '65-points-australian-immigration', '', '1', '', NULL, 'No', '5', 'country', '0', '0', 0),
(33, '', '', '', 'Employer Nomination Scheme Subclass Visa 186', 'Employer Nomination Scheme Subclass Visa 186', 'employer-nomination-scheme-subclass-visa-186', '', '1', '', NULL, 'No', '5', 'country', NULL, NULL, NULL),
(34, '', '', 'about.jpg', 'Skilled Independent Visa (Subclass 189)', 'Skilled Independent Visa (Subclass 189)', 'skilled-independent-visa-subclass-189', '<p>The&nbsp;<strong>Skilled-Independent Visa (subclass 189)</strong>&nbsp;is a skilled Australian visa for the skilled workers who are not sponsored by the employer, by the state or the territory or the member of a family.&nbsp;</p>\r\n<p>The&nbsp;<strong>subclass visa 189&nbsp;</strong>holders can permanently work as well as live in Australia. The application must include individual family members. For being eligible for a visa<strong>,&nbsp;</strong>you are required to score a minimum of 65 points on the Points Test.&nbsp;</p>\r\n<h2><strong>What is the skilled independent subclass 189 visa?</strong></h2>\r\n<p>With this&nbsp;<strong>skilled independent subclass 189 visa</strong>, you can live as well as work in Australia. Many skilled workers listed on the&nbsp;<strong>skilled independent visa (subclass 189) occupation list</strong>&nbsp;can be eligible for the visa category. This&nbsp;<strong>subclass 189 visa</strong>&nbsp;demands that the candidates complete the skills test and must be supported by the employer or the family member, or approved by the State government.</p>\r\n<h3><strong>Skilled independent visa (subclass 189) &ndash; How can one apply?</strong></h3>\r\n<p>For becoming eligible, a valid application for the Subclass Visa 189, you must first receive a positive evaluation of the skills and then submit the EOI i.e., Expression of Interest via SkillSelect.&nbsp;</p>\r\n<p><strong>Step 1: Check whether your occupation is on the skilled independent visa (subclass 189) occupation list</strong></p>\r\n<p>This visa<strong>&nbsp;</strong>is made available to people those fill the positions on the&nbsp;<strong>skilled independent visa (subclass 189) occupation list</strong></p>\r\n<p><strong>Step 2: See to that you meet all the eligibility criteria</strong></p>\r\n<p>To apply for the&nbsp;<strong>subclass visa 189,&nbsp;</strong>you need to meet the below standards:</p>\r\n<ul>\r\n<li>You should be less than 50 years</li>\r\n<li>Have proper English speaking skills</li>\r\n<li>You need to meet all the health as well as the character requirements</li>\r\n<li>You should not hold the outstanding debts to the Government of Australia</li>\r\n<li>Must willingly sign the values statement of Australia</li>\r\n</ul>\r\n<p><strong>Step 3: Complete the Skills Assessment</strong></p>\r\n<p>You should complete the Skills Assessment and also obtain the acceptable score for becoming eligible for a&nbsp;<strong>skilled independent visa (subclass 189).&nbsp;</strong></p>\r\n<h4><strong>Step 4: Submit the EOI i.e., Expression of Interest visa SkillSelect</strong></h4>\r\n<p>You are required to submit the EOI via SkillSelect. This SkillSelect program would ask you lots of questions related to your background, relevant work history, and skills. The authorities would see the Expression of Interest in Australia. It must be available to the employers in Australia who are looking for someone having good skill sets for hire. Whenever you obtain the nomination or the sponsor and the expression of interest meet all the requirements of the&nbsp;<strong>subclass visa 189,&nbsp;</strong>you would be invited to apply for 189 visas.</p>\r\n<p><strong>Step 5: Find the sponsor</strong></p>\r\n<p>For a&nbsp;<strong>skilled independent visa (subclass 189),&nbsp;</strong>you must be sponsored by the employer or the family member or must be nominated by the territory government or the state. When you find the perfect sponsor, they will send you the invitation to an application letter for&nbsp;<strong>a subclass 189 visa.&nbsp;</strong></p>\r\n<p>If you don&rsquo;t have the eligible employer or the relative for sponsoring you, then you can find the employer via a SkillSelect program. This SkillSelect program does match with the skilled workers along with employers who are looking for abroad working people. The territory or the state government might even nominate you via this program.</p>\r\n<p><strong>Step 6: Complete all the required paperwork through the sponsor</strong></p>\r\n<p>When you find the sponsor, you should be nominated through them for the visa. One can also apply for the visa at the same time when the sponsors apply. The employer can also complete the nomination application in online mode visa DHA.</p>\r\n<h4><strong>Step 7: You need to apply for Skilled Independent Visa (subclass 189) &ndash;Work Visa</strong></h4>\r\n<p>Once you find the potential employer and get the nomination, one can also apply for&nbsp;<strong>a subclass 189 visa</strong>&nbsp;in an online mode via DHA.</p>\r\n<p><strong>&nbsp;8: You need to wait for the decision</strong></p>\r\n<p>It takes some time for DHA to decide on the visa application.&nbsp;</p>\r\n<p><strong>Step 9: You will receive the visa and then start working</strong></p>\r\n<p>When your application is accepted, you would be obtaining your visa, and then you can start working in Australia.</p>\r\n<h3><strong>Skilled independent visa (subclass 189) Process in Australia</strong></h3>\r\n<p><strong>Subclass Visa 189&nbsp;</strong>depends on the three-stage application process.</p>\r\n<ul>\r\n<li><strong>Stage 1-&nbsp;</strong><span>The first stage in the application process includes the completion of skills assessment with the relevant Government body. Skills assessment allows the Home affairs department to judge if you hold the necessary level of skills which you have chosen in the occupation for practicing in Australia.</span></li>\r\n</ul>\r\n<ul>\r\n<li><strong>Stage 2-&nbsp;</strong><span>Whenever you receive a positive skills assessment, you are required to submit the EOI visa SkillSelect.</span></li>\r\n</ul>\r\n<ul>\r\n<li><strong>Stage 3-&nbsp;</strong><span>Whenever you are issued the ITA i.e., the Invitation to Apply, one can continue with the Home Affairs department of application where one can submit the final and completed application to get it approved by the Home Affairs department so that your&nbsp;</span><strong>subclass 189 visa</strong><span>&nbsp;gets granted.</span></li>\r\n</ul>\r\n<h3><strong>The Skilled Visa Conditions in Australia</strong></h3>\r\n<p>A qualified applicant will be granted a multiple entry visa for living and working in Australia for five years. You only have to live 2 of the five years in Australia to get the visa reissued for another five years. Additionally, you can stay in Australia for four consecutive years and be eligible for citizenship.</p>\r\n<p>Nevertheless, when you choose not to obtain citizenship, you should apply for the Resident Return Visa for traveling to and from Australia before the initial one expires. To apply for this, you must prove that you have been legally residing in Australia for two years or that you have significant personal, cultural, or business ties with Australia.</p>\r\n<p>Complete the online assessment to decide whether you can qualify as the highly skilled migrant to the Australian Qualified-Independent Visa.</p>\r\n<h3><strong>Benefits of the subclass visa 189</strong></h3>\r\n<p>The&nbsp;<strong>subclass 189 visa&nbsp;</strong>offers various benefits of the permanent residency in Australia for yourself and your family. They are:&nbsp;</p>\r\n<ul>\r\n<li>One can live as well as work in Australia permanently</li>\r\n<li>You get the opportunity of studying in Australia</li>\r\n<li>You can also enroll in the medicare or the healthcare program run in Australia</li>\r\n<li>The chance for applying for citizenship in Australia</li>\r\n<li>You can even sponsor all the relatives and your family members for Permanent residency</li>\r\n<li>You can travel in and around Australia</li>\r\n</ul>\r\n<h3><strong>Visa Process in a Nutshell</strong></h3>\r\n<p>For applying for this visa<strong>,&nbsp;</strong>you should:</p>\r\n<ul>\r\n<li>be less than 45 years in an age whenever you being invited to apply.</li>\r\n<li>Nominate the occupation which matches all your qualifications and skills and is on relevant MLTSSL.</li>\r\n<li>have all the skills assessed by proper assessing authority suitable for the nominated occupation</li>\r\n<li>be competent in English</li>\r\n<li>score minimum 65 points in the Points Test</li>\r\n<li>meet all the character and the health needs</li>\r\n</ul>\r\n<p>I hope this helps.&nbsp;</p>', '1', '', NULL, 'No', '5', 'country', '0', '0', 0),
(35, '', '', 'about.jpg', 'Skilled Nominated Visa Subclass 190', 'Skilled Nominated Visa Subclass 190', 'skilled-nominated-visa-subclass-190', '', '1', '', NULL, 'No', '5', 'country', NULL, NULL, NULL),
(36, '', '', 'about.jpg', 'Sponsored Provisional Visa (Subclass 489) Visa', 'Sponsored Provisional Visa (Subclass 489) Visa', 'sponsored-provisional-visa-subclass-489-visa', '', '1', '', NULL, 'No', '5', 'country', NULL, NULL, NULL),
(37, '', '', 'about.jpg', 'Post Landing Services ', 'Post Landing Services ', 'post-landing-services', '', '1', '', NULL, '0', '6', 'country', NULL, NULL, NULL);
INSERT INTO `countrydemo` (`id`, `flag`, `image`, `bimage`, `name`, `heading`, `url`, `description`, `status`, `alt`, `location`, `shomepage`, `pmenu`, `page_type`, `spcountry`, `scpnp`, `orderby`) VALUES
(38, '', '', 'about.jpg', 'Canada PR Visa', 'Canada PR Visa', 'canada-pr-visa', '<p>Are you inspired by migration to Canada based on the&nbsp;<strong>Canada PR visa?</strong>&nbsp;Are you wishing to settle down in Canada, and then following the Canada PR process is necessary.&nbsp;</p>\r\n<h2><strong>All about Canada PR Visa</strong></h2>\r\n<p>The&nbsp;<strong>Canada PR Visa&nbsp;</strong>is provided to people who have the right to work as well as life in Canada without having any stay limit. To get the<strong>&nbsp;PR visa for Canada,&nbsp;</strong>the potential applicants should apply for the IRCC, which means immigration, refugee, and citizenship Canada.&nbsp;</p>\r\n<p>The&nbsp;<strong>Canada Permanent Visa&nbsp;</strong>is granted to those who are permanent residents of Canada. Depending on the various compelling factors that include career opportunities, security, environment, and living quality, etc. Canada has been rated to be the number one country throughout the world for permanent residency. Getting to stay in Canada via&nbsp;<strong>Canada Permanent Visa&nbsp;</strong>is the right option.</p>\r\n<h2><strong>Advantages of having a PR Visa Canada</strong></h2>\r\n<ul>\r\n<li>The residents are protected by a Canadian Charter and Canadian Law of Freedom and Rights</li>\r\n<li>The social benefits</li>\r\n<li>The healthcare facilities</li>\r\n<li>Citizens having a Permanent Residency are eligible for the citizenship of Canada</li>\r\n</ul>\r\n<h3><strong>The Canada PR Process</strong></h3>\r\n<p>After you apply and once it is approved, the foreign national can get their Canada Permanent visa. With this, they can migrate to Canada and can also enjoy various benefits that are similar to the citizens of Canada.</p>\r\n<p>In effect, surely, the best distinction between the Canadian citizen and permanent resident of Canada is a right to hold the public office and join the military and also vote. To become a Canadian permanent resident is a fundamental human right that can be revoked if a person is observed guilty of any serious crime so as a consequence is deported.</p>\r\n<p>Some other way a permanent resident of Canada may lose his or her status is through failing to fulfill their duty to reside. The permanent resident in Canada is expected to spend at least two years in Canada in each 5 year period.&nbsp;</p>\r\n<p>If an officer is worried at either the port of entry or at the Canadian visa office that the permanent resident of Canada hasn\'t fulfilled his obligation to live, they will begin counting five years to check that the permanent resident of Canada has spent approximately 730 days in Canada.</p>\r\n<p>To meet the residency requirement, a permanent resident of Canada should have spent a minimum of 730 days seeing one of the below over the last five years:</p>\r\n<ul>\r\n<li>Working in a foreign country for the Canadian company</li>\r\n<li>Accompanying their spouse abroad who is a citizen of Canada</li>\r\n<li>Staying in Canada</li>\r\n</ul>\r\n<h3><strong>Necessary Documents for applying PR in Canada</strong></h3>\r\n<ul>\r\n<li>The results of IELTS</li>\r\n<li>The original copies of various documents that support your application</li>\r\n<li>Your educational certificates, diploma certificates if any, your id proofs and other relevant information</li>\r\n<li>The Educational Credential Assessment &ndash; ECA</li>\r\n<li>The sufficient fund proof which supports your application</li>\r\n<li>Clearance certificate from the police</li>\r\n<li>All the certificates those prove your medical fitness</li>\r\n</ul>\r\n<h3><strong>The Eligibility Criteria</strong></h3>\r\n<p>You are required to get 67 points depending on your language skills, your work experience, your education, and age as well as the job offer that you hold. Your work experience must be featured in an occupation list of <strong>Canada PR Visa</strong>, which is known as the \"National Occupational Classification\". When you clear the eligibility criteria, you should apply for a visa card in three easy steps.</p>\r\n<p>Canada\'s permanent resident visa has several immigration initiatives. Still, if you\'re a skilled worker, the Express Entry system of Canada is the easiest way for those looking to get permanent residency in Canada.</p>\r\n<ul>\r\n<li>Step 1: Test your points accompanied by the WES or any other related evaluation bodies.</li>\r\n<li>Point 2: Apply directly via an electronic portal entitled as an Express Entry, and get selected depending on the ranking.</li>\r\n<li>Step 3: Invite to apply. Prepare a final request together with the documents as well as the applicable fees.&nbsp;</li>\r\n</ul>\r\n<p>Once you\'ve completed these three easy steps and the visa has been confirmed, you\'ll be required to submit your passport for your visa stamping to the <a href=\"https://www.international.gc.ca/country-pays/india-inde/index.aspx?lang=eng\">Canadian Embassy</a>.</p>\r\n<h3><strong>How one makes use of the Express Entry System for the Visa?</strong></h3>\r\n<p>If you are a skilled worker, the Federal Skilled Workers Program allows you to qualify for a <strong>Canada PR Visa</strong>. In 2015 the Canadian government launched this to attract skilled workers to come and live in the country. To be eligible under this system, in the eligibility criteria given below, you should be able to get 67 points out of 100: Age: those between 18-35 years get maximum points. Those over 35 earn fewer points while the maximum age to qualify is 45.</p>\r\n<ul>\r\n<li><strong>Education:</strong> According to Canadian standards, under this category, your education qualification must be equal to higher secondary education.</li>\r\n<li><strong>Work experience:</strong> You should have full-time work experience of at least one year for minimum points. More years of experience with work means more points. Your jobs must be classified as National Occupational Classification (NOC) Skill Type 0 or Skill Level A or B.</li>\r\n<li><strong>Language skills:</strong> In your IELTS exam, you must have at least six bands, and the score must be less than two years old. If you are fluent in French, you get extra points.</li>\r\n<li><strong>Adaptability:</strong> If your spouse or common-law partner is able to move to Canada with you, you are entitled to 10 additional Adaptability Points.</li>\r\n<li><strong>Arranged employment:</strong> If you have a valid offer from a Canadian employer, you will receive a maximum of 10 points.</li>\r\n</ul>\r\n<h3><strong>How one can qualify for the PR Visa via the PNP &ndash; Provincial Nominee Program</strong></h3>\r\n<p>If you feel that under the Express Entry system, you may not get the required points for a PR visa, you may find the Provincial Nominee Program. There are two options to get your PR visa using the PNP system.&nbsp;If any province needs such a profile as yours, they will pick your nomination profile and give you an invitation to apply for a <strong>Canada PR Visa</strong>.&nbsp;If you want to live in a given province in Canada, you will apply directly to that province.</p>\r\n<p>When you satisfy the requirements, you can obtain a provincial nomination. After you receive the nomination form, you can apply for permanent residency.&nbsp;The advantage to use the PNP program is that if you have applied for a <strong>Canada PR Visa</strong> under that program earlier, you could include the points you scored in the Express Entry Program. You must use those points to your PNP profile.</p>', '1', '', NULL, 'No', '6', 'country', '0', '0', 0),
(39, '', '', 'about.jpg', 'Canada Express Entry Program 2020', 'Canada Express Entry Program 2020', 'canada-express-entry-program', '<h2><strong>Express Entry Points Calculator</strong></h2>\r\n<p>Canada employs the point-based migration system to attract. It\'s highly experienced and skilled workers that can contribute to its growing economy. The point-based system Canada is pursuing is straightforward. Here is a brief introduction about how the Express Entry Points Calculator works:&nbsp;</p>\r\n<p>The method for points on which the Canada functions is known as a Comprehensive Ranking System (CRS). The order came into use in January 2015.</p>\r\n<p>An important thing that one must do is create an online Express Entry profile with your personal details, especially your age, communication skills, educational qualifications, your work experience, etc.&nbsp;</p>\r\n<p>The documents that you provide in the profile would be considered to provide you with the CRS score. The CRS score then determines whether you are eligible for applying for the Canada PR.</p>\r\n<h3><strong>The Express Entry Points Calculator</strong></h3>\r\n<p>The&nbsp;<strong>Express Entry Points Calculator</strong>&nbsp;is vital to know the chances of getting a <a href=\"../../canada-pr-visa\">Canada PR Visa</a>. Canada migration is indeed a point-based system and determines your eligibility depending on your CRS score.&nbsp;The abbreviation CRS is for the Comprehensive Ranking System. The CRS ranking system is an analytical framework explicitly designed by the Canadian immigration authorities to award numerical scores to all applicants applying for the Immigration to&nbsp;<strong>Canada Express Entry points calculator</strong>.</p>\r\n<p>The CRS score of the candidate is a fair analysis of his / her performance since it is based on the information entered by the candidate in his / her Express Entry Profile. It is incredibly efficient as well as unbiased, as the automated system calculates points for every candidate automatically, and there\'s no independent person or a company involved can favor any one candidate over another.</p>\r\n<p>Below is the list of max points a candidate may earn depending on the details of his/her profile:</p>\r\n<h4><strong>Human Capital Factors:</strong></h4>\r\n<ul>\r\n<li>One can score a maximum of 80 points for their work experience in Canada</li>\r\n<li>One can score a maximum of 160 points for their proficiency in the language</li>\r\n<li>Score a maximum of 150 points for their educational qualifications</li>\r\n<li>One can score a maximum of 110 points for their age</li>\r\n</ul>\r\n<h4><strong>Spouse or Common-law Factors:</strong></h4>\r\n<ul>\r\n<li>One can score a maximum of 20 points for the language proficiency of their spouse</li>\r\n<li>Score a maximum of 10 points for academic excellence of their spouse</li>\r\n<li>One can score a maximum of 10 points for the work experience of their spouse in Canada</li>\r\n</ul>\r\n<h4><strong>The skill transferability</strong></h4>\r\n<ul>\r\n<li>Work experience in a foreign country\r\n<ul>\r\n<li>One can score a maximum of 50 points for their proficiency in language with their work experience in a foreign country</li>\r\n<li>One can score a maximum of 50 points for their work experience in Canada or work experience in any other foreign country&nbsp;</li>\r\n</ul>\r\n</li>\r\n<li>Trade Certification or Qualification:\r\n<ul>\r\n<li>One can score a maximum of 50 points for their proficiency in the English language with the qualification certificates</li>\r\n</ul>\r\n</li>\r\n<li>Education:\r\n<ul>\r\n<li>One can score a maximum of 50 points for their post-secondary degree with the skill in language</li>\r\n<li>One can score a maximum of 50 points for their work experience in Canada with a post-secondary degree.</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<p><strong>The Bonus Points</strong></p>\r\n<ul>\r\n<li>One can score a maximum of 15 points if they have a sibling staying in Canada with the PR status</li>\r\n<li>One can score a maximum of 15 points if they have a post-secondary degree in education from Canada with the credentials of 1 to 2 years</li>\r\n<li>Score a maximum of 30 points if they own a post-secondary degree with the credentials up to 3 years of experience or even more</li>\r\n<li>One can score a maximum of 200 points if they have an offer letter listed in the occupation in NOC 00</li>\r\n<li>One can score a maximum of 50 points if they have an offer letter from the job in the profession listed in the NOC 0, A or B.</li>\r\n<li>Score a maximum of 600 points if they receive the nomination from the Canadian province for the PNP program.</li>\r\n</ul>\r\n<h3><strong>How can one increase their score with the help of the PNP program i.e., a Provincial Nominee Program?</strong></h3>\r\n<p>Provincial Nominee Programs (PNPs) are the immigration alternative that should be considered when it does not have sufficient&nbsp;<strong>express entry Canada points calculator</strong>. Yes, you would receive additional 600 points when chosen by either a province to win the provincial nomination, which will automatically get you the ITA at the next draw. &nbsp;However, you\'ll need to stay in the province when you get your permanent residence with a provincial nomination (more detailed information on the subject here).&nbsp;</p>\r\n<p>Most of the provinces have the immigration streams aligned with the&nbsp;<strong>Canada Express Entry points calculator 2020</strong>, but each area and the flow will have its eligibility requirements.</p>\r\n<h3><strong>What is the cut-off for the CRS?</strong></h3>\r\n<p>For Canada PR to receive an Invitation to Apply (ITA), you need to get points that are more than or equal to the CRS cut. The CRS cut off is the minimum number of points a candidate must score in order to obtain an ITA. The cut-off score is 473 based on the latest Express Entry draw.</p>\r\n<h3><strong>What can affect the CRS score?</strong></h3>\r\n<p>The&nbsp;<strong>Express entry points calculator</strong>&nbsp;is a ranking that helps immigration authorities find a qualified applicant for permanent residency in Canada.&nbsp;The Express Entry system uses the CRS score mostly to validate the profiles of candidates whose applications they receive for permanent residency in Canada each year.&nbsp;The score has played a very crucial role in selecting candidates. The profiles with the highest CRS score have the most chances of receiving a faster Invitation to Apply.</p>\r\n<h3><strong>How can you increase the CRS score via language skills?</strong></h3>\r\n<p>Boost your English proficiency. If you feel you haven\'t scored enough bands in IELTS to check your English language skills, you can show up again for a test and raise your score and boost your points further. You could also try to display your French skills as you could get extra points by having decent French language skills.</p>\r\n<h3><strong>Based on education</strong></h3>\r\n<p>You can also increase your points if you are improving your educational qualifications. For example, you can opt for a master\'s degree and even a Ph.D. when you are just graduated and also had a bachelor\'s degree. This is making an awful difference in increasing your points and getting a permanent residency.</p>', '1', '', NULL, 'No', '6', 'country', '0', '0', 0),
(40, '', '', 'about.jpg', 'How Express Entry Works?', 'How Express Entry Works?', 'how-express-entry-works-', '', '1', '', NULL, '0', '6', 'country', NULL, NULL, NULL),
(41, '', '', 'about.jpg', 'Canada PNP Program 2020', 'Canada PNP Program 2020', '#canadapnp', '', '1', '', NULL, 'No', '6', 'country', '0', '0', 0),
(42, '', '', 'about.jpg', 'Express Entry Points Calculator', 'Express Entry Points Calculator', 'express-entry-points-calculator', '', '1', '', NULL, '0', '6', 'country', NULL, NULL, NULL),
(43, '', '', 'about.jpg', 'Express Entry Next Draw Prediction', 'Express Entry Next Draw Prediction', 'express-entry-next-draw-prediction', '', '1', '', NULL, '0', '6', 'country', NULL, NULL, NULL),
(44, '', 'about.jpg', '', 'New zealand', 'NEW ZEALAND IMMIGRATION', 'new-zealand-immigration', '', '1', 'newzealand-immigration', NULL, 'Yes', '1', 'country', '1', '0', 3),
(45, '', '', 'about.jpg', 'Family Category Visa', 'Family Category Visa', 'family-category-visa', '', '1', '', NULL, '0', '44', 'country', NULL, NULL, NULL),
(46, '', '', 'about.jpg', 'Relugee Family Support Visa', 'Relugee Family Support Visa', 'relugee-family-support-visa', '', '1', '', NULL, '0', '44', 'country', NULL, NULL, NULL),
(47, '', '', 'about.jpg', 'Parents Retirement Category Visa', 'Parents Retirement Category Visa', 'parents-retirement-category-visa', '', '1', '', NULL, '0', '44', 'country', NULL, NULL, NULL),
(48, '', '', 'about.jpg', 'Work to Residence Visa', 'Work to Residence Visa', 'work-to-residence-visa', '', '1', '', NULL, '0', '44', 'country', NULL, NULL, NULL),
(49, '', '', 'about.jpg', 'Residence From Work Visa', 'Residence From Work Visa', 'residence-from-work-visa', '', '1', '', NULL, '0', '44', 'country', NULL, NULL, NULL),
(50, '', '', 'about.jpg', 'Skilled Migration Visa', 'Skilled Migration Visa', 'skilled-migration-visa', '', '1', '', NULL, '0', '44', 'country', NULL, NULL, NULL),
(51, '', '', 'about.jpg', 'Long Term Skilled Shortage List', 'Long Term Skilled Shortage List', 'long-term-skilled-shortage-list', '', '1', '', NULL, '0', '44', 'country', NULL, NULL, NULL),
(52, '', '', 'about.jpg', 'Hong Kong Quality Migrant Admission Scheme', 'Hong Kong Quality Migrant Admission Scheme', 'hong-kong-quality-migrant-admission-scheme', '', '1', '', NULL, '0', '11', 'country', NULL, NULL, NULL),
(53, '', '', 'about.jpg', 'Germany Job Seeker Visa', 'Germany Job Seeker Visa', 'germany-job-seeker-visa', '', '1', '', NULL, '0', '10', 'country', NULL, NULL, NULL),
(56, 'yukon.png', '', 'about.jpg', 'Yukon', 'Yukon', 'yukon', '', '1', '', NULL, 'No', '12', 'country', '0', '1', 0);

-- --------------------------------------------------------

--
-- Table structure for table `crs`
--

CREATE TABLE `crs` (
  `id` int(100) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `heading` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bimage` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `crs`
--

INSERT INTO `crs` (`id`, `image`, `name`, `heading`, `url`, `description`, `status`, `bimage`) VALUES
(18, 'Canada 67 Point.png', 'CRS Point Calculator 2020', 'CRS Point Calculator 2020', 'crs-point-calculator', '', '1', 'CRS (1).jpg');

-- --------------------------------------------------------

--
-- Table structure for table `crsform`
--

CREATE TABLE `crsform` (
  `id` int(100) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `dcountry` varchar(255) DEFAULT NULL,
  `rcountry` varchar(255) DEFAULT NULL,
  `experience` varchar(255) DEFAULT NULL,
  `education` varchar(255) DEFAULT NULL,
  `reading` varchar(255) DEFAULT NULL,
  `writing` varchar(255) DEFAULT NULL,
  `listening` varchar(255) DEFAULT NULL,
  `speaking` varchar(255) DEFAULT NULL,
  `age` varchar(255) DEFAULT NULL,
  `mstatus` varchar(255) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `adaptability` varchar(255) DEFAULT NULL,
  `message` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `enquiry`
--

CREATE TABLE `enquiry` (
  `id` int(100) NOT NULL,
  `date` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `service` varchar(255) DEFAULT NULL,
  `message` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `enquiry`
--

INSERT INTO `enquiry` (`id`, `date`, `name`, `email`, `service`, `message`) VALUES
(1, '21-03-1999', 'Ravinder', 'ravinderg631@gmail.com', 'web site', 'Ram Ram'),
(2, '31-03-2000', 'Ashwin', 'ashwin@gmail.com', 'web development', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\r\n\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `front_enquiry`
--

CREATE TABLE `front_enquiry` (
  `id` int(100) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `course` varchar(255) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `sdate` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `front_enquiry`
--

INSERT INTO `front_enquiry` (`id`, `name`, `email`, `phone`, `course`, `dob`, `sdate`, `message`) VALUES
(1, 'Ravinder', 'ravinderg631@gmail.com', '8930509185', 'Personality Development', '2020-12-31', '2020-12-31', 'hello\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `modal`
--

CREATE TABLE `modal` (
  `id` int(100) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `message` longtext DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `modal`
--

INSERT INTO `modal` (`id`, `name`, `phone`, `email`, `message`, `country`) VALUES
(8, 'Eric Jones', '416-385-3200', 'eric@talkwithcustomer.com', ' \r\nHey,\r\n\r\nYou have a website visamount.com, right?\r\n\r\nOf course you do. I am looking at your website now.\r\n\r\nIt gets traffic every day – that you’re probably spending $2 / $4 / $10 or more a click to get.  Not including all of the work you put into creating social media, videos, blog posts, emails, and so on.\r\n\r\nSo you’re investing seriously in getting people to that site.\r\n\r\nBut how’s it working?  Great? Okay?  Not so much?\r\n\r\nIf that answer could be better, then it’s likely you’re putting a lot of time, effort, and money into an approach that’s not paying off like it should.\r\n\r\nNow… imagine doubling your lead conversion in just minutes… In fact, I’ll go even better.\r\n \r\nYou could actually get up to 100X more conversions!\r\n\r\nI’m not making this up.  As Chris Smith, best-selling author of The Conversion Code says: Speed is essential - there is a 100x decrease in Leads when a Lead is contacted within 14 minutes vs being contacted within 5 minutes.\r\n\r\nHe’s backed up by a study at MIT that found the odds of contacting a lead will increase by 100 times if attempted in 5 minutes or less.\r\n\r\nAgain, out of the 100s of visitors to your website, how many actually call to become clients?\r\n\r\nWell, you can significantly increase the number of calls you get – with ZERO extra effort.\r\n\r\nTalkWithCustomer makes it easy, simple, and fast – in fact, you can start getting more calls today… and at absolutely no charge to you.\r\n\r\nCLICK HERE http://www.talkwithcustomer.com now to take a free, 14-day test drive to find out how.\r\n\r\nSincerely,\r\nEric\r\n\r\nPS: Don’t just take my word for it, TalkWithCustomer works:\r\nEMA has been looking for ways to reach out to an audience. TalkWithCustomer so far is the most direct call of action. It has produced above average closing ratios and we are thrilled. Thank you for providing a real and effective tool to generate REAL leads. - P MontesDeOca.\r\nBest of all, act now to get a no-cost 14-Day Test Drive – our gift to you just for giving TalkWithCustomer a try. \r\nCLICK HERE http://www.talkwithcustomer.com to start converting up to 100X more leads today!\r\n\r\nIf you\'d like to unsubscribe click here http://liveserveronline.com/talkwithcustomer.aspx?d=visamount.com\r\n', 'Australia'),
(9, 'Eric Jones', '416-385-3200', 'eric@talkwithwebvisitor.com', 'Hey there, I just found your site, quick question…\r\n\r\nMy name’s Eric, I found visamount.com after doing a quick search – you showed up near the top of the rankings, so whatever you’re doing for SEO, looks like it’s working well.\r\n\r\nSo here’s my question – what happens AFTER someone lands on your site?  Anything?\r\n\r\nResearch tells us at least 70% of the people who find your site, after a quick once-over, they disappear… forever.\r\n\r\nThat means that all the work and effort you put into getting them to show up, goes down the tubes.\r\n\r\nWhy would you want all that good work – and the great site you’ve built – go to waste?\r\n\r\nBecause the odds are they’ll just skip over calling or even grabbing their phone, leaving you high and dry.\r\n\r\nBut here’s a thought… what if you could make it super-simple for someone to raise their hand, say, “okay, let’s talk” without requiring them to even pull their cell phone from their pocket?\r\n  \r\nYou can – thanks to revolutionary new software that can literally make that first call happen NOW.\r\n\r\nTalk With Web Visitor is a software widget that sits on your site, ready and waiting to capture any visitor’s Name, Email address and Phone Number.  It lets you know IMMEDIATELY – so that you can talk to that lead while they’re still there at your site.\r\n  \r\nYou know, strike when the iron’s hot!\r\n\r\nCLICK HERE http://www.talkwithwebvisitor.com to try out a Live Demo with Talk With Web Visitor now to see exactly how it works.\r\n\r\nWhen targeting leads, you HAVE to act fast – the difference between contacting someone within 5 minutes versus 30 minutes later is huge – like 100 times better!\r\n\r\nThat’s why you should check out our new SMS Text With Lead feature as well… once you’ve captured the phone number of the website visitor, you can automatically kick off a text message (SMS) conversation with them. \r\n \r\nImagine how powerful this could be – even if they don’t take you up on your offer immediately, you can stay in touch with them using text messages to make new offers, provide links to great content, and build your credibility.\r\n\r\nJust this alone could be a game changer to make your website even more effective.\r\n\r\nStrike when  the iron’s hot!\r\n\r\nCLICK HERE http://www.talkwithwebvisitor.com to learn more about everything Talk With Web Visitor can do for your business – you’ll be amazed.\r\n\r\nThanks and keep up the great work!\r\n\r\nEric\r\nPS: Talk With Web Visitor offers a FREE 14 days trial – you could be converting up to 100x more leads immediately!   \r\nIt even includes International Long Distance Calling. \r\nStop wasting money chasing eyeballs that don’t turn into paying customers. \r\nCLICK HERE http://www.talkwithwebvisitor.com to try Talk With Web Visitor now.\r\n\r\nIf you\'d like to unsubscribe click here http://talkwithwebvisitor.com/unsubscribe.aspx?d=visamount.com\r\n', 'Canada');

-- --------------------------------------------------------

--
-- Table structure for table `newblog`
--

CREATE TABLE `newblog` (
  `id` int(100) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `bimage` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `heading` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `alt` varchar(255) DEFAULT NULL,
  `shomepage` varchar(255) DEFAULT NULL,
  `pmenu` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `page`
--

CREATE TABLE `page` (
  `id` int(100) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `heading` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `page`
--

INSERT INTO `page` (`id`, `name`, `url`, `heading`, `description`, `status`) VALUES
(24, 'About Us', 'about-us', 'ABOUT US', '<p>Dushyant World, a well-trusted, distinguished and renowned institute, was founded on 7th April, 2014 by Dushyant Kumar. Since its inception, it has been enriching the potential and personality of its students with international level of English communication, globally accepted standard of accent of English and high thinking to achieve unimaginable success in their life. The institute has strengthened the candidature of its students to compete at any level and show their abilities and demonstrative skills in order to make their recognition exceptionally in the society. The people, who have been trained here, feel pride having been the part of the Institute.<br />The institute\'s incredible achievement is the enrollment of 70 families (as per the date) in different courses.<br />The Institute imparts training in the area of English Communication, coaching for IELTS, TOEFL, PTE, CELPIP, OET, Voice &amp; Accent, Personality Development and Professional Writing.<br />The Director, Dushyant Kumar, is a Postgraduate in English and a Certified Trainer from Indian Society for Training and Development (ISTD).<br />Our Mission -<br />To train people to enrich their personality with English Communication of international standard by using its distinguished methodology and disseminating the absolute knowledge of English.<br />Our Vision -<br />To be at the top on the Earth in English Communication and Personality Enrichment training in order to produce eloquent speakers and writers in the society at large.</p>\r\n<p>Our Methodology<br />To take less time of students but comparatively give them more learning.</p>', '1');

-- --------------------------------------------------------

--
-- Table structure for table `seo`
--

CREATE TABLE `seo` (
  `id` int(100) NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `seotitle` varchar(255) DEFAULT NULL,
  `keyword` varchar(255) DEFAULT NULL,
  `seodescription` longtext DEFAULT NULL,
  `metatag` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `seo`
--

INSERT INTO `seo` (`id`, `url`, `seotitle`, `keyword`, `seodescription`, `metatag`) VALUES
(10, 'about-us', 'About Us', 'About Us', '', NULL),
(48, 'canada', 'Canada Immigration | Canada Immigration Consultants in Delhi', 'Canada Immigration News, Canada Immigration Points, Canada Immigration Eligibility, Canada Immigration Process, Immigration to Canada from India, Canada Immigration Consultants', 'Visa mount is one of the best &amp; reliable Canada Immigration Consultants in Delhi. We are also providing Study Visa, Working Visa, Tourist Visa &amp; many more.', NULL),
(50, 'canada', 'canada', 'best tour packages  in rohini', '<span>Custom-Designed Vacations&nbsp;</span><strong>Packages</strong><span>&nbsp;Available To Fit Your Needs and Special Interests.</span>', NULL),
(51, 'canada-family-visa', 'Canada Family Visa', 'canada family visa, family visa for canada, canada visa family information form, canada family visa from india', 'Immigrate your family with the help of Canada Family Visa and live a better life. We are known for our excellent services for Canada Immigration in Delhi.', NULL),
(53, 'germany-job-seeker-visa', 'germany IMMIGRATION', 'germany IMMIGRATION', 'germany&nbsp; IMMIGRATION', NULL),
(54, 'hong-kong-qmas-visa', 'Hong Kong Immigration', 'Hong Kong  Immigration', 'UK Immigration', NULL),
(56, 'canada-pnp', 'Canada PNP Program', '', '', NULL),
(57, 'manitoba-pnp', 'Manitoba PNP Program', '', '', NULL),
(59, 'new-brunswick-pnp', '', '', '', NULL),
(61, 'nova-scotia', '', '', '', NULL),
(62, 'saskatchewan-pnp', '', '', '', NULL),
(80, 'alberta-pnp-program', '', '', '', NULL),
(81, 'prince-edward-island', '', '', '', NULL),
(82, 'northwest-territories', '', '', '', NULL),
(83, 'british-columbia', '', '', '', NULL),
(87, 'australian-immigration', 'Australia Immigration | Immigration to Australia | Australia Visa Consultants', 'Australia Immigration, Australia visa consultants, immigration to australia, south australia immigration, australia immigration news, immigration australia', 'Visa Mount is offering services for Australia Immigration &amp; it is based on skills, work experience &amp; qualification. Immigrate to Australia with simple steps.', NULL),
(89, 'australia-occupation-in-demand', '', '', '', NULL),
(90, '65-points-australian-immigration', '', '', '', NULL),
(91, 'employer-nomination-scheme-subclass-visa-186', '', '', '', NULL),
(92, 'skilled-independent-visa-subclass-189', 'Subclass Visa 189 | Skilled Independent Visa (subclass 189) | Visa Mount', 'Subclass Visa 189, skilled independent visa (subclass 189), skilled independent visa (subclass 189) occupation list, subclass 189 visa', 'In Subclass Visa 189, the applicants who are highly skilled &amp; qualified those are in demand by a state or the territory of Australia could go for this visa.&nbsp;', NULL),
(93, 'skilled-nominated-visa-subclass-190', '', '', '', NULL),
(94, 'sponsored-provisional-visa-subclass-489-visa', '', '', '', NULL),
(96, 'canada-pr-visa', 'Canada PR Visa | Canada Immigration | Canada Visa Expert', 'Canada PR Visa Fees, pr visa canada, pr visa for canada, canada pr visa fees, Canada Permanent Visa ', 'Visa mount is offering services for the Canada PR Visa. We are one of the best Immigration Consultants in India &amp; Canada Immigration Expert in New Delhi.', NULL),
(97, 'canada-express-entry-program', 'Express Entry Points Calculator | Canada Points Calculator', 'canada express entry points calculator, express entry points calculator, canada express entry points calculator 2020, express entry canada points calculator', 'With the help of the Canada Express Entry Points Calculator, you can calculate your CRS points and you can apply for the Canada Permanent Residence Visa.', NULL),
(98, 'how-express-entry-works-', '', '', '', NULL),
(99, '#canadapnp', '', '', '', NULL),
(100, 'express-entry-points-calculator', '', '', '', NULL),
(101, 'express-entry-next-draw-prediction', '', '', '', NULL),
(106, 'study-visa', '', '', '', NULL),
(114, 'new-zealand-immigration', '', '', '', NULL),
(115, 'family-category-visa', '', '', '', NULL),
(116, 'relugee-family-support-visa', '', '', '', NULL),
(117, 'parents-retirement-category-visa', '', '', '', NULL),
(118, 'work-to-residence-visa', '', '', '', NULL),
(119, 'residence-from-work-visa', '', '', '', NULL),
(120, 'skilled-migration-visa', '', '', '', NULL),
(121, 'long-term-skilled-shortage-list', '', '', '', NULL),
(122, 'hong-kong-quality-migrant-admission-scheme', '', '', '', NULL),
(123, 'germany-job-seeker-visa', '', '', '', NULL),
(126, 'yukon', '', '', '', NULL),
(147, 'crs-point-calculator', 'CRS Point Calculator 2020', 'CRS Point Calculator 2020', '', NULL),
(151, 'professional-writing', '', '', '', 'INDEX, FOLLOW'),
(152, 'personality-development', '', '', '', 'INDEX, FOLLOW'),
(153, 'moderate-english', '', '', '', 'INDEX, FOLLOW'),
(154, 'extensive-english', '', '', '', 'INDEX, FOLLOW'),
(155, 'ielts-toefl-pte-celpip-oet', '', '', '', 'INDEX, FOLLOW'),
(158, 'absolute-english', '', '', '', 'INDEX, FOLLOW');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(100) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `heading` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bimage` varchar(255) DEFAULT NULL,
  `shomepage` varchar(255) DEFAULT NULL,
  `smenu` varchar(255) DEFAULT NULL,
  `orderby` varchar(255) DEFAULT NULL,
  `duration` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `image`, `name`, `heading`, `url`, `description`, `status`, `bimage`, `shomepage`, `smenu`, `orderby`, `duration`) VALUES
(131, '', 'Absolute English', 'Absolute English', 'absolute-english', '<p>As the term indicates it is an absolute transformational course that makes your potential strong enough in the field of English communication. It empowers you to utislise extremely effective demonstrative skills to leave unforgettable impact on others. When it comes to official correspondence like letter-writing, report-writing and e-mails, etc., your performance will be highly admirable and will bring effective results. Intensive Understanding of English Newspaper will be your asset to show intelligence to the world. Accurate and suitable vocabulary usage will be your identity to the masses.<br />The Course Contents -</p>\r\n<p>Grammar Fundamentals<br />Basic Sentence Making<br />Everyday Dialogues in English<br />Basic Understanding of English Newspaper<br />Interview Handling<br />Role plays<br />Group Discussions and Debates<br />Writing Skills<br />Moderate Understanding of English Newspaper<br />Complex Sentences<br />Demonstrative Skills<br />Official Correspondence<br />Vocabulary Enhancement<br />Customised Professional Language<br />Intensive Understanding of English Newspaper<br />Introduction to Accent</p>\r\n<p>3 Trial Classes Duration 1 hour and 30 minutes</p>', '1', 'bg3 (1).jpg', '1', '1', '', ''),
(31, 'course-img3.jpg', 'IELTS/TOEFL/PTE/CELPIP/OET ', 'IELTS/TOEFL/PTE/CELPIP/OET Coaching', 'ielts-toefl-pte-celpip-oet', '<p>In the coaching of abovementioned exams, utmost attention is given to International Standard of English so that the students can qualify any International English Exam easily because , in such exams, Global Standard of English is checked.</p>\r\n<p>Listening Practice<br />Reading Practice<br />Writing Practice<br />Speaking Practice<br />Mock Tests</p>\r\n<p>3 Trial Classes Duration 1 hour and 30 minutes</p>', '1', 'bg3.jpg', '1', '1', '5', 'Till Exam Date'),
(128, 'anna-chlopecki-1176283.jpg', 'Extensive English', 'Extensive English', 'extensive-english', '<p>If you want to prove your candidature to the corporate world and/or government sector in order to qualify job interviews in either of the sectors then Extensive Course of English is the right answer. You will be trained for communicating in English for different situations of life. When it comes to discussing in a group, you will outshine others as your communication will be distinguished and impactful which will grab the opportunities for you in every such competitive situations. In addition to this, the Extensive English Course makes you capable of writing effectively which will impress others.</p>\r\n<p>The Course Contents -</p>\r\n<p>Grammar Fundamentals<br />Sentence Making<br />Basic Understanding of English Newspaper<br />Everyday Dialogues in English<br />Interview Handling<br />Role Plays<br />Group Discussions<br />Writing Skills<br />Moderate Understanding of English Newspaper</p>\r\n<p>3 Trial Classes Duration 1 hour and 30 minutes</p>\r\n<p>Basic Sentence Making</p>\r\n<p>Everyday Dialogues in English<br />Basic Understanding of English Newspaper</p>\r\n<p>3 Trial Classes Duration 1 hour and 30 minutes</p>', '1', 'bg3.jpg', '1', '1', '4', '4 Months'),
(129, 'brown-brunette-female-finger-41551.jpeg', 'Moderate English', 'Moderate English', 'moderate-english', '<p>This course enables you to use English of daily-use and have basic understandability of English Newspapers. In addition to this, you feel confident in using the language and your brain starts storing the language. Investing time and energy into Moderate English Course leads you to go for further accomplishment in the language.</p>\r\n<p>The Course Contents -</p>\r\n<p>Grammar Fundamentals<br />Basic Sentence Making<br />Everyday Dialogues in English<br />Basic Understanding of English Newspaper</p>\r\n<p>3 Trial Classes Duration 1 hour and 30 minutes</p>\r\n<div><span>&nbsp;</span></div>', '1', 'bg3.jpg', '1', '1', '3', '2 Months'),
(126, 'business-839788_1920.jpg', 'Personality Development', 'Personality Development', 'personality-development', '<p>The world knows you with the way you speak, so, this course intensively works upon your way of speaking i.e. voice &amp; accent. Acquiring global accent in English makes your candidature totally competent for winning the opportunities of international platforms. You are enriched with pleasing etiquette and high thinking to achieve big things and live life with absolute worth.</p>\r\n<p>The Course Contents -</p>\r\n<p>Voice &amp; Accent<br />Confidence building<br />Think Big<br />Etiquette at different situations<br />Customised English Communication</p>\r\n<p><br />3 Trial Classes Duration 1 hour and 30 minutes</p>', '1', 'bg3.jpg', '1', '1', '2', '2 Months'),
(125, 'man-people-space-desk.jpg', 'Professional Writing', 'Professional Writing', 'professional-writing', '<p>This course has been designed to make you an influential writer whose language is impressive and beautiful which, ultimately, develops capability of earning through professional writing assignments in your candidature.</p>\r\n<p>The Course Contents -</p>\r\n<p>Standard Sentences<br />Noting &amp; Drafting<br />British English Vs. American English<br />Global standard of Writing</p>', '1', 'bg3.jpg', '1', '1', '1', '2 / 4 / 6 Months');

-- --------------------------------------------------------

--
-- Table structure for table `sidebarenqiry`
--

CREATE TABLE `sidebarenqiry` (
  `id` int(100) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `message` longtext DEFAULT NULL,
  `course` varchar(255) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `sdate` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sidebarenqiry`
--

INSERT INTO `sidebarenqiry` (`id`, `name`, `phone`, `email`, `message`, `course`, `dob`, `sdate`) VALUES
(12, 'Ravinder', '8930509185', 'ravinderg631@gmail.com', 'hello', 'Professional Writing', '03/21/1999', '21-3-2020'),
(14, 'ajay', '8930509185`', 'ajay9560205422@gmail.com', 'hello', 'Professional Writing', '03/21/1999', '21-3-2020'),
(16, 'Ravinder', '8930509185', 'ravinderg631@gmail.com', 'HELLO', 'Professional Writing', '03/21/1999', '21-3-2020');

-- --------------------------------------------------------

--
-- Table structure for table `site-setting`
--

CREATE TABLE `site-setting` (
  `id` int(100) NOT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `twitter` varchar(255) DEFAULT NULL,
  `youtube` varchar(255) DEFAULT NULL,
  `instagram` varchar(255) DEFAULT NULL,
  `whatsapp` varchar(255) DEFAULT NULL,
  `telegram` varchar(255) DEFAULT NULL,
  `linkdin` varchar(255) DEFAULT NULL,
  `pcolor` varchar(255) DEFAULT NULL,
  `scolor` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `site-setting`
--

INSERT INTO `site-setting` (`id`, `logo`, `facebook`, `twitter`, `youtube`, `instagram`, `whatsapp`, `telegram`, `linkdin`, `pcolor`, `scolor`) VALUES
(1, 'Dushyant World Logo.jpg', 'https://www.facebook.com/Visa-Mount-108191697415655/', 'https://twitter.com/MountVisa', 'https://www.youtube.com/channel/UCi9GmhBo2pXm1K19lFYD-zw/featured?view_as=subscriber', '#', '+919911043666', '', 'https://www.linkedin.com/authwall?trk=bf&trkInfo=AQHUq7_sqCNTmgAAAXAfxNBIMffNCILVTt-IoUUe0m9ZHTwHeqt_zPJiA7Ccwyp7sRN_ZH5V2L468dtbvmgbv4O9FJ-4fyhVoYG0DzHkB7XzC2cku93pDOYBZYJdLEjflqEHxLE=&originalReferer=&sessionRedirect=https%3A%2F%2Fwww.linkedin.com%2Fcom', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `id` int(100) NOT NULL,
  `image` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `heading` varchar(255) DEFAULT NULL,
  `sheading` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`id`, `image`, `url`, `heading`, `sheading`) VALUES
(13, '4.jpg', '#', 'We are partner with global university of CANADA', 'Education Overseas'),
(14, '5.jpg', '#', 'If you want to settle in overseas ??', 'Settle in Overseas'),
(15, 'Study.jpg', '#', 'if you want to study in overseas ??', 'study abroad');

-- --------------------------------------------------------

--
-- Table structure for table `subscribe`
--

CREATE TABLE `subscribe` (
  `id` int(100) NOT NULL,
  `email` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(100) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_gallery`
--

CREATE TABLE `tbl_gallery` (
  `id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_gallery`
--

INSERT INTO `tbl_gallery` (`id`, `image`) VALUES
(74, 'event8.jpg'),
(76, 'event2.jpg'),
(78, 'event4.jpg'),
(84, 'about-us.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_master`
--

CREATE TABLE `tbl_master` (
  `id` int(11) NOT NULL,
  `url` text DEFAULT NULL,
  `page_type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_master`
--

INSERT INTO `tbl_master` (`id`, `url`, `page_type`) VALUES
(9, 'about-us', 'page'),
(15, 'canada', 'country'),
(16, 'canada-family-visa', 'country'),
(18, 'germany-job-seeker-visa', 'country'),
(19, 'hong-kong-qmas-visa', 'country'),
(20, 'canada-pnp', 'country'),
(21, 'manitoba-pnp', 'country'),
(23, 'new-brunswick-pnp', 'country'),
(25, 'nova-scotia', 'country'),
(26, 'saskatchewan-pnp', 'country'),
(32, 'alberta-pnp-program', 'country'),
(33, 'prince-edward-island', 'country'),
(34, 'northwest-territories', 'country'),
(35, 'british-columbia', 'country'),
(39, 'australian-immigration', 'country'),
(41, 'australia-occupation-in-demand', 'country'),
(42, '65-points-australian-immigration', 'country'),
(43, 'employer-nomination-scheme-subclass-visa-186', 'country'),
(44, 'skilled-independent-visa-subclass-189', 'country'),
(45, 'skilled-nominated-visa-subclass-190', 'country'),
(46, 'sponsored-provisional-visa-subclass-489-visa', 'country'),
(48, 'canada-pr-visa', 'country'),
(49, 'canada-express-entry-program', 'country'),
(50, 'how-express-entry-works-', 'country'),
(51, '#canadapnp', 'country'),
(52, 'express-entry-points-calculator', 'country'),
(53, 'express-entry-next-draw-prediction', 'country'),
(58, 'study-visa', 'service'),
(66, 'new-zealand-immigration', 'country'),
(67, 'family-category-visa', 'country'),
(68, 'relugee-family-support-visa', 'country'),
(69, 'parents-retirement-category-visa', 'country'),
(70, 'work-to-residence-visa', 'country'),
(71, 'residence-from-work-visa', 'country'),
(72, 'skilled-migration-visa', 'country'),
(73, 'long-term-skilled-shortage-list', 'country'),
(74, 'hong-kong-quality-migrant-admission-scheme', 'country'),
(75, 'germany-job-seeker-visa', 'country'),
(78, 'yukon', 'country'),
(99, 'crs-point-calculator', 'crs'),
(101, 'professional-writing', 'service'),
(102, 'personality-development', 'service'),
(103, 'moderate-english', 'service'),
(104, 'extensive-english', 'service'),
(105, 'ielts-toefl-pte-celpip-oet', 'service'),
(108, 'absolute-english', 'service');

-- --------------------------------------------------------

--
-- Table structure for table `testimonial`
--

CREATE TABLE `testimonial` (
  `id` int(100) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `cname` varchar(255) DEFAULT NULL,
  `discription` longtext DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testimonial`
--

INSERT INTO `testimonial` (`id`, `image`, `name`, `cname`, `discription`, `status`) VALUES
(18, 'ankur-arora.jpg', 'Ankur Arora                                                                   ', 'IT Professional  , New Delhi, India         ', 'An Institute that has changed my life and motivated me a lot.', '1'),
(17, 'arunima.jpg', 'Arunima ', 'Counselor', 'Very good training presented by Dushyant Sir . Definitely my personality has transformed after this Personality Development Program. I am sure this program will definitely change the life of many.', '1'),
(15, 'neelam-vats.jpg', 'Dr. Neelam Vats', 'Yoga Expert Vienna, Austria                                               ', 'Dushyant World\'s&nbsp; Personality Development Program has speeded up my journey to reach my destination.', '1'),
(16, 'cherry-chawla.jpg', 'Cherry Chawla', 'Actuary, DXC Technologies , New Delhi, India                                                               ', 'If you want to enhance your self - image, decision-making and confidence building at difficult tasks then the right answer is Dushyant World\'s \'Personality&nbsp; Development Program\'.', '1'),
(14, 'ria.jpg', 'Ria Dua', 'Inventory Analyst, Mitre 10 Mega, Auckland, New Zealand                                                                                  ', 'The result of giving Dushyant World a few minutes of your life is that you walk out smarter than what you were when you came in.', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assistment`
--
ALTER TABLE `assistment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blogcat`
--
ALTER TABLE `blogcat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contactenquary`
--
ALTER TABLE `contactenquary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_details`
--
ALTER TABLE `contact_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countrydemo`
--
ALTER TABLE `countrydemo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `crs`
--
ALTER TABLE `crs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `crsform`
--
ALTER TABLE `crsform`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enquiry`
--
ALTER TABLE `enquiry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `front_enquiry`
--
ALTER TABLE `front_enquiry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `modal`
--
ALTER TABLE `modal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newblog`
--
ALTER TABLE `newblog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `page`
--
ALTER TABLE `page`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seo`
--
ALTER TABLE `seo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sidebarenqiry`
--
ALTER TABLE `sidebarenqiry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `site-setting`
--
ALTER TABLE `site-setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscribe`
--
ALTER TABLE `subscribe`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_gallery`
--
ALTER TABLE `tbl_gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_master`
--
ALTER TABLE `tbl_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonial`
--
ALTER TABLE `testimonial`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assistment`
--
ALTER TABLE `assistment`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `blogcat`
--
ALTER TABLE `blogcat`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contactenquary`
--
ALTER TABLE `contactenquary`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `contact_details`
--
ALTER TABLE `contact_details`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `countrydemo`
--
ALTER TABLE `countrydemo`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `crs`
--
ALTER TABLE `crs`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `crsform`
--
ALTER TABLE `crsform`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `enquiry`
--
ALTER TABLE `enquiry`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `front_enquiry`
--
ALTER TABLE `front_enquiry`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `modal`
--
ALTER TABLE `modal`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `newblog`
--
ALTER TABLE `newblog`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `page`
--
ALTER TABLE `page`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `seo`
--
ALTER TABLE `seo`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=159;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=132;

--
-- AUTO_INCREMENT for table `sidebarenqiry`
--
ALTER TABLE `sidebarenqiry`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `site-setting`
--
ALTER TABLE `site-setting`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `subscribe`
--
ALTER TABLE `subscribe`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_gallery`
--
ALTER TABLE `tbl_gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `tbl_master`
--
ALTER TABLE `tbl_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=109;

--
-- AUTO_INCREMENT for table `testimonial`
--
ALTER TABLE `testimonial`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
