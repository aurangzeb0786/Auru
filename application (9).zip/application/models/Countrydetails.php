<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Countrydetails extends CI_Model {
	



public function  selectcountrydetailbyurl($url)
{   
    $this->db->where('url',$url);
	$result=$this->db->get('country_details');
	return $result->result();
}
public function  selectallcountrydetailslist()
{   
    
	$result=$this->db->get('country_details');
	return $result->result();
}

function update($url,$data,$table)
{
	$this->db->where('url',$url);
	return $this->db->update($table,$data);
}



public function  selectcountrydetailbycountry_name($countryname)
{   
    $this->db->where('country_name',$countryname);
	$result=$this->db->get('country_details');
	return $result->result();
}



public function  selectcountrydetailbyservice_name($servicename)
{   
    $this->db->where('service_name',$servicename);
	$result=$this->db->get('services');
	return $result->result();
}







}
