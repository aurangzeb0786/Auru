<?php
class Gallerys extends CI_Model
{
	function selectallbanner() 
	{
		
		$data= $this->db->get("tbl_gallery");
		return $data->result();		
	}
	
	
	function selectactivebanner() 
	{
	    $this->db->order_by('id','desc');
		$this->db->where('status','1');
		$data= $this->db->get("tbl_gallery");  
		return $data->result();		
	}
	
	function selectbannerbyid($id)
	{
		$this->db->where('id', $id);
		$data= $this->db->get('tbl_gallery');
		return $data->result();
	}
	
	function insert($data)
	{
		$result= $this->db->insert('tbl_gallery', $data);
		return $result;
	}
	
	function update($id,$data)
	{
		$this->db->where('id', $id);
		return $this->db->update('tbl_gallery',$data);
	}
	
	function delete($id)
	{
		$this->db->where('id', $id);
		return $this->db->delete('tbl_gallery');
	}
}
?>