<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Services extends CI_Model {
	



public function  selectservicesbyid($id)
{   
    $this->db->where('id',$id);
	$result=$this->db->get('services');
	return $result->result(); 
}

public function  selectservicesbyurl($url)
{   
    $this->db->where('url',$url);
	$result=$this->db->get('services');
	return $result->result(); 
}

public function  selectimmigrationservicesbylimit($limit)
{   
    $this->db->where('show_immigration','1');
    $this->db->where('status','1');
    $this->db->limit($limit);
	$result=$this->db->get('services');
	return $result->result(); 
}


public function  selectimmigrationservicesbyhome()
{   
   
    $this->db->where('shomepage','1');
	$result=$this->db->get('services');
	return $result->result(); 
}

public function  selectimmigrationservicesbymenu()
{   
     
   
    $this->db->where('smenu','1');
	$this->db->order_by('id','desc');
	$result=$this->db->get('services');
	return $result->result(); 
}





public function  selectconsultantservicesbylimit($limit)
{   
    $this->db->where('show_consultant','1');
    $this->db->where('status','1');
    $this->db->limit($limit);
	$result=$this->db->get($table);
	return $result->result(); 
}

public function  selectallhomeserviceslist()
{   
  
  $this->db->order_by('orderby','desc');
    $this->db->limit(6);
	 
    $this->db->where('shomepage','1');
	$result=$this->db->get('services');
	return $result->result();
}

public function  selectallhomeservicescnp()
{   
    $this->db->limit(9);
    $this->db->where('shomepage','1');
	$result=$this->db->get('services');
	return $result->result();
}

public function  selectallserviceslist()
{   
    
	$result=$this->db->get('services');
	return $result->result();
}



public function selectseobyurl($url)
{   
    $this->db->where('url',$url);
	$result=$this->db->get('seo');
	return $result->result();
}


public function selectseobycatcourse($catcourse)
{   
    $this->db->where('catcourse',$catcourse);
	$result=$this->db->get('services');
	return $result->result();
}










}
