<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Homeenquarys extends CI_Model {
	


function  selectallenquary()
{   
    
	$result=$this->db->get('front_enquiry');
	return $result->result();
}













}
