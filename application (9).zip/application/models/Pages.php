<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pages extends CI_Model {
	

function  selectdetailsbyurl($url)
{   
    $this->db->where('url',$url);
	$result=$this->db->get('page');
	return $result->result();
}



function  selectdetailsbyid($id)
{   
    $this->db->where('id',$id);
	$result=$this->db->get('page');
	return $result->result();
}

function  selectallpage()
{   
    
	$result=$this->db->get('page');
	return $result->result();
}


public function  selectallseopage($url)
{   
    $this->db->where('url',$url);
	$result=$this->db->get('seo');
	return $result->result();
}

function update($id,$data,$table)
{
	$this->db->where('id',$id);
	return $this->db->update($table,$data);
}









}
