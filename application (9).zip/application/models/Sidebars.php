<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sidebars extends CI_Model {

function  selectallsitedetail()
{   
    
	$result=$this->db->get('sidebarenqiry');
	return $result->result();
}


// start contact enquiry //
function  selectallcontactenquiry()
{   
    
	$result=$this->db->get('contactenquary');
	return $result->result();
}
// end contact enquiry //

}
