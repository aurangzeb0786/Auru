<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Contactdata extends CI_Model {
	



function  selectdetailsbyid($id)
{   
    $this->db->where('id',$id);
	$result=$this->db->get('contact_details');
	return $result->result();
}
function  selectallsitedetail()
{   
    
	$result=$this->db->get('contact_details');
	return $result->result();
}


}
