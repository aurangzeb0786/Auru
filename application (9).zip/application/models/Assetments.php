<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Assetments extends CI_Model {

function  selectallsitedetail()
{   
    
	$result=$this->db->get('assistment');
	return $result->result();
}




}
