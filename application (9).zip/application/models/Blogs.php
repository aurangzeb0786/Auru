<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blogs extends CI_Model {
	



public function  selectsliderbyurl($url)
{   
    $this->db->where('url',$url);
	$result=$this->db->get('blog'); 
	return $result->result();
}

public function  selectsliderbyid($id)
{   
    $this->db->where('id',$id);
	$result=$this->db->get('blog'); 
	return $result->result();
}

public function  selectallbloglist()
{   
    
	$result=$this->db->get('blog');
	return $result->result();
}

public function  selectablogbylimit($limit)
{   
    $this->db->limit($limit);
	$result=$this->db->get('blog');
	return $result->result();
}


function update($url,$data,$table)
{
	$this->db->where('url',$url);
	return $this->db->update($table,$data);
}

public function  selectblogdetailbyheading($heading)
{   
    $this->db->where('heading',$heading);
	$result=$this->db->get('blog');
	return $result->result();
}

}
