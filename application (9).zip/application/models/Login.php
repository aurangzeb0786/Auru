<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Model {

function adminLogin($username, $password)
	{
		$this->db->where('username', $username);
		$this->db->where('password', $password);	
		$data= $this->db->get("tbl_admin");
		return $data->result();		
	}
	
	


}