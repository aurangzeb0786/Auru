<?php
class Admins extends CI_Model
{

function adminlogin($username,$password)
{
	$this->db->where('username',$username);
	$this->db->where('password',$password);
	$data=$this->db->get("tbl_admin");
	return $data->result();
 
	}
	
function selectAdmin()
{
	$data=$this->db->get("tbl_admin");
	return $data->result;
}
}
