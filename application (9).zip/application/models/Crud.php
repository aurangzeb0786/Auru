<?php
class Crud extends CI_Model

{
	
function insert($table,$data)
{
	$result=$this->db->insert($table,$data);
	return $result;
}

function update($id,$data,$table)
{
	$this->db->where('id',$id);
	return $this->db->update($table,$data);
}

function delete($id,$table)
{
	$this->db->where('id',$id);
	return $this->db->delete($table);
}

function deletebyurl($url,$table)
{
	$this->db->where('url',$url);
	return $this->db->delete($table);
}

public function  selecttablemaster()
{   

	$result=$this->db->get('tbl_master');
	return $result->result(); 
} 

public function  selectcommonbyurl($url)
{   
    $this->db->where('url',$url);
	$result=$this->db->get('tbl_master');
	return $result->result(); 
} 

public function  updatecommontable($url,$data)
{   
	$this->db->where('url',$url);
	return $this->db->update('tbl_master',$data);
} 




public function selectseobyurl($url)
{   
    $this->db->where('url',$url);
	$result=$this->db->get('seo');
	return $result->result();
}



}
