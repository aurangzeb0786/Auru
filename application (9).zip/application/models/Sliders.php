<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sliders extends CI_Model {
	



public function  selectsliderbyid($id)
{   
    $this->db->where('id',$id);
	$result=$this->db->get('slider');
	return $result->result();
}
public function  selectallsliderlist()
{   
    
	$result=$this->db->get('slider');
	return $result->result();
}


}
