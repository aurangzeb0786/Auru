<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Countrys extends CI_Model {
	



public function  selectsliderbyid($id)
{   
    $this->db->where('id',$id);
	$result=$this->db->get('country');
	return $result->result(); 
}

public function  selectsliderbyurl($url)
{   
    $this->db->where('url',$url);
	$result=$this->db->get('country');
	return $result->result(); 
}

public function  selectimmigrationcountrybylimit($limit)
{   
    $this->db->where('show_immigration','1');
    $this->db->where('status','1');
    $this->db->limit($limit);
	$result=$this->db->get('country');
	return $result->result(); 
}

public function  selectconsultantcountrybylimit($limit)
{   
    $this->db->where('show_consultant','1');
    $this->db->where('status','1');
    $this->db->limit($limit);
	$result=$this->db->get('country');
	return $result->result(); 
}

public function  selectallcountrylist()
{   
    
	$result=$this->db->get('country');
	return $result->result();
}




public function selectseobyurl($url)
{   
    $this->db->where('url',$url);
	$result=$this->db->get('seo');
	return $result->result();
}


public function  selectallactivecountrylist()
{   
	$this->db->where('status','1');
	$result=$this->db->get('country');
	return $result->result();
}







}
