<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Subscribe extends CI_Model {
	










public function  selectallsubscribelist()
{   
    
	$result=$this->db->get('subscribe');
	return $result->result();
}















}
