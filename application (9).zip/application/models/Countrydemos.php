<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Countrydemos extends CI_Model {
	

public function selectpnpprogram()
{
    $this->db->where('pmenu',"12");
    $result=$this->db->get('countrydemo');
	return $result->result(); 
}

public function  selectcountrydemobyid($id)
{   
    $this->db->where('id',$id);
	$result=$this->db->get('countrydemo');
	return $result->result(); 
}

public function  selectcountrydemobyurl($url)
{   
    $this->db->where('url',$url);
	$result=$this->db->get($table);
	return $result->result(); 
}

public function  selectcountrydemobylimit($limit)
{   
    $this->db->where('show_consultant','1');
    $this->db->where('status','1');
    $this->db->limit($limit);
	$result=$this->db->get($table);
	return $result->result(); 
}

public function  selectallpopularcountry()
{   
    $this->db->where('shomepage','Yes');
    $this->db->limit(4);
	$result=$this->db->get('countrydemo');
	return $result->result();
}
public function  selectallpopular()
{   
    $this->db->where('spcountry','1');
    $this->db->limit(4);
	$result=$this->db->get('countrydemo');
	return $result->result();
}

public function  selectallcnp()
{   
    $this->db->where('spcountry','1');
    $this->db->limit(8);
	$result=$this->db->get('countrydemo');
	return $result->result();
}

public function  selectallcanadapnp()
{   
    $this->db->where('scpnp','1');
    $this->db->limit(9);
	$result=$this->db->get('countrydemo');
	return $result->result();
}

public function  selectallcountrydemolist()
{   
    
    
    $result=$this->db->where_not_in('id',1);
	$result=$this->db->get('countrydemo');
	return $result->result();
}


public function  selectallactivecountrylist()
{   $this->db->order_by('orderby','asc');
    $result=$this->db->where('pmenu',1);
    
    $result=$this->db->where('status','1');
	$result=$this->db->get('countrydemo');
	return $result->result();
}


public function  selectallactivecountrylistbyparentcat($parent)
{   
    $result=$this->db->where('pmenu',$parent);
    $this->db->where_not_in('url','canada-pnp');
    $result=$this->db->where('status','1');
	$result=$this->db->get('countrydemo');
	return $result->result();
}


public function  selectcountrydetailbyurl($url)
{   
    $this->db->where('url',$url);
	$result=$this->db->get('countrydemo');
	return $result->result(); 
}


public function selectseobyurl($url)
{   
    $this->db->where('url',$url);
	$result=$this->db->get('seo');
	return $result->result();
}











}
