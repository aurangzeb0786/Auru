<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Modals extends CI_Model {
	



function  selectdetailsbyid($id)
{   
    $this->db->where('id',$id);
	$result=$this->db->get('modal');
	return $result->result();
}
function  selectallmodaldetail()
{   
    
	$result=$this->db->get('modal');
	return $result->result();
}


}
