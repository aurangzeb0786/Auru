<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crsforms extends CI_Model {
	



function  selectdetailsbyid($id)
{   
    $this->db->where('id',$id);
	$result=$this->db->get('crsform');
	return $result->result();
}
function  selectallcrsdetail()
{   
    
	$result=$this->db->get('crsform');
	return $result->result();
}


}
