<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Siteeditingss extends CI_Model {

function insert($table,$data)
{
	$result=$this->db->insert($table,$data);
	return $result;
}

function update($id,$data,$table)
{
	$this->db->where('id',$id);
	return $this->db->update($table,$data);
}

function delete($id,$table)
{
	$this->db->where('id',$id);
	return $this->db->delete($table);
}


function  selectdetailsbyid($id)
{   
    $this->db->where('id',$id);
	$result=$this->db->get($table);
	return $result->result();
}
function  selectallsitedetail()
{   
    
	$result=$this->db->get('site-setting');
	return $result->result();
}


// start contact enquiry //
function  selectallcontactenquiry()
{   
    
	$result=$this->db->get('contactenquary');
	return $result->result();
}
// end contact enquiry //

}
