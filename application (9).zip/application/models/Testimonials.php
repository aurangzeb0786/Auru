<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Testimonials extends CI_Model {
	
public function  selecttestimialbyid($id)
{   
    $this->db->where('id',$id);
	$result=$this->db->get('testimonial');
	return $result->result(); 
}

public function  selectalltestominallist()
{   
    
	$result=$this->db->get('testimonial');
	return $result->result();
}















}
