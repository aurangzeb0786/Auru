<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Newblogs extends CI_Model {
	



public function  selectnewblogbyid($id)
{   
    $this->db->where('id',$id);
	$result=$this->db->get('newblog');
	return $result->result(); 
}

public function  selectnewblogbyurl($url)
{   
    $this->db->where('url',$url);
	$result=$this->db->get('newblog');
	return $result->result(); 
}

public function  selectnewblogbypmenu($pmenu)
{   
    $this->db->where('pmenu',$pmenu);
	$result=$this->db->get('newblog');
	return $result->result(); 
}


public function  selectcountrydemobyurl($url)
{   
    $this->db->where('url',$url);
	$result=$this->db->get($table);
	return $result->result(); 
}

public function  selectcountrydemobylimit($limit)
{   
    $this->db->where('show_consultant','1');
    $this->db->where('status','1');
    $this->db->limit($limit);
	$result=$this->db->get($table);
	return $result->result(); 
}

public function  selectallhomecountrydemolist()
{   
    $this->db->limit(6);
	$result=$this->db->get($table);
	return $result->result();
}

public function  selectallnewbloglist()
{   
    
	$result=$this->db->get('newblog');
	return $result->result();
}



public function selectseobyurl($url)
{   
    $this->db->where('url',$url);
	$result=$this->db->get('seo');
	return $result->result();
}











}
