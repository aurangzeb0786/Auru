<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crss extends CI_Model {
	



public function  selectcrsbyid($id)
{   
    $this->db->where('id',$id);
	$result=$this->db->get('crs');
	return $result->result(); 
}

public function  selectcrsbyurl($url)
{   
    $this->db->where('url',$url);
	$result=$this->db->get('crs');
	return $result->result(); 
}

public function  selectimmigrationcrsbylimit($limit)
{   
    $this->db->where('show_immigration','1');
    $this->db->where('status','1');
    $this->db->limit($limit);
	$result=$this->db->get($table);
	return $result->result(); 
}

public function  selectconsultantcrsbylimit($limit)
{   
    $this->db->where('show_consultant','1');
    $this->db->where('status','1');
    $this->db->limit($limit);
	$result=$this->db->get($table);
	return $result->result(); 
}

public function  selectallhomecrslist()
{   
    $this->db->limit(6);
	$result=$this->db->get('crs');
	return $result->result();
}

public function  selectallcrslist()
{   
    
	$result=$this->db->get('crs');
	return $result->result();
}



public function selectseobyurl($url)
{   
    $this->db->where('url',$url);
	$result=$this->db->get('seo');
	return $result->result();
}











}
