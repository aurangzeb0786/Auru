<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blogcats extends CI_Model {
	



public function  selectblogcatbyid($id)
{   
    $this->db->where('id',$id);
	$result=$this->db->get('blogcat');
	return $result->result(); 
}

public function  selectblogcatbyurl($url)
{   
    $this->db->where('url',$url);
	$result=$this->db->get('blogcat');
	return $result->result(); 
}

public function  selectcountrydemobyurl($url)
{   
    $this->db->where('url',$url);
	$result=$this->db->get($table);
	return $result->result(); 
}

public function  selectcountrydemobylimit($limit)
{   
    $this->db->where('show_consultant','1');
    $this->db->where('status','1');
    $this->db->limit($limit);
	$result=$this->db->get($table);
	return $result->result(); 
}

public function  selectallhomecountrydemolist()
{   
    $this->db->limit(6);
	$result=$this->db->get($table);
	return $result->result();
}

public function  selectallblogcatlist()
{   
    
	$result=$this->db->get('blogcat');
	return $result->result();
}



public function selectseobyurl($url)
{   
    $this->db->where('url',$url);
	$result=$this->db->get('seo');
	return $result->result();
}











}
