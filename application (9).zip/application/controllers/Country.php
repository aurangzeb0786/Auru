<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Country extends CI_Controller {
    
	public function add()
	{
		
		
		if(isset($_POST['submit']))
		{
			
			if($_FILES['image']['name']!='')
			{
				
				$bimage =$_FILES['image']['name'];
				$path = 'assets/country/'.$bimage;
				move_uploaded_file($_FILES['image']['tmp_name'] ,$path);
			}
			else
			{
				$bimage =  "";
			}
	
			$data['image'] = $bimage;
            $data['name']=$this->input->post('name');
			$data['url']=$this->input->post('url');
			$data['description']=$this->input->post('description');
			$data['show_consultant']=$this->input->post('show_consultant');
			// $data['show_immigration']=$this->input->post('show_immigration');
			// $data['show_immigration']=$this->input->post('show_immigration');
			$data['status']=$this->input->post('status');

			$this->crud->insert('country',$data);
			
			$seodata['url']=$this->input->post('url');
			$seodata['seotitle']=$this->input->post('seotitle');
			$seodata['keyword']=$this->input->post('keyword');
			$seodata['seodescription']=$this->input->post('seodescription');
			// $seodata['metatag']=$this->input->post('meta-tag');

			$this->crud->insert('seo',$seodata);

			redirect('country/countrylist');
	
		}
		
		$this->load->view('admin/country/add');
	}
	
	
	
	public function countrylist() 
	{
		$data['RESULT']=$this->countrys->selectallcountrylist();
		$this->load->view('admin/country/list',$data);
	}
	
	public function edit()
	{
		$args=func_get_args();
		if(isset($_POST['submit']))
		{

			if($_FILES['image']['name']!='')
			{
				
				$bimage =$_FILES['image']['name'];
				$path = 'assets/country/'.$bimage;
				move_uploaded_file($_FILES['image']['tmp_name'] ,$path);
			}
			else 
			{
				$bimage =  $this->input->post('old-image'); 
			}
	
			$data['image'] = $bimage;
            $data['name']=$this->input->post('name');
			$data['url']=$this->input->post('url');
			$data['description']=$this->input->post('description'); 
			$data['show_consultant']=$this->input->post('show_consultant');
			$data['show_immigration']=$this->input->post('show_immigration');			
			$data['status']=$this->input->post('status');

			$this->crud->update($args[0],$data,'country');

            $seoid=$this->input->post('seoid');
			$seodata['url']=$this->input->post('url');
			$seodata['seotitle']=$this->input->post('seotitle');
			$seodata['keyword']=$this->input->post('keyword');
			$seodata['seodescription']=$this->input->post('seodescription');
			$seodata['metatag']=$this->input->post('meta-tag');


			$this->crud->update($seoid,$seodata,'seo');
			redirect('country/countrylist');
		}
		
		$data['EDITCOUNTRY']=$this->countrys->selectsliderbyid($args[0]); 
		$data['EDITSEO']=$this->countrys->selectseobyurl($data['EDITCOUNTRY'][0]->url); 
		$this->load->view('admin/country/edit',$data);
		
	}
	








	
	// public function edit()
	// {
		 // $args=func_get_args();
		  // if(isset($_POST['submit']))
		// {
			// $data['name']=$this->input->post('name');
			// $data['url']=$this->input->post('url');
			// $data['heading	']=$this->input->post('heading');
			// $data['description']=$this->input->post('description');
			// $data['status']=$this->input->post('status');

		   // $result=$this->pages->update($args[0],$data,'page');
		   
		   // $seodata['url']=$this->input->post('url');
			// $seodata['seotitle']=$this->input->post('seotitle');
			// $seodata['keyword']=$this->input->post('keyword');
			// $seodata['seodescription']=$this->input->post('seodescription');
			
			
		   // $result=$this->pages->update($args[0],$seodata,'seo');
		   
            // redirect ('page/pagelist');
		// }
		
		// $data['EDITENQUIRY']=$this->pages->selectdetailsbyurl($args[0]);
		// $data['SEOEDITENQUIRY']=$this->pages->selectallseopage($args[0]);
		// $this->load->view('pages/edit',$data);
	// }
	
	
	
	
	
	
	
	
	
		public function delete()
	{
		$args=func_get_args();
		
		$this->crud->deletebyurl($args[0],'country');
		$this->crud->deletebyurl($args[0],'seo');
		redirect('country/countrylist');
	}
	
	
	
	
	
	
}