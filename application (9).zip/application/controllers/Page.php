<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Page extends CI_Controller {
    
	public function add()
	{
		
		
		if(isset($_POST['submit']))
		{
			$data['name']=$this->input->post('name');
			$data['url']=$this->input->post('url');
			$data['heading	']=$this->input->post('heading');
			$data['description']=$this->input->post('description');
			$data['status']=$this->input->post('status');
			
			
			$this->crud->insert('page',$data);
			
			$seodata['url']=$this->input->post('url');
			
			$seodata['seotitle']=$this->input->post('seotitle');
			$seodata['keyword']=$this->input->post('keyword');
			$seodata['seodescription']=$this->input->post('seodescription');
			$seodata['metatag']=$this->input->post('meta-tag');
			
			$this->crud->insert('seo',$seodata);

			$common['url'] = $this->input->post('url');
			$common['page_type'] = "page";
			$this->crud->insert('tbl_master',$common); 

			  redirect ('page/pagelist');
			
			
		}
		
		
		$this->load->view('admin/pages/add-page');
	}
	
	
	
	public function pagelist()
	{
		$data['RESULT']=$this->pages->selectallpage();
		$this->load->view('admin/pages/list',$data);
	}
	
	
	public function edit()
	{
		 $args=func_get_args();
		  if(isset($_POST['submit']))
		{
			$data['name']=$this->input->post('name');
			$data['url']=$this->input->post('url');
			$data['heading']=$this->input->post('heading');
			$data['description']=$this->input->post('description');
			$data['status']=$this->input->post('status');
			
		

		   $result=$this->pages->update($args[0],$data,'page');
		   
            $seoid=$this->input->post('seoid');
		    $seodata['url']=$this->input->post('url');
			$seodata['seotitle']=$this->input->post('seotitle');
			$seodata['keyword']=$this->input->post('keyword');
			$seodata['seodescription']=$this->input->post('seodescription');
			
		   $result=$this->pages->update($seoid,$seodata,'seo');


			$common['url'] = $this->input->post('url'); 
			$common['page_type'] = "page";
			$commonurl = $this->input->post('commonurl');
			$this->crud->updatecommontable($commonurl,$common);  		   
		   
            redirect ('page/pagelist');
		}
		
		$data['EDITPAGES']=$this->pages->selectdetailsbyid($args[0]); 
		$data['SEOEDITENQUIRY']=$this->pages->selectallseopage($data['EDITPAGES'][0]->url); 
		
		
		// echo $args[0]; 
		// print_r($data['EDITENQUIRY']);
		// exit; 
		
		
		
		$this->load->view('admin/pages/edit',$data);
	}
	
	
	
	
	
	
	
	
	
		public function delete()
	{
	    
	   
		$args=func_get_args();
		
		$this->crud->deletebyurl($args[0],'page');
		$this->crud->deletebyurl($args[0],'seo');
		$this->crud->deletebyurl($args[0],'tbl_master'); 
		redirect('page/pagelist');
	}
	
	
}