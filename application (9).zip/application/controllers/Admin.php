<?php
class Admin extends CI_controller
{
	function index()
	{
		if(isset($_POST['submit']))
		{
			$username=$this->input->post('username');
			$password=$this->input->post('password');
			
		
			
			$row=$this->admins->adminlogin($username,$password);
			
			if(count($row)==1)
				{
				redirect('admin/dashboard');
				}
		}
		$this->load->view('admin/index');
	}	
		
	function dashboard()

	{

		$this->load->view('admin/dashboard');

	}
	

	
	
	
	
	function logout()

	{

		$this->session->sess_destroy();

		$this->session->set_userdata(array('USERID' => '', 'USERNAME' => '', 'logged_in' => ''));

		$this->session->set_flashdata('message','<div class="alert alert-success">You have been successsully lougout.</div>');

		redirect('/admin/index');

	}
	
	
	
	
	
}	
?>
