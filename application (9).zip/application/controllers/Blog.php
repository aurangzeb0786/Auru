<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blog extends CI_Controller {
    
	public function add()
	{
		
		
		if(isset($_POST['submit']))
		{
			
			if($_FILES['image']['name']!='')
			{
				
				$bimage =$_FILES['image']['name'];
				$path = 'assets/blog/'.$bimage;
				move_uploaded_file($_FILES['image']['tmp_name'] ,$path);
			}
			else
			{
				$bimage =  "";
			}
	
			$data['image'] = $bimage;
            $data['heading']=$this->input->post('heading');
			$data['url']=$this->input->post('url');
			$data['status']=$this->input->post('status');
			$data['description']=$this->input->post('description');
			
			
			
			$this->crud->insert('blog',$data);
			
			$seodata['url']=$this->input->post('url');
			
			$seodata['seotitle']=$this->input->post('seotitle');
			
			$seodata['keyword']=$this->input->post('keyword');
			$seodata['seodescription']=$this->input->post('seodescription');
			$seodata['metatag']=$this->input->post('meta-tag');
			
			$this->crud->insert('seo',$seodata);


			$common['url'] = $this->input->post('url');
			$common['page_type'] = "news";
			$this->crud->insert('tbl_master',$common);



			redirect('blog/bloglist');
			
			
			
		}
		
		
		$this->load->view('admin/blog/add');
	}
	
	
	
	
	
	
	
	
	
	
	public function bloglist()
	{
		$data['RESULT']=$this->blogs->selectallbloglist();
		$this->load->view('admin/blog/list',$data);
	}
	
	


   public function edit()
   {
	   $args=func_get_args();
		if(isset($_POST['submit']))
		{
			if($_FILES['image']['name']!='')
			{
				
				$image =$_FILES['image']['name'];
				$path = 'assets/country/'.$image;
				move_uploaded_file($_FILES['image']['tmp_name'] ,$path);
			}
			
			
			else
			{
			$image =  $this->input->post('old-image');
			}
	
		

			$data['image'] = $image;
		
			$data['heading']=$this->input->post('heading');
			$data['url']=$this->input->post('url');
			$data['status']=$this->input->post('status');
			$data['description']=$this->input->post('description');
				
			$this->blogs->update($args[0],$data,'blog');
			$seodata['url']=$this->input->post('url');
			$seodata['seotitle']=$this->input->post('seotitle');
			$seodata['keyword']=$this->input->post('keyword');
			$seodata['seodescription']=$this->input->post('seodescription');
		    $result=$this->pages->update($args[0],$seodata,'seo');
		   

			$common['url'] = $this->input->post('url');
			$common['page_type'] = "news";
			$commonurl = $this->input->post('commonurl');
			$this->crud->updatecommontable($commonurl,$common);             
			
			redirect('blog/bloglist');
		}
		
		
		$data['EDITBLOG']=$this->blogs->selectsliderbyurl($args[0]);
		$data['SEOEDITENQUIRY']=$this->pages->selectallseopage($args[0]);
		$this->load->view('admin/blog/edit',$data);
   }





	
		public function delete()
	{
		$args=func_get_args();
		
		$this->crud->deletebyurl($args[0],'blog');
		$this->crud->deletebyurl($args[0],'seo');
		$this->crud->deletebyurl($args[0],'tbl_master');
		redirect('blog/bloglist');
	}
	
	

	
	
}