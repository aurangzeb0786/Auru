<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Siteediting extends CI_Controller {
    
	public function setting()
	{
  $args=func_get_args();

    if(isset($_POST['submit']))
		{
			
			$id=$this->input->post('id');

if($_FILES['logo']['name']!='')
{

$bimage =$_FILES['logo']['name'];
$path = 'assets/logo/'.$bimage;
move_uploaded_file($_FILES['logo']['tmp_name'] ,$path);
}
else
{
$bimage =  $this->input->post('old-logo');
}


            $data['logo'] = $bimage; //$_FILES['image']['name']; 
			$data['facebook']=$this->input->post('facebook');
			$data['twitter']=$this->input->post('twitter');
			$data['youtube']=$this->input->post('youtube');
			$data['instagram']=$this->input->post('instagram');
			$data['whatsapp']=$this->input->post('whatsapp');
			$data['telegram']=$this->input->post('telegram');
			$data['linkdin']=$this->input->post('linkdin');
			$data['pcolor']=$this->input->post('pcolor');
			$data['scolor']=$this->input->post('scolor');

			$result=$this->siteeditingss->update($id,$data,'site-setting'); 
			$this->session->set_flashdata('message','<div class="alert alert-success">Record Successfully Updated</div>');
            redirect ('siteediting/setting');
		}
		
		
		
		$data['EDITINVOICE']=$this->siteeditingss->selectallsitedetail();
		$this->load->view('admin/site-editing/setting',$data);
	}
	
	
	
	
	
	
	
	
// 	public function contact()
// 	{
		
// 		if (isset ($_POST['submit'])){
			
			
// 			$len = count($this->input->post('addresshead'));
			
// 			for($i=0; $i<$len; $i++){
				
// 				$data['addresshead']=$this->input->post('addresshead')[$i];
// 			    $data['address']=$this->input->post('address')[$i];
// 			    $data['map']=$this->input->post('map')[$i];
  		
//                 $this->crud->insert('contact_details',$data);
// 			}
			
// 			redirect('siteediting/contact');	
			
			
			
// 		}
		
		
// 		$this->load->view('admin/site-editing/contact-detail');
// 	}
	
	
	public function alldetails()
	{
	    
	    	$data['RESULT']=$this->contactdata->selectallsitedetail();
		$this->load->view('admin/site-editing/detail-list',$data);
	}
	
	
	
	
}