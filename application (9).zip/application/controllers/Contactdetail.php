<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Contactdetail extends CI_Controller {
    
	
	public function contact()
	{
		
		if (isset ($_POST['submit'])){
			
			
			$len = count($this->input->post('addresshead'));
			
			for($i=0; $i<$len; $i++){
				
				$data['addresshead']=$this->input->post('addresshead')[$i];
			    $data['address']=$this->input->post('address')[$i];
			    $data['map']=$this->input->post('map')[$i];
  		    
                $this->crud->insert('contact_details',$data);
			}
			
			
			redirect('siteediting/alldetails');	
			
			
			
			
		}
		
		
		$this->load->view('admin/site-editing/contact-detail');
	}
	
	
	public function alldetails()
	{
		
		$data['RESULT']=$this->contactdata->selectallsitedetail();
		
		

		
		$this->load->view('admin/site-editing/detail-list',$data);
	}
	
	
	

	public function editdetails()
	{
		
  $args=func_get_args();
  
 

    if(isset($_POST['submit']))
		{
			$data['addresshead']=$this->input->post('addresshead');
			$data['address']=$this->input->post('address');
			$data['map']=$this->input->post('map');

			$result=$this->crud->update($args[0],$data,'contact_details');
            redirect ('contactdetail/alldetails	');
		}
       
		
		
		
		$data['EDITENQUIRY']=$this->contactdata->selectdetailsbyid($args[0]);
		$this->load->view('admin/site-editing/detail-edit',$data);
	}
	
	
	
	
	
	
	
	public function delete()
	{
		$args=func_get_args();
		
		$this->crud->delete($args[0],'contact_details');
		redirect('contactdetail/alldetails');
	}
	
	
	
	
// start contact page enquiry //

 public function enquirylist()
 {
	 
	 
	 
	 $data['RESULT']=$this->siteeditingss->selectallcontactenquiry();
	 $this->load->view('admin/site-editing/enquiry',$data);
 }
 
 
 
 
 	public function enquarydelete()
	{
		$args=func_get_args();
		
		$this->crud->delete($args[0],'contactenquary');
		redirect('contactdetail/enquirylist');
	}
	
// end contact page enquiry //
	
	
	
}