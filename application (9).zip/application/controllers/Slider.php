<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Slider extends CI_Controller {
    
	function add()
	{
		
		if(isset($_POST['submit']))
		{		
	if($_FILES['image']['name']!='')
			{
				
				$bimage =$_FILES['image']['name'];
				$path = 'assets/slider/'.$bimage;
				move_uploaded_file($_FILES['image']['tmp_name'] ,$path);
			}
			else
			{
				$bimage =  "";
			}
	
			
			

			$data['image'] = $bimage; //$_FILES['image']['name'];

		
                        $data['url'] = $this->input->post('url');
                         $data['heading'] = $this->input->post('heading');
                          $data['sheading'] = $this->input->post('sheading');
				
			$this->crud->insert('slider',$data);
			redirect('slider/sliderlist');			
			
					
		}
		
		$this->load->view('admin/slider/add');
	}
	
	
	public function sliderlist()
	{
		
		$data['RESULT']=$this->sliders->selectallsliderlist();
		$this->load->view('admin/slider/list',$data);
	}
	
	
	public function edit()
	{
		$args=func_get_args();
		if(isset($_POST['submit']))
		{
			if($_FILES['image']['name']!='')
			{
				
				$image =$_FILES['image']['name'];
				$path = 'assets/slider/'.$image;
				move_uploaded_file($_FILES['image']['tmp_name'] ,$path);
			}
			
			
			else
			{
			$image =  $this->input->post('old-image');
			}
	
		

			$data['image'] = $image;
		
		
             $data['url'] = $this->input->post('url');
             $data['heading'] = $this->input->post('heading');
             $data['sheading'] = $this->input->post('sheading');
             
           
			$this->crud->update($args[0],$data,'slider');
			
			redirect('slider/sliderlist');
		}
		
		$data['EDITSLIDER']=$this->sliders->selectsliderbyid($args[0]); 
		$this->load->view('admin/slider/edit',$data);
		
	}
	
	
	
	
	
	
	public function delete()
	{
		$args=func_get_args();
		
		$this->crud->delete($args[0],'slider');
		redirect('slider/sliderlist');
	}
	
	
	
	
	
	
	
	
}