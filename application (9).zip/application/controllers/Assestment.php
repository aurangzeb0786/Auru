<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Assestment extends CI_Controller {
    
	
	
	
	
// start contact page enquiry //

 public function enquirylist()
 {
	 
	 
	 
	 $data['RESULT']=$this->assetments->selectallsitedetail();
	 $this->load->view('admin/assetment-enquiry/list',$data);
 }
 
 
 
 
 	public function enquarydelete()
	{
		$args=func_get_args();
		
		$this->crud->delete($args[0],'assistment');
		redirect('assestment/enquirylist');
	}
	
// end contact page enquiry //
	
	
	
}