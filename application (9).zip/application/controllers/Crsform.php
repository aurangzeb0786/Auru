<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crsform extends CI_Controller {
    
	
	
	public function alldetails()
	{
	    
	    	$data['RESULT']=$this->crsforms->selectallcrsdetail();
		$this->load->view('admin/crsform-enquiry/list',$data);
	}
	
	public function delete()
	{
		$args=func_get_args();
		
		$this->crud->delete($args[0],'crsform');
		redirect('crsform/alldetails');
	}
	
	
	
	
}