<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Countrydemo extends CI_Controller {
    
	public function add() 
	{
		
		
		if(isset($_POST['submit']))
		{
			
			if($_FILES['image']['name']!='')
			{
				
				$bimage =$_FILES['image']['name'];
				$path = 'assets/countrydemo/'.$bimage;
				move_uploaded_file($_FILES['image']['tmp_name'] ,$path);
			}
			else
			{
				$bimage =  "";
			}



			if($_FILES['bimage']['name']!='')
			{
				
				$bgimage =$_FILES['bimage']['name'];
				$path = 'assets/countrydemo/'.$bgimage;
				move_uploaded_file($_FILES['bimage']['tmp_name'] ,$path);
			}
			else
			{
				$bgimage =  "";
			}	
			
			if($_FILES['flag']['name']!='')
			{
				
				$fimage =$_FILES['flag']['name'];
				$path = 'assets/flag/'.$fimage;
				move_uploaded_file($_FILES['flag']['tmp_name'] ,$path);
			}
			else
			{
				$fimage =  "";
			}		
	
			$data['image'] = $bimage;
			$data['bimage'] = $bgimage;
			$data['flag'] = $fimage;
            $data['name']=$this->input->post('name');
            $data['heading']=$this->input->post('heading');
			$data['url']=$this->input->post('url');
			$data['description']=$this->input->post('description');
			$data['status']=$this->input->post('status');
			$data['alt']=$this->input->post('alt');
			$data['shomepage']=$this->input->post('shomepage');
			$data['spcountry']=$this->input->post('spcountry');
			$data['scpnp']=$this->input->post('scpnp');
			$data['orderby']=$this->input->post('order');
			$data['pmenu']=$this->input->post('pmenu');

			$this->crud->insert('countrydemo',$data);
			
			$seodata['url']=$this->input->post('url');
			$seodata['seotitle']=$this->input->post('seotitle');
			$seodata['keyword']=$this->input->post('keyword');
			$seodata['seodescription']=$this->input->post('seodescription');

			$this->crud->insert('seo',$seodata);

			$common['url'] = $this->input->post('url');
			$common['page_type'] = "country";
			$this->crud->insert('tbl_master',$common); 



			redirect('countrydemo/list');
	
		}
		
		$this->load->view('admin/country-demo/add');
	}
	
	
	
	public function list() 
	{
		$data['RESULT']=$this->countrydemos->selectallcountrydemolist();
		$this->load->view('admin/country-demo/list',$data);
	}
	
	public function edit()
	{
		$args=func_get_args();
		if(isset($_POST['submit']))
		{

			if($_FILES['image']['name']!='')
			{
				
				$bimage =$_FILES['image']['name'];
				$path = 'assets/countrydemo/'.$bimage;
				move_uploaded_file($_FILES['image']['tmp_name'] ,$path);
			}
			else 
			{
				$bimage =  $this->input->post('old-image'); 
			}
			
			
			
				if($_FILES['bimage']['name']!='')
			{
				
				$bgimage =$_FILES['bimage']['name'];
				$path = 'assets/countrydemo/'.$bgimage;
				move_uploaded_file($_FILES['bimage']['tmp_name'] ,$path);
			}
			else
			{
				$bgimage =  $this->input->post('old-bimage'); 
			}	
			
			
			if($_FILES['flag']['name']!='')
			{
				
				$fimage =$_FILES['flag']['name'];
				$path = 'assets/flag/'.$fimage;
				move_uploaded_file($_FILES['flag']['tmp_name'] ,$path);
			}
			else
			{
				$fimage =  $this->input->post('old-flag');
			}			
			
	
			$data['image'] = $bimage;
			$data['bimage'] = $bgimage;
			$data['flag'] = $fimage;
            $data['name']=$this->input->post('name');
            $data['heading']=$this->input->post('heading');
			$data['url']=$this->input->post('url');
			$data['description']=$this->input->post('description');
			$data['status']=$this->input->post('status');
			$data['alt']=$this->input->post('alt');
			$data['shomepage']=$this->input->post('shomepage');
			$data['spcountry']=$this->input->post('spcountry');
			$data['scpnp']=$this->input->post('scpnp');
			$data['orderby']=$this->input->post('order');
			$data['pmenu']=$this->input->post('pmenu');

			$this->crud->update($args[0],$data,'countrydemo');

            $seoid=$this->input->post('seoid');
			$seodata['url']=$this->input->post('url');
			$seodata['seotitle']=$this->input->post('seotitle');
			$seodata['keyword']=$this->input->post('keyword');
			$seodata['seodescription']=$this->input->post('seodescription');
			// $seodata['metatag']=$this->input->post('meta-tag');

			$this->crud->update($seoid,$seodata,'seo');


			$common['url'] = $this->input->post('url');
			$common['page_type'] = "country";
			$commonurl = $this->input->post('commonurl');
			$this->crud->updatecommontable($commonurl,$common);  

			redirect('countrydemo/list');
		}
		
		$data['EDITCOUNTRY']=$this->countrydemos->selectcountrydemobyid($args[0]); 
		$data['EDITSEO']=$this->services->selectseobyurl($data['EDITCOUNTRY'][0]->url); 
		$this->load->view('admin/country-demo/edit',$data);
		
	} 

	
	
	
	
	
	
	
		public function delete()
	{
		$args=func_get_args();
		
		$this->crud->deletebyurl($args[0],'countrydemo');
		$this->crud->deletebyurl($args[0],'seo');
		$this->crud->deletebyurl($args[0],'tbl_master'); 
		redirect('countrydemo/list');
	}
	
	
	
	
	
	
}