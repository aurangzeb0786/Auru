<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Subscribes extends CI_Controller {
    

	
	
	public function list() 
	{
		$data['RESULT']=$this->subscribe->selectallsubscribelist();
		$this->load->view('admin/subscribe/list',$data);
	}
	
	public function delete()
	{
		$args=func_get_args();
		
		$this->crud->delete($args[0],'subscribe');
	
		redirect('subscribes/list');
	}
	
	
	
	
	
	
}