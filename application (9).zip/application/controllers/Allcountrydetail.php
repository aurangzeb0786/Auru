<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Allcountrydetail extends CI_Controller {
    
	
	
	public function allcountrydetails()
	{
		
			if(isset($_POST['submit']))
		{
			$data['country_name']=$this->input->post('country_name');
			$data['heading']=$this->input->post('heading');
			$data['description']=$this->input->post('description');
			$data['url']=$this->input->post('url');
			$data['status']=$this->input->post('status');


			$this->crud->insert('country_details',$data);
			
			$seodata['url']=$this->input->post('url');
			$seodata['seotitle']=$this->input->post('seotitle');
			$seodata['keyword']=$this->input->post('keyword');
			$seodata['seodescription']=$this->input->post('seodescription');
			$seodata['metatag']=$this->input->post('meta-tag');
			
			
			$this->crud->insert('seo',$seodata);


			redirect('allcountrydetail/allcountrylist');
			
			
			
		}
		
	
		
		$data['COUNTRYRESULTS']=$this->countrys->selectallcountrylist();
		$this->load->view('admin/country/allcountrydetails',$data);
	}
	
	
	
	
	
	
	
	
	public function allcountrylist()
	{
		$data['RESULT']=$this->countrydetails->selectallcountrydetailslist();
		$this->load->view('admin/country/all_country_list',$data);
	}










	
	 public function edit()
	{
		 
		 $args=func_get_args();
		  if(isset($_POST['submit']))
		{
			$data['country_name']=$this->input->post('country_name');
			$data['heading']=$this->input->post('heading');
			$data['description']=$this->input->post('description');
			$data['url']=$this->input->post('url');
			$data['status']=$this->input->post('status'); 

		   $result=$this->countrydetails->update($args[0],$data,'country_details');
		   
		    $seodata['url']=$this->input->post('url');
			$seodata['seotitle']=$this->input->post('seotitle');
			$seodata['keyword']=$this->input->post('keyword');
			$seodata['seodescription']=$this->input->post('seodescription');
			$seodata['metatag']=$this->input->post('meta-tag');
			
			
		   $result=$this->countrydetails->update($args[0],$seodata,'seo');
		   
            redirect ('allcountrydetail/allcountrylist');
		}
		
		$data['EDITDETAILS']=$this->countrydetails->selectcountrydetailbyurl($args[0]); 
		$data['SEOEDITENQUIRY']=$this->pages->selectallseopage($args[0]);
		$data['COUNTRYRESULTS']=$this->countrys->selectallcountrylist();
		$this->load->view('admin/country/allcountryedit',$data);
	}
	
	
	
		public function empty()
	{
		$args=func_get_args();
		
		$this->crud->deletebyurl($args[0],'country_details');
		$this->crud->deletebyurl($args[0],'seo');
		redirect('allcountrydetail/allcountrylist');
	}
	
}