<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blogcat extends CI_Controller {
    
	public function add()
	{
		
		
		if(isset($_POST['submit']))
		{
			
			if($_FILES['image']['name']!='')
			{
				
				$bimage =$_FILES['image']['name'];
				$path = 'assets/blogcategory/'.$bimage;
				move_uploaded_file($_FILES['image']['tmp_name'] ,$path);
			}
			else
			{
				$bimage =  "";
			}
		
	
	
			$data['image'] = $bimage;
		
            $data['name']=$this->input->post('name');
             
			$data['url']=$this->input->post('url');
		
			$data['status']=$this->input->post('status');
			$data['alt']=$this->input->post('alt');
			
			
			$data['pmenu']=$this->input->post('pmenu');

			$this->crud->insert('blogcat',$data);
			
			$seodata['url']=$this->input->post('url');
			$seodata['seotitle']=$this->input->post('seotitle');
			$seodata['keyword']=$this->input->post('keyword');
			$seodata['seodescription']=$this->input->post('seodescription');


			$this->crud->insert('seo',$seodata);

			redirect('blogcat/list');
	
		}
		
		$data['RESULT']=$this->blogcats->selectallblogcatlist();
		$this->load->view('admin/blogcat/add',$data);
	}
	
	
	
	public function list() 
	{
		$data['RESULT']=$this->blogcats->selectallblogcatlist();
		$this->load->view('admin/blogcat/list',$data);
	}
	
	public function edit()
	{
		$args=func_get_args();
		if(isset($_POST['submit']))
		{

			if($_FILES['image']['name']!='')
			{
				
				$bimage =$_FILES['image']['name'];
				$path = 'assets/blogcategory/'.$bimage;
				move_uploaded_file($_FILES['image']['tmp_name'] ,$path);
			}
			else 
			{
				$bimage =  $this->input->post('old-image'); 
			}
			
			
	
			$data['image'] = $bimage;
		
            $data['name']=$this->input->post('name');
          
			$data['url']=$this->input->post('url');
			
			$data['status']=$this->input->post('status');
			$data['alt']=$this->input->post('alt');
			
			$data['pmenu']=$this->input->post('pmenu');
			$this->crud->update($args[0],$data,'blogcat');

            $seoid=$this->input->post('seoid');
			$seodata['url']=$this->input->post('url');
			$seodata['seotitle']=$this->input->post('seotitle');
			$seodata['keyword']=$this->input->post('keyword');
			$seodata['seodescription']=$this->input->post('seodescription');
		


			$this->crud->update($seoid,$seodata,'seo');
			redirect('blogcat/list');
		}
		
		$data['EDITBLOGCAT']=$this->blogcats->selectblogcatbyid($args[0]);
	$data['RESULT']=$this->blogcats->selectallblogcatlist();		
		$data['EDITSEO']=$this->services->selectseobyurl($data['EDITBLOGCAT'][0]->url); 
		$this->load->view('admin/blogcat/edit',$data);
		
	}
	








	

	
	
	
	
	
	
	
	
		public function delete()
	{
		$args=func_get_args();
		
		$this->crud->deletebyurl($args[0],'blogcat');
		$this->crud->deletebyurl($args[0],'seo');
		redirect('blogcat/list');
	}
	
	
	
	
	
	
}