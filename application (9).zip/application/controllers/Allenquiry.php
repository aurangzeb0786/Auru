<?php
class  Allenquiry extends CI_Controllers


{




function delete()
	{
		$args=func_get_args();
		$data= $this->image->selectimagebyid($args[0]);
		$path ='media/uploads/images/'.$data[0]->image;
		@unlink($path);
		$this->image->delete($args[0]);
		$this->session->set_flashdata('message','<div class="alert alert-success">Record has been successfully deleted.</div>');
		redirect('index.php/images/listing');
	}
	}
	?>