<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

     private $sitesetting = null;

	 public function __construct(){ 
        parent:: __construct(); 
        $this->sitesetting=$this->siteeditingss->selectallsitedetail();  
    }
			

   function sitemap()
    {

        $data['ALLURL']=$this->crud->selecttablemaster();
        header("Content-Type: text/xml;charset=iso-8859-1");
        $this->load->view("sitemap",$data);
    }


	public function index() 
	{
		
		 if(isset($_POST['submit'])){
		     
		         $message = '<html><body>';
$message .= '<table rules="all" style="border-color: #666;" cellpadding="10">';
$message .= "<tr style='background: #eee;'><td colspan='2'><strong>Dushyant World Home Page Form Enquiry</strong> </td></tr>";
$message .= "<tr><td><strong>Name:</strong> </td><td>" . $_POST['name'] . "</td></tr>";
$message .= "<tr><td><strong>Email:</strong> </td><td>" . $_POST['email'] . "</td></tr>";
$message .= "<tr><td><strong>Phone:</strong> </td><td>" . $_POST['phone'] . "</td></tr>";
$message .= "<tr><td><strong>Message:</strong> </td><td>" . $_POST['message'] . "</td></tr>";
$message .= "</table>";
$message .= "</body></html>";

			$to = 'dushyantworldonline@gmail.com';
			$this->load->library('email');
			$this->email->set_newline("\r\n");
            $this->email->set_mailtype("html");
			$this->email->from('Dushyantworld');
			$this->email->to($to);
			$this->email->subject('Dushyantworld');
			$this->email->message($message);
			$mail= $this->email->send();
		
		
		if($mail)
		{
		  echo '<script>alert("We will contact You Shortly")</script>';
		}
		     
		     
		     
		     
		     
		     
		     
		     
		     
		   
	    $this->form_validation->set_rules('name', 'name', 'required');
        $this->form_validation->set_rules('email', 'email', 'required');
        $this->form_validation->set_rules('phone', 'phone', 'required');
        $this->form_validation->set_rules('course', 'course', 'required');
		$this->form_validation->set_rules('dob', 'dob', 'required');
		$this->form_validation->set_rules('sdate', 'sdate', 'required');
		$this->form_validation->set_rules('message', 'message', 'required');
		 
		$this->form_validation->set_error_delimiters('<div class="invalid-feedback">','</div>');
		
         if ($this->form_validation->run())
        {
           $data['name']=$this->input->post('name');
			$data['email']=$this->input->post('email');
			$data['phone']=$this->input->post('phone');
			$data['course']=$this->input->post('course');
			$data['dob']=$this->input->post('dob');
			$data['sdate']=$this->input->post('sdate');
			$data['message']=$this->input->post('message');
			
			$this->crud->insert('front_enquiry',$data);
			
         }
		 
         else{}
		 
	  }    
	  
		$data['ALLSLIDERS']=$this->sliders->selectallsliderlist();
		$data['ALLCOUNTRY']=$this->countrydemos->selectallactivecountrylist(); 
		$data['SITEDATA']=$this->siteeditingss->selectallsitedetail();   
		$data['ADDRDATA']=$this->contactdata->selectallsitedetail();  
		$data['EDITPAGESS']=$this->pages->selectallpage();
	$data['BLOGFUNC']=$this->newblogs->selectallnewbloglist();
		$data['CRSDETAILS']=$this->crss->selectallcrslist();
	    $data['SERVIC']=$this->services->selectallserviceslist();
	    $data['POPULARCOUNTRY']=$this->countrydemos->selectallpopularcountry();
	     $data['POPULARCNP']=$this->countrydemos->selectallcnp();
	    
		 $data['POPULAR']=$this->countrydemos->selectallpopular();
		  $data['CANADAPNP']=$this->countrydemos->selectallcanadapnp();
		
	    
	       $data['SELECTSERVICECNP']=$this->services->selectallhomeservicescnp();
	      $data['ABOUTUSDETAILS']=$this->pages->selectallpage();
	    $data['SELECTTESTOMINAL']=$this->testimonials->selectalltestominallist();
	    $data['SELECTCOURSES']=$this->services->selectallhomeserviceslist();
	    $data['PNPPROGRAM']=$this->countrydemos->selectpnpprogram();
	   // $data['SHOWHOME']=$this->services->selectimmigrationservicesbyhome();
	    $data['SHOWMENU']=$this->services->selectimmigrationservicesbymenu();
		$data['ALLGALLERY']=$this->gallerys->selectallbanner();  
		
		
		$this->load->view('index',$data);   	
	} 
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	

	public function contact()
	{
	    
	  if(isset($_POST['submit'])){
	      
	      
	      $message = '<html><body>';
$message .= '<table rules="all" style="border-color: #666;" cellpadding="10">';
$message .= "<tr style='background: #eee;'><td colspan='2'><strong>Dushyant World Contact us Form Enquiry</strong> </td></tr>";
$message .= "<tr><td><strong>Name:</strong> </td><td>" . $_POST['name'] . "</td></tr>";
$message .= "<tr><td><strong>Email:</strong> </td><td>" . $_POST['email'] . "</td></tr>";
$message .= "<tr><td><strong>Phone:</strong> </td><td>" . $_POST['phone'] . "</td></tr>";
$message .= "<tr><td><strong>Message:</strong> </td><td>" . $_POST['message'] . "</td></tr>";
$message .= "</table>";
$message .= "</body></html>";

			$to = 'dushyantworldonline@gmail.com';
			$this->load->library('email');
			$this->email->set_newline("\r\n");
            $this->email->set_mailtype("html");
			$this->email->from('Dushyantworld');
			$this->email->to($to);
			$this->email->subject('Dushyantworld');
			$this->email->message($message);
			$mail= $this->email->send();
		
		
		if($mail)
		{
		  echo '<script>alert("We will contact You Shortly")</script>';
		}
	      
	     $this->form_validation->set_rules('name', 'name', 'required');
        $this->form_validation->set_rules('email', 'email', 'required');
        $this->form_validation->set_rules('phone', 'phone', 'required');
        $this->form_validation->set_rules('course', 'course', 'required');
		$this->form_validation->set_rules('dob', 'dob', 'required');
		$this->form_validation->set_rules('sdate', 'sdate', 'required');
		$this->form_validation->set_rules('message', 'message', 'required');
		 
		$this->form_validation->set_error_delimiters('<div class="invalid-feedback">','</div>');
		
         if ($this->form_validation->run())
        {
           $data['name']=$this->input->post('name');
			$data['email']=$this->input->post('email');
			$data['phone']=$this->input->post('phone');
			$data['course']=$this->input->post('course');
			$data['dob']=$this->input->post('dob');
			$data['sdate']=$this->input->post('sdate');
			$data['message']=$this->input->post('message');
			
			$this->crud->insert('contactenquary',$data);
			
         }
		 
         else{}
		 
	  }
	  
	  
	  
	  
	  
	  

	    $data['SITEDATA']=$this->sitesetting;
		$data['ALLCOUNTRY']=$this->countrydemos->selectallactivecountrylist(); 
	    $data['ADDRDATA']=$this->contactdata->selectallsitedetail(); 
		$data['EDITPAGESS']=$this->pages->selectallpage();
		$data['SERVIC']=$this->services->selectallserviceslist();
		$data['BLOGFUNC']=$this->newblogs->selectallnewbloglist();
		 $data['SELECTTESTOMINAL']=$this->testimonials->selectalltestominallist();
		$data['CRSDETAILS']=$this->crss->selectallcrslist();
		$data['SHOWMENU']=$this->services->selectimmigrationservicesbymenu();
		$this->load->view('contact',$data);  
	}



 

	public function service()
	{

		$args=func_get_args(); 
		$row=$this->crud->selectcommonbyurl($args[0]); 
		//echo $row[0]->page_type;

		if ($row[0]->page_type=="country") {
			
			
			
		 if(isset($_POST['submit']))
		{
			
			 $this->form_validation->set_rules('name', 'name', 'required');
        $this->form_validation->set_rules('phone', 'phone', 'required');
        $this->form_validation->set_rules('email', 'email', 'required');
        $this->form_validation->set_rules('message', 'message', 'required');
        $this->form_validation->set_rules('country', 'country', 'required');
		$this->form_validation->set_error_delimiters('<div class="invalid-feedback">','</div>');
			
          if ($this->form_validation->run())
        {
            $data['name']=$this->input->post('name');
			$data['phone']=$this->input->post('phone');
			$data['email']=$this->input->post('email');
			$data['message']=$this->input->post('message');
			$data['country']=$this->input->post('country');
			
			$this->crud->insert('sidebarenqiry',$data);
			
			redirect('welcome/thankyou');
		
         }
         else{}
		 
	  }          	
			
			
		$data['COUNTRYDATA']=$this->countrydemos->selectcountrydetailbyurl($args[0]);
		$data['SITEDATA']=$this->sitesetting;
		$data['ALLCOUNTRY']=$this->countrydemos->selectallactivecountrylist();
		$data['ADDRDATA']=$this->contactdata->selectallsitedetail();
		$data['SERVIC']=$this->services->selectallserviceslist();
		$data['EDITPAGESS']=$this->pages->selectallpage();
		$data['BLOGFUNC']=$this->newblogs->selectallnewbloglist();
		$data['CRSDETAILS']=$this->crss->selectallcrslist();
		 $data['SELECTTESTOMINAL']=$this->testimonials->selectalltestominallist();
		$data['POPULARCOUNTRY']=$this->countrydemos->selectallpopularcountry();
		 $data['SHOWMENU']=$this->services->selectimmigrationservicesbymenu();
		 $data['SEODATA']=$this->crud->selectseobyurl($args[0]);
		$this->load->view('country',$data);

		}

		elseif ($row[0]->page_type=="page") {

		$data['SITEDATA']=$this->sitesetting;
		$data['SEODATA']=$this->services->selectseobyurl($args[0]);  
		$data['ALLCOUNTRY']=$this->countrydemos->selectallactivecountrylist(); 
		$data['ADDRDATA']=$this->contactdata->selectallsitedetail(); 
		$data['SERVIC']=$this->services->selectallserviceslist();
		$data['EDITPAGESS']=$this->pages->selectallpage();
		$data['DETAILSPAGES']=$this->pages->selectdetailsbyurl($args[0]);
		$data['BLOGFUNC']=$this->newblogs->selectallnewbloglist();
		$data['CRSDETAILS']=$this->crss->selectallcrslist();
		 $data['SELECTTESTOMINAL']=$this->testimonials->selectalltestominallist();
		 $data['SHOWMENU']=$this->services->selectimmigrationservicesbymenu();
		$this->load->view('page',$data);  

		}

		elseif ($row[0]->page_type=="service") {
			
	
	
	
	
	
		$data['SERVICEDATA']=$this->services->selectservicesbyurl($args[0]); 
		$data['SEODATA']=$this->services->selectseobyurl($args[0]);  
		$data['SITEDATA']=$this->sitesetting;
		$data['BLOGFUNC']=$this->newblogs->selectallnewbloglist();
		$data['ALLCOUNTRY']=$this->countrydemos->selectallactivecountrylist();
		$data['ADDRDATA']=$this->contactdata->selectallsitedetail();  
		$data['SERVIC']=$this->services->selectallserviceslist();
		$data['SERVICEBG']=$this->services->selectallserviceslist();
		$data['EDITPAGESS']=$this->pages->selectallpage();
	    $data['POPULARCOUNTRY']=$this->countrydemos->selectallpopularcountry();
		$data['SHOWMENU']=$this->services->selectimmigrationservicesbymenu();
		 $data['SELECTTESTOMINAL']=$this->testimonials->selectalltestominallist();
		$data['CRSDETAILS']=$this->crss->selectallcrslist();
		$this->load->view('servicesdetails',$data);			

		}elseif ($row[0]->page_type=="crs") {
			
		$data['SERVICEDATA']=$this->services->selectservicesbyurl($args[0]); 
		$data['SEODATA']=$this->services->selectseobyurl($args[0]);  
		$data['SITEDATA']=$this->sitesetting;
			    $data['POPULARCOUNTRY']=$this->countrydemos->selectallpopularcountry();
		$data['ALLCOUNTRY']=$this->countrydemos->selectallactivecountrylist();
		$data['ADDRDATA']=$this->contactdata->selectallsitedetail();  
		$data['SERVIC']=$this->services->selectallserviceslist();
		$data['SERVICEBG']=$this->services->selectallserviceslist();
		$data['SELECTTESTOMINAL']=$this->testimonials->selectalltestominallist();
		$data['EDITPAGESS']=$this->pages->selectallpage();
		$data['CRSDATA']=$this->crss->selectcrsbyurl($args[0]); 
		$data['BLOGFUNC']=$this->newblogs->selectallnewbloglist();
		$data['CRSDETAILS']=$this->crss->selectallcrslist();
		 $data['SHOWMENU']=$this->services->selectimmigrationservicesbymenu();
		$this->load->view('crspage',$data);

		}elseif ($row[0]->page_type=="news") {
			
		$data['BLOGDATAS']=$this->blogs->selectsliderbyurl($args[0]);
        $data['SITEDATA']=$this->sitesetting;		
		$data['ALLBLOG']=$this->blogs->selectallbloglist();
		$data['ALLCOUNTRY']=$this->countrydemos->selectallactivecountrylist(); 
		$data['ADDRDATA']=$this->contactdata->selectallsitedetail(); 
		$data['SERVIC']=$this->services->selectallserviceslist();
	    $data['BLOGFUNC']=$this->newblogs->selectallnewbloglist();
		$data['SELECTTESTOMINAL']=$this->testimonials->selectalltestominallist();
		$data['SEODATA']=$this->crud->selectseobyurl($args[0]);
		$data['CRSDETAILS']=$this->crss->selectallcrslist();
	    $data['EDITPAGESS']=$this->pages->selectallpage();
	    	    $data['POPULARCOUNTRY']=$this->countrydemos->selectallpopularcountry();
	    $data['SHOWMENU']=$this->services->selectimmigrationservicesbymenu();
		$this->load->view('immigrationpage',$data); 

		}elseif ($row[0]->page_type=="blog") {
			
		$args = func_get_args(); 
		// $data['BLOGDATA']=$this->blogs->selectsliderbyurl($args[0]);
        $data['SITEDATA']=$this->sitesetting;		
		$data['ALLBLOG']=$this->blogs->selectallbloglist();
	    $data['POPULARCOUNTRY']=$this->countrydemos->selectallpopularcountry();
		$data['ALLCOUNTRY']=$this->countrydemos->selectallactivecountrylist(); 
		$data['ADDRDATA']=$this->contactdata->selectallsitedetail(); 
		$data['SERVIC']=$this->services->selectallserviceslist();
		$data['EDITPAGESS']=$this->pages->selectallpage();
		$data['BLOGFUNC']=$this->newblogs->selectnewblogbyurl($args[0]); 
		$data['CRSDETAILS']=$this->crss->selectallcrslist();
		$data['SELECTTESTOMINAL']=$this->testimonials->selectalltestominallist();
		$data['SEODATA']=$this->crud->selectseobyurl($args[0]);
		$data['SHOWMENU']=$this->services->selectimmigrationservicesbymenu();
		$this->load->view('blogdetail',$data); 

		}
		

	}


	public function category()
	{
		$args = func_get_args(); 
	    $data['SITEDATA']=$this->sitesetting;
		$data['ALLCOUNTRY']=$this->countrydemos->selectallactivecountrylist(); 
	    $data['ADDRDATA']=$this->contactdata->selectallsitedetail(); 
		$data['EDITPAGESS']=$this->pages->selectallpage();
		$data['SERVIC']=$this->services->selectallserviceslist();
		$data['BLOGFUNC']=$this->newblogs->selectnewblogbypmenu($args[0]);
		$data['CRSDETAILS']=$this->crss->selectallcrslist();
		$data['SELECTTESTOMINAL']=$this->testimonials->selectalltestominallist();
		$data['SHOWMENU']=$this->services->selectimmigrationservicesbymenu();
		$this->load->view('blog',$data); 		
	}



public function assistment()
{   


  	if(isset($_POST['submit']))
		{
			
			
			
			 if(isset($_POST['submit'])){
		   
	    $this->form_validation->set_rules('title', 'Title', 'required');
        $this->form_validation->set_rules('fname', 'Full Name', 'required');
        $this->form_validation->set_rules('rcountry', 'Country of Residence', 'required');
        $this->form_validation->set_rules('dcountry', 'Destination Country ', 'required');
        $this->form_validation->set_rules('Isdcode', 'ISD Code', 'required');
		$this->form_validation->set_rules('phone', 'Contact No', 'required');
		$this->form_validation->set_rules('email', 'Email ID', 'required');
		$this->form_validation->set_rules('address', 'Address', 'required');
		$this->form_validation->set_rules('city', 'City', 'required');
		$this->form_validation->set_rules('pincode', 'Pincode', 'required');
		$this->form_validation->set_rules('age', 'Age', 'required');
		$this->form_validation->set_rules('hqualification', 'Highest Qualification', 'required');
		$this->form_validation->set_rules('experience', 'Experince (in Years)', 'required');
		$this->form_validation->set_rules('pimmigrate', 'Purpose to Immigrate', 'required');
		$this->form_validation->set_error_delimiters('<div class="invalid-feedback">','</div>');
		
         if ($this->form_validation->run())
        {
           $data['title']=$this->input->post('title');
			$data['fname']=$this->input->post('fname');
			$data['rcountry']=$this->input->post('rcountry');
			$data['dcountry']=$this->input->post('dcountry');
			$data['Isdcode']=$this->input->post('Isdcode');
			$data['phone']=$this->input->post('phone');
			$data['email']=$this->input->post('email');
			$data['address']=$this->input->post('address');
			$data['city']=$this->input->post('city');
			$data['pincode']=$this->input->post('pincode');
			$data['age']=$this->input->post('age');
			$data['hqualification']=$this->input->post('hqualification');
			$data['experience']=$this->input->post('experience');
			$data['pimmigrate']=$this->input->post('pimmigrate');
			$this->crud->insert('assistment',$data);
			redirect('welcome/thankyou');
         }
         else{}
		 
	        	
			
			
			
			
	
		}
		}
    $data['SITEDATA']=$this->sitesetting;
	
		$data['ALLCOUNTRY']=$this->countrydemos->selectallactivecountrylist(); 
		$data['ADDRDATA']=$this->contactdata->selectallsitedetail(); 
		$data['SERVIC']=$this->services->selectallserviceslist();
		$data['EDITPAGESS']=$this->pages->selectallpage();
		 $data['SELECTTESTOMINAL']=$this->testimonials->selectalltestominallist();
		$data['BLOGFUNC']=$this->newblogs->selectallnewbloglist();
		$data['CRSDETAILS']=$this->crss->selectallcrslist();
		$data['SHOWMENU']=$this->services->selectimmigrationservicesbymenu();
		
	$this->load->view('assistment',$data);
}



	public function pages()  
	{
	    $args=func_get_args();
		$data['SITEDATA']=$this->sitesetting;
		$data['SEODATA']=$this->services->selectseobyurl($args[0]);  
		$data['ALLCOUNTRY']=$this->countrydemos->selectallactivecountrylist(); 
		$data['ADDRDATA']=$this->contactdata->selectallsitedetail(); 
		$data['SERVIC']=$this->services->selectallserviceslist();
		$data['EDITPAGESS']=$this->pages->selectallpage();
		$data['DETAILSPAGES']=$this->pages->selectdetailsbyurl($args[0]);
		$data['BLOGFUNC']=$this->newblogs->selectallnewbloglist();
		$data['SELECTTESTOMINAL']=$this->testimonials->selectalltestominallist();
		
		$data['CRSDETAILS']=$this->crss->selectallcrslist();
		$data['SHOWMENU']=$this->services->selectimmigrationservicesbymenu();
		$this->load->view('page',$data);  
	}
 


	public function countrydetails()
	{
		
		
		
		$args = func_get_args();  

		$data['COUNTRYDATA']=$this->countrydemos->selectcountrydetailbyurl($args[0]);
		$data['SITEDATA']=$this->sitesetting;
		$data['ALLCOUNTRY']=$this->countrydemos->selectallactivecountrylist();
		$data['ADDRDATA']=$this->contactdata->selectallsitedetail();
		$data['SERVIC']=$this->services->selectallserviceslist();
		$data['EDITPAGESS']=$this->pages->selectallpage();
		$data['SELECTTESTOMINAL']=$this->testimonials->selectalltestominallist();
		$data['BLOGFUNC']=$this->newblogs->selectallnewbloglist();
		$data['CRSDETAILS']=$this->crss->selectallcrslist();
		 $data['SHOWMENU']=$this->services->selectimmigrationservicesbymenu();
		$this->load->view('country',$data);
	}



	public function country()
	{
		$args = func_get_args();  
		$data['COUNTRYDATA']=$this->countrys->selectsliderbyurl($args[0]);  
		$data['SITEDATA']=$this->sitesetting;
		$data['ALLCOUNTRY']=$this->countrydemos->selectallactivecountrylist();
		$data['ADDRDATA']=$this->contactdata->selectallsitedetail();  
		$data['SERVIC']=$this->services->selectallserviceslist();
		$data['SELECTTESTOMINAL']=$this->testimonials->selectalltestominallist();
	$data['EDITPAGESS']=$this->pages->selectallpage();
	$data['BLOGFUNC']=$this->newblogs->selectallnewbloglist();
		$data['CRSDETAILS']=$this->crss->selectallcrslist();
		 $data['SHOWMENU']=$this->services->selectimmigrationservicesbymenu();
		$this->load->view('maincountry',$data);
	}







	public function immigration()
	{
		$args = func_get_args(); 
		// $data['BLOGDATA']=$this->blogs->selectsliderbyurl($args[0]);
        $data['SITEDATA']=$this->sitesetting;		
		$data['ALLBLOG']=$this->blogs->selectallbloglist();
		$data['ALLCOUNTRY']=$this->countrydemos->selectallactivecountrylist(); 
		$data['ADDRDATA']=$this->contactdata->selectallsitedetail(); 
		$data['SERVIC']=$this->services->selectallserviceslist();
		 $data['EDITPAGESS']=$this->pages->selectallpage();
	$data['BLOGFUNC']=$this->newblogs->selectallnewbloglist();
		$data['CRSDETAILS']=$this->crss->selectallcrslist();
		 $data['SELECTTESTOMINAL']=$this->testimonials->selectalltestominallist();
		 	    $data['POPULARCOUNTRY']=$this->countrydemos->selectallpopularcountry();
		 $data['SHOWMENU']=$this->services->selectimmigrationservicesbymenu();
		$this->load->view('immigration',$data); 
	}
	
	public function immigrationpage()
	{
		$args = func_get_args(); 
		$data['BLOGDATAS']=$this->blogs->selectsliderbyurl($args[0]);
        $data['SITEDATA']=$this->sitesetting;		
		$data['ALLBLOG']=$this->blogs->selectallbloglist();
		$data['ALLCOUNTRY']=$this->countrydemos->selectallactivecountrylist(); 
		$data['ADDRDATA']=$this->contactdata->selectallsitedetail(); 
		$data['SERVIC']=$this->services->selectallserviceslist();
	    $data['BLOGFUNC']=$this->newblogs->selectallnewbloglist();
		$data['CRSDETAILS']=$this->crss->selectallcrslist();
		 $data['SELECTTESTOMINAL']=$this->testimonials->selectalltestominallist();
		 	    $data['POPULARCOUNTRY']=$this->countrydemos->selectallpopularcountry();
	    $data['EDITPAGESS']=$this->pages->selectallpage();
	    $data['SHOWMENU']=$this->services->selectimmigrationservicesbymenu();
		$this->load->view('immigrationpage',$data); 	
		
		
	}

/* start blog */
	public function blog()
	{
		$args = func_get_args(); 
		// $data['BLOGDATA']=$this->blogs->selectsliderbyurl($args[0]);
        $data['SITEDATA']=$this->sitesetting;		
		$data['ALLBLOG']=$this->blogs->selectallbloglist();
		$data['ALLCOUNTRY']=$this->countrydemos->selectallactivecountrylist(); 
		$data['ADDRDATA']=$this->contactdata->selectallsitedetail(); 
		$data['SERVIC']=$this->services->selectallserviceslist();
		 $data['EDITPAGESS']=$this->pages->selectallpage();
		$data['BLOGFUNC']=$this->newblogs->selectallnewbloglist();
		 $data['SELECTTESTOMINAL']=$this->testimonials->selectalltestominallist();
		$data['POPULARCOUNTRY']=$this->countrydemos->selectallpopularcountry();
		$data['CRSDETAILS']=$this->crss->selectallcrslist();
		 $data['SHOWMENU']=$this->services->selectimmigrationservicesbymenu();
		$this->load->view('blog',$data); 
	}
	
	public function blogdeatils()
	{
		$args = func_get_args(); 
		// $data['BLOGDATA']=$this->blogs->selectsliderbyurl($args[0]);
        $data['SITEDATA']=$this->sitesetting;		
		$data['ALLBLOG']=$this->blogs->selectallbloglist();
		$data['ALLCOUNTRY']=$this->countrydemos->selectallactivecountrylist(); 
		$data['ADDRDATA']=$this->contactdata->selectallsitedetail(); 
		$data['SERVIC']=$this->services->selectallserviceslist();
		$data['EDITPAGESS']=$this->pages->selectallpage();
		$data['BLOGFUNC']=$this->newblogs->selectallnewbloglist();
		 $data['SELECTTESTOMINAL']=$this->testimonials->selectalltestominallist();
		$data['CRSDETAILS']=$this->crss->selectallcrslist();
		$data['SHOWMENU']=$this->services->selectimmigrationservicesbymenu();
		$this->load->view('blogdetail',$data); 
	}
	
	
	
/* end blog*/


public function thankyou()
{
    
    
    
    	$args = func_get_args();  
		

		$data['SITEDATA']=$this->sitesetting;
		$data['ALLCOUNTRY']=$this->countrydemos->selectallactivecountrylist();
		$data['ADDRDATA']=$this->contactdata->selectallsitedetail();  
		$data['SERVIC']=$this->services->selectallserviceslist();
		$data['SERVICEBG']=$this->services->selectallserviceslist();
		$data['EDITPAGESS']=$this->pages->selectallpage();
	
		$data['BLOGFUNC']=$this->newblogs->selectallnewbloglist();
		$data['CRSDETAILS']=$this->crss->selectallcrslist();
		 $data['SHOWMENU']=$this->services->selectimmigrationservicesbymenu();
    
$this->load->view('thankyou',$data);
}




















/* start service */
public function allservices()

{  
    $args = func_get_args(); 
    
    
    $data['SITEDATA']=$this->sitesetting;
    $data['ALLCOUNTRY']=$this->countrydemos->selectallactivecountrylist(); 
    $data['ADDRDATA']=$this->contactdata->selectallsitedetail(); 
    $data['SELECTSERVICE']=$this->services->selectallserviceslist();
    $data['SERVIC']=$this->services->selectallserviceslist();
    $data['EDITPAGESS']=$this->pages->selectallpage();
	 $data['SELECTTESTOMINAL']=$this->testimonials->selectalltestominallist();
   $data['BLOGFUNC']=$this->newblogs->selectallnewbloglist();
		$data['CRSDETAILS']=$this->crss->selectallcrslist();
		 $data['SHOWMENU']=$this->services->selectimmigrationservicesbymenu();
    $this->load->view('all-services',$data);
}



	public function servicedetails()
	{
		$args = func_get_args();  
		$data['SERVICEDATA']=$this->services->selectservicesbyurl($args[0]); 
		$data['SEODATA']=$this->services->selectseobyurl($args[0]);  
		$data['SITEDATA']=$this->sitesetting;
		$data['BLOGFUNC']=$this->newblogs->selectallnewbloglist();
		$data['ALLCOUNTRY']=$this->countrydemos->selectallactivecountrylist();
		$data['ADDRDATA']=$this->contactdata->selectallsitedetail();  
		$data['SERVIC']=$this->services->selectallserviceslist();
		$data['SERVICEBG']=$this->services->selectallserviceslist();
		$data['EDITPAGESS']=$this->pages->selectallpage();
		 $data['SELECTTESTOMINAL']=$this->testimonials->selectalltestominallist();
		 $data['SHOWMENU']=$this->services->selectimmigrationservicesbymenu();
		$data['CRSDETAILS']=$this->crss->selectallcrslist();
		$this->load->view('servicesdetails',$data);
	}





	public function crsdetails()
	{
		$args = func_get_args();  
		$data['SERVICEDATA']=$this->services->selectservicesbyurl($args[0]); 
		$data['SEODATA']=$this->services->selectseobyurl($args[0]);  
		$data['SITEDATA']=$this->sitesetting;
		$data['ALLCOUNTRY']=$this->countrydemos->selectallactivecountrylist();
		$data['ADDRDATA']=$this->contactdata->selectallsitedetail();  
		$data['SERVIC']=$this->services->selectallserviceslist();
		 $data['SELECTTESTOMINAL']=$this->testimonials->selectalltestominallist();
		$data['SERVICEBG']=$this->services->selectallserviceslist();
		$data['EDITPAGESS']=$this->pages->selectallpage();
		$data['CRSDATA']=$this->crss->selectcrsbyurl($args[0]); 
		$data['BLOGFUNC']=$this->newblogs->selectallnewbloglist();
		$data['CRSDETAILS']=$this->crss->selectallcrslist();
		 $data['SHOWMENU']=$this->services->selectimmigrationservicesbymenu();
		$this->load->view('crspage',$data);
	}






/* end services */



 public function subscribe()
 {
  	if(isset($_POST['submit']))
		{
		
			$data['email']=$this->input->post('email');
			$this->crud->insert('subscribe',$data);
			redirect('welcome/thankyou');
		}
	    
     
 }
 
  public function modal()
 {
  	if(isset($_POST['submit']))
		
		{   
	        
	      $data['name']=$this->input->post('name');
			$data['phone']=$this->input->post('phone');
			$data['email']=$this->input->post('email');
			$data['message']=$this->input->post('message');
			$data['country']=$this->input->post('country');
			
			$this->crud->insert('modal',$data);
			redirect('welcome/thankyou');
		}
	    
     
 }
 
 
 
  public function crsform()
 {
  	if(isset($_POST['submit']))
		{   
	        
	      $data['name']=$this->input->post('name');
			$data['phone']=$this->input->post('phone');
			$data['email']=$this->input->post('email');
			$data['rcountry']=$this->input->post('rcountry');
			
			 $data['dcountry']=$this->input->post('dcountry');
			$data['experience']=$this->input->post('experience');
			$data['education']=$this->input->post('education');
			$data['reading']=$this->input->post('reading');
			$data['writing']=$this->input->post('writing');
			
			 $data['listening']=$this->input->post('listening');
			$data['speaking']=$this->input->post('speaking');
			$data['age']=$this->input->post('age');
			$data['mstatus']=$this->input->post('mstatus');
			$data['sex']=$this->input->post('sex');
			
			$data['adaptability']=$this->input->post('adaptability');
			$data['message']=$this->input->post('message');
			 $data['SELECTTESTOMINAL']=$this->testimonials->selectalltestominallist();
			
			 $data['SHOWMENU']=$this->services->selectimmigrationservicesbymenu();
			$this->crud->insert('crsform',$data);
			
			
		}
	    
     
 }
 
 
 
 
 public function gallery()
 {
	 $data['SHOWMENU']=$this->services->selectimmigrationservicesbymenu();
	 $data['SITEDATA']=$this->siteeditingss->selectallsitedetail();   
	 $data['SELECTCOURSES']=$this->services->selectallhomeserviceslist();
	 $data['ALLGALLERY']=$this->gallerys->selectallbanner();  
	 $this->load->view('gallery',$data);
 }
 
 
 
 
 
  public function categorypage()
 {
	 $args = func_get_args(); 
	 
	 $data['SHOWMENU']=$this->services->selectimmigrationservicesbymenu();
	 $data['SITEDATA']=$this->siteeditingss->selectallsitedetail();   
	 $data['SELECTCOURSES']=$this->services->selectallhomeserviceslist();
	 $data['ALLGALLERY']=$this->gallerys->selectallbanner();  
	$data['COURSECATEGORY']=$this->services->selectseobycatcourse($args[0]);
	 $this->load->view('category-page',$data);
 }
 
 
   public function allcourses()
 {
	 
	 
	 $data['SHOWMENU']=$this->services->selectimmigrationservicesbymenu();
	 $data['SITEDATA']=$this->siteeditingss->selectallsitedetail();   
	 $data['SELECTCOURSES']=$this->services->selectallhomeserviceslist();
	 $data['ALLGALLERY']=$this->gallerys->selectallbanner();  
	 $data['ALLCOURSES']=$this->services->selectallserviceslist();
	 $this->load->view('all-courses',$data);
 }
 
 
 
 
 public function sidebar()
 {
	   	if(isset($_POST['submit']))
		
		{   
		    
		    
		        $message = '<html><body>';
$message .= '<table rules="all" style="border-color: #666;" cellpadding="10">';
$message .= "<tr style='background: #eee;'><td colspan='2'><strong>Dushyant World sidebar Form Enquiry</strong> </td></tr>";
$message .= "<tr><td><strong>Name:</strong> </td><td>" . $_POST['name'] . "</td></tr>";
$message .= "<tr><td><strong>Email:</strong> </td><td>" . $_POST['email'] . "</td></tr>";
$message .= "<tr><td><strong>Phone:</strong> </td><td>" . $_POST['phone'] . "</td></tr>";
$message .= "<tr><td><strong>Message:</strong> </td><td>" . $_POST['message'] . "</td></tr>";
$message .= "</table>";
$message .= "</body></html>";

			$to = 'dushyantworldonline@gmail.com';
			$this->load->library('email');
			$this->email->set_newline("\r\n");
            $this->email->set_mailtype("html");
			$this->email->from('Dushyantworld');
			$this->email->to($to);
			$this->email->subject('Dushyantworld');
			$this->email->message($message);
			$mail= $this->email->send();
		
		
		if($mail)
		{
		  echo '<script>alert("We will contact You Shortly")</script>';
		  echo '<script>window.location.href="http://dushyantworld.com/"</script>';
		}
		    
		    
		    
		    
	     $data['name']=$this->input->post('name');
			$data['email']=$this->input->post('email');
			$data['phone']=$this->input->post('phone');
			$data['course']=$this->input->post('course');
			$data['dob']=$this->input->post('dob');
			$data['sdate']=$this->input->post('sdate');
			$data['message']=$this->input->post('message');
			
			$this->crud->insert('sidebarenqiry',$data);
		
			
		}
	    
 }
 

}

