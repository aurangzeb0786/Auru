<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Gallery extends CI_Controller 
{
	function listing()
	{

		$data['BANNERDATA']= $this->gallerys->selectallbanner();
		$this->load->view('admin/gallery/list',$data);
	}
	function add() 
	{

		if(isset($_POST['submit']))
		{	
$gallery = $_FILES['image']['name'];
$lenth = count($gallery);
for ($i=0; $i <$lenth ; $i++) { 

	if($_FILES['image']['name']!='') 
			{
				
				$bimage =$_FILES['image']['name'][$i];
				$path = 'media/uploads/gallery/'.$bimage;
				$imgname = str_replace('.webp', '', $bimage);

				move_uploaded_file($_FILES['image']['tmp_name'][$i] ,$path); 
			}
			else
			{
				$bimage =  "";
			}
	
			
			
			$data['image'] = $bimage; //$_FILES['image']['name'];
							
			$this->gallerys->insert($data);		

}
			$this->session->set_flashdata('message','<div class="alert alert-success">Record has been successfully saved.</div>');
			redirect('gallery/listing');			
		}
		$this->load->view('admin/gallery/add');
	}
	function edit()
	{

		$args=func_get_args();
		if(isset($_POST['submit']))
		{
		    
		    	if($_FILES['image']['name']!='')
			{
				
				$image =$_FILES['image']['name'];
				$path = 'media/uploads/gallery/'.$image;
				move_uploaded_file($_FILES['image']['tmp_name'] ,$path);
			}
			else
			{
				$image= $_POST['oldimage'];
			}
	
		    
		
			$data['image'] = $image;
			
							
			$this->gallerys->update($args[0],$data);
			$this->session->set_flashdata('message','<div class="alert alert-success">Record has been successfully updated.</div>');
			redirect('gallery/listing');
		}
		$data['EDITBANNER']= $this->gallerys->selectbannerbyid($args[0]);
		$this->load->view('admin/gallery/edit',$data);
	}
	
	function delete()
	{
		$args=func_get_args();
		$data= $this->gallerys->selectbannerbyid($args[0]);
		$path ='media/uploads/gallery/'.$data[0]->image;
		@unlink($path);
		$this->gallerys->delete($args[0]);
		$this->session->set_flashdata('message','<div class="alert alert-success">Record has been successfully deleted.</div>');
		redirect('gallery/listing');
	}
	

}