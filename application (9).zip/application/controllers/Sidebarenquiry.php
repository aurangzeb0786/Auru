<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sidebarenquiry extends CI_Controller {
    
	
	
	
	
// start contact page enquiry //

 public function enquirylist()
 {
	 
	 
	 
	 $data['RESULT']=$this->sidebars->selectallsitedetail();
	 $this->load->view('admin/sidebar-enquiry/list',$data);
 }
 
 
 
 
 	public function enquarydelete()
	{
		$args=func_get_args();
		
		$this->crud->delete($args[0],'sidebarenqiry');
		redirect('sidebarenquiry/enquirylist');
	}
	
// end contact page enquiry //
	
	
	
}