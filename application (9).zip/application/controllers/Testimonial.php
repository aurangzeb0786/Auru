<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Testimonial extends CI_Controller {
    
	public function add()
	{
		
		
		if(isset($_POST['submit']))
		{
			
			if($_FILES['image']['name']!='')
			{
				
				$bimage =$_FILES['image']['name'];
				$path = 'assets/testimonial/'.$bimage;
				move_uploaded_file($_FILES['image']['tmp_name'] ,$path);
			}
			else
			{
				$bimage =  "";
			}
	
			$data['image'] = $bimage;
            $data['name']=$this->input->post('name');
              $data['cname']=$this->input->post('cname');
			$data['discription']=$this->input->post('discription');
			$data['status']=$this->input->post('status');

			$this->crud->insert('testimonial',$data);
		
	     redirect('testimonial/list');
			
	
		}
		
		$this->load->view('admin/testimonial/add');
	}
	
	
	
	public function list() 
	{
		$data['RESULT']=$this->testimonials->selectalltestominallist();
		$this->load->view('admin/testimonial/list',$data);
	}
	
	public function edit()
	{
		$args=func_get_args();
		if(isset($_POST['submit']))
		{

			if($_FILES['image']['name']!='')
			{
				
				$bimage =$_FILES['image']['name'];
				$path = 'assets/testimonial/'.$bimage;
				move_uploaded_file($_FILES['image']['tmp_name'] ,$path);
			}
			else 
			{
				$bimage =  $this->input->post('old-image'); 
			}
	
			$data['image'] = $bimage;
           $data['name']=$this->input->post('name');
              $data['cname']=$this->input->post('cname');
			$data['discription']=$this->input->post('discription');
			$data['status']=$this->input->post('status');
			$this->crud->update($args[0],$data,'testimonial');


			redirect('testimonial/list');
		}
		
		$data['EDITTESTOMINAL']=$this->testimonials->selecttestimialbyid($args[0]);
		$this->load->view('admin/testimonial/edit',$data);
		
	}
	








	

	
	
	
	
	
	
	
	
		public function delete()
	{
		$args=func_get_args();
		
		$this->crud->delete($args[0],'testimonial');
	
		redirect('testimonial/list');
	}
	
	
	
	
	
	
}