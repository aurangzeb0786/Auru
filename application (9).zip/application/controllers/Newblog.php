<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Newblog extends CI_Controller {
    
	public function add()
	{
		
		
		if(isset($_POST['submit']))
		{
			
			if($_FILES['image']['name']!='')
			{
				
				$bimage =$_FILES['image']['name'];
				$path = 'assets/newblog/'.$bimage;
				move_uploaded_file($_FILES['image']['tmp_name'] ,$path);
			}
			else
			{
				$bimage =  "";
			}



			if($_FILES['bimage']['name']!='')
			{
				
				$bgimage =$_FILES['bimage']['name'];
				$path = 'assets/newblog/'.$bgimage;
				move_uploaded_file($_FILES['bimage']['tmp_name'] ,$path);
			}
			else
			{
				$bgimage =  "";
			}			
	
	
			$data['image'] = $bimage;
			$data['bimage'] = $bgimage;
            $data['name']=$this->input->post('name');
              $data['heading']=$this->input->post('heading');
			$data['url']=$this->input->post('url');
			$data['description']=$this->input->post('description');
			$data['status']=$this->input->post('status');
			$data['alt']=$this->input->post('alt');
			
			$data['shomepage']=$this->input->post('shomepage');
			$data['pmenu']=$this->input->post('pmenu');

			$this->crud->insert('newblog',$data);
			
			$seodata['url']=$this->input->post('url');
			$seodata['seotitle']=$this->input->post('seotitle');
			$seodata['keyword']=$this->input->post('keyword');
			$seodata['seodescription']=$this->input->post('seodescription');

			$this->crud->insert('seo',$seodata);


			$common['url'] = $this->input->post('url');
			$common['page_type'] = "blog";
			$this->crud->insert('tbl_master',$common); 



			redirect('newblog/list');
	
		}
	$data['RESULT']=$this->blogcats->selectallblogcatlist();	
		
		$this->load->view('admin/newblog/add',$data);
	}
	
	
	
	public function list() 
	{
		$data['RESULT']=$this->newblogs->selectallnewbloglist();
		$this->load->view('admin/newblog/list',$data);
	}
	
	public function edit()
	{
		$args=func_get_args();
		if(isset($_POST['submit']))
		{

			if($_FILES['image']['name']!='')
			{
				
				$bimage =$_FILES['image']['name'];
				$path = 'assets/newblog/'.$bimage;
				move_uploaded_file($_FILES['image']['tmp_name'] ,$path);
			}
			else 
			{
				$bimage =  $this->input->post('old-image'); 
			}
			
			
			
				if($_FILES['bimage']['name']!='')
			{
				
				$bgimage =$_FILES['bimage']['name'];
				$path = 'assets/newblog/'.$bgimage;
				move_uploaded_file($_FILES['bimage']['tmp_name'] ,$path);
			}
			else
			{
				$bgimage =  $this->input->post('old-bimage'); 
			}	
	
			$data['image'] = $bimage;
			$data['bimage'] = $bgimage;
            $data['name']=$this->input->post('name');
              $data['heading']=$this->input->post('heading');
			$data['url']=$this->input->post('url');
			$data['description']=$this->input->post('description');
			$data['status']=$this->input->post('status');
			$data['alt']=$this->input->post('alt');
			$data['shomepage']=$this->input->post('shomepage');
			$data['pmenu']=$this->input->post('pmenu');
			$this->crud->update($args[0],$data,'newblog');

            $seoid=$this->input->post('seoid');
			$seodata['url']=$this->input->post('url');
			$seodata['seotitle']=$this->input->post('seotitle'); 
			$seodata['keyword']=$this->input->post('keyword');
			$seodata['seodescription']=$this->input->post('seodescription');
			// $seodata['metatag']=$this->input->post('meta-tag');
			$this->crud->update($seoid,$seodata,'seo');


			$common['url'] = $this->input->post('url'); 
			$common['page_type'] = "blog";
			$commonurl = $this->input->post('commonurl');
			$this->crud->updatecommontable($commonurl,$common);  



			redirect('newblog/list');
		}
		
		$data['EDITNEWBLOG']=$this->newblogs->selectnewblogbyid($args[0]); 
		$data['RESULT']=$this->blogcats->selectallblogcatlist();	
		$data['EDITSEO']=$this->services->selectseobyurl($data['EDITNEWBLOG'][0]->url); 
		$this->load->view('admin/newblog/edit',$data);
		
	}
	








	

	
	
	
	
	
	
	
	
		public function delete()
	{
		$args=func_get_args();
		
		$this->crud->deletebyurl($args[0],'newblog');
		$this->crud->deletebyurl($args[0],'seo');
		$this->crud->deletebyurl($args[0],'tbl_master');
		redirect('newblog/list');
	}
	
	
	
	
	
	
}