<!doctype html>
<html lang="en">
  <head>
       <title><?php echo $SEODATA[0]->seotitle; ?></title>
      <meta name="description" content="<?php echo $SEODATA[0]->seodescription; ?>" />
    <meta name="keywords" content="<?php echo $SEODATA[0]->keyword; ?>" />
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo $SEODATA[0]->seotitle;?></title>
    <meta name="description" content="<?php echo $SEODATA[0]->seodescription;?>">
  <meta name="keywords" content="<?php echo $SEODATA[0]->keyword;?>">
 <?php $this->load->view('include/css.php');?>
</head>

<body>

<?php $this->load->view('include/header');?>
<!--------------------------------------------------- country-head -------------------------->

<section style="background-image:url('<?php echo base_url(); ?>assets/services/<?php echo $SERVICEBG[0]->bimage;?>'); " class="bgheadpic">
    <div class="headclr">
<div class="container">
<div class="row">
<div class="col-md-12">

<h1 class="text-center text-white  mb-0"><?= $SERVICEDATA[0]->name; ?></h1> 

</div>
</div>
</div>
</div>
</section>
<!--------------------------------------------------- Australia Visitor Visa -------------------------->


<section class="pt-5">
<div class="container">
<div class="row">




<div class="col-md-8">
<div class="row"> 

<div class="col-md-12 immigration-new-style service">


<h2 class="font-weight-bold mb-2"><?= $SERVICEDATA[0]->heading; ?></h2>

<p> <?= $SERVICEDATA[0]->description; ?></p>

 
</div>

</div>
</div>











<?php $this->load->view('include/sidebar');?>














</div>
</div>
</section>

<!--------------------------------------------------- Australian Visas Categories: -------------------------->



<!--------------------------------------------------- Have Questions? Look Here -------------------------->




<?php $this->load->view('include/footer');?>
<script>
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("actives");
    var panel = this.nextElementSibling;
    if (panel.style.display === "block") {
      panel.style.display = "none";
    } else {
      panel.style.display = "block";
    }
  });
}
</script>