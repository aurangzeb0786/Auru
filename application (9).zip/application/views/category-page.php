<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <title>Category</title>
    <meta name="description" content="">
  <meta name="keywords" content="">
 <?php $this->load->view('include/css.php');?>
</head>

<style type="text/css">
  span{
    color: #F96921;
  }
</style>

<body>

<?php $this->load->view('include/header');?>
<!--------------------------------------------------- country-head -------------------------->

<section  style="background-image:url(<?php echo base_url(); ?>assets/services/bg3.jpg); " class="bgheadpic">
<div class="headclr">
<div class="container">
<div class="row">
<div class="col-md-12">

<h1 class="text-center text-white h3 mb-0"><?php echo $COURSECATEGORY[0]->catcourse;?></h1> 

</div>
</div>
</div>
</div>
</section>
<!--------------------------------------------------- Australia Visitor Visa -------------------------->


<section class="pt-4">
<div class="container">
<div class="row">



<div class="col-md-12">
<div class="row"> 

<div class="col-md-12 immigration-new-style py-4 px-4 ">
<h2 class="text-center  h3 mb-0"><?php echo $COURSECATEGORY[0]->catcourse;?></h2> 
<div class="row mt-5 ">



<?php foreach($COURSECATEGORY as $data) 
{  ?>




<div class="col-lg-4 coursesheight">
<div class="col-lg-12 p-0">
<div class="course-img" style="background-image:url(<?php echo base_url();?>assets/services/<?php echo $data->image; ?>)">
<div class="course-clr">
<h5><a href="<?php echo $data->url;?>"><?php echo $data->name; ?></a></h5>
<p><?php echo word_limiter($data->description,8); ?></p>
</div>
</div>
</div>
<div class="col-lg-12">
<div class="row p-0">
<div class="col-lg-9  p-0">
<div class="duration">
<p><b>Duration : <?php echo $data->duration; ?></b></p>
</div>
</div>
<div class="col-lg-3  p-0 ">
<div class="vicon">
<a href="<?php echo $data->url;?>"><i class="fa fa-play" aria-hidden="true"></i></a>
</div>
 </div>
</div>
</div>
</div>


<?php } ?>
</div>
</div>

</div>
</div>


</div>
</div>
</section>



<?php $this->load->view('include/footer');?>

