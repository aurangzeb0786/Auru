<!doctype html>
<html class="no-js " lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<meta name="description" content="">
<title>Edit Blog</title>
<?php $this->load->view('admin/includes/css');?>
</head>
<body class="theme-cyan">
<!-- Overlay For Sidebars -->
<div class="overlay"></div>
<?php $this->load->view('admin/includes/topbar');?>

<?php $this->load->view('admin/includes/left-sidebar');?>

<section class="content">
    <div class="block-header">
        <div class="row">
            <div class="col-lg-7 col-md-6 col-sm-12">
                <h2>Edit Blog
                <small class="text-muted"></small>
                </h2>
            </div>
            <div class="col-lg-5 col-md-6 col-sm-12">
                <ul class="breadcrumb float-md-right">
                    <li class="breadcrumb-item"><a href="<?php echo base_url('admin/dashboard');?>"><i class="zmdi zmdi-home"></i> Home</a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Edit Blog</a></li>

                </ul>
            </div>
        </div>
    </div>
    <div class="container-fluid">  
      
        <!-- Masked Input -->
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="header">
                        <h2><strong>Edit</strong> Blog</h2>
                       
                    </div>
                    <div class="body">
                        <div class="demo-masked-input">

						 <form  method="post" enctype="multipart/form-data">
                        <div class="">
                            <div class="control-group ">
                <label class="control-label">Old Image<font color="#FF0000">* </font> </label>
                <div class="controls">
                  <img src="<?php echo base_url(); ?>/media/uploads/gallery/<?php echo $EDITBANNER[0]->image; ?>" width="150" height="100"/>
                  <input type="hidden" name="oldimage" value="<?php echo $EDITBANNER[0]->image; ?>" />
                </div> 
              </div>
                            
							
							
							<div class="col-lg-12 col-md-12"> <b>Image</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"></span>	
                                        <input type="file" name="image" class="form-control"  multiple>
                                    </div>
                                </div>
							
							
						
          


                           



                        </div>
            
                            
                    
                                 <input type="submit" name="submit" class="btn-large" value="Submit">
                            </div>
                        </div>

  


                    </form>
						
                    </div>
                </div>
				</div>
            </div>
        </div>
        <!-- #END# Masked Input -->        
       
    </div>
</section>
<?php $this->load->view('admin/includes/js');?>
</body>
</html>