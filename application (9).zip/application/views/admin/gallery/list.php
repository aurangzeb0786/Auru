<!doctype html>
<html class="no-js " lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<meta name="description" content="">
<title>Gallery list</title>
<?php $this->load->view('admin/includes/css');?>
</head>
<body class="theme-cyan">

<!-- Overlay For Sidebars -->
<div class="overlay"></div>
<?php $this->load->view('admin/includes/topbar');?>
<!-- Left Sidebar -->
<?php $this->load->view('admin/includes/left-sidebar');?>

<section class="content">
    <div class="block-header">
        <div class="row">
            <div class="col-lg-7 col-md-6 col-sm-12">
                <h2>All Gallery
              
                </h2>
            </div>
            <div class="col-lg-5 col-md-6 col-sm-12">
                <ul class="breadcrumb float-md-right">
                    <li class="breadcrumb-item"><a href="<?php echo base_url('admin/dashboard');?>"><i class="zmdi zmdi-home"></i> Home</a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Gallery</a></li>
                    <li class="breadcrumb-item active">All Gallery</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <!-- Exportable Table -->
        <div class="row clearfix">
            <div class="col-lg-12">
                <div class="card">
                    <div class="header">
                        <h2><strong>All</strong> Gallery  </h2>
                      
                    </div>
                    <div class="body">
                          <table class="table" id="example">
                            <thead>
                                <tr>
                                    <th>#</th>
                                   
                                    <th>Image</th>
                                    <th>Edit</th>
                                   
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
<?php $i=0; foreach($BANNERDATA as $data){ $i++; 
			
				?>
                <tr bgcolor="#FFFFFF">
                  <td><?php echo $i; ?></td>
                 
                  <td><img src="<?php echo base_url(); ?>/media/uploads/gallery/<?php echo $data->image; ?>" width="150" height="auto"/></td>
                  <td align="center" class="sb2-2-1-edit">
					<a href="<?php echo base_url('gallery/edit/'.$data->id); ?>"><i class="fa fa-pencil-square-o"></i></a> 
					
					</td>

                  
					
					<td class="sb2-2-1-edit">
					
					<a href="<?php echo base_url('gallery/delete/'.$data->id); ?>" onclick="return confirm('are you sure do you want to delete this record')"><i class="fa fa-trash"></i></a> 
				  </td>
                </tr>
                <?php } ?> 
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- #END# Exportable Table --> 
    </div>
</section>

<?php $this->load->view('admin/includes/js'); ?>
</body>
</html>