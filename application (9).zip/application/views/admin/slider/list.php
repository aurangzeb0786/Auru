<!doctype html>
<html class="no-js " lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<meta name="description" content="">
<title>Slider List</title>
<?php $this->load->view('admin/includes/css');?>
</head>
<body class="theme-cyan">

<!-- Overlay For Sidebars -->
<div class="overlay"></div>
<?php $this->load->view('admin/includes/topbar');?>
<!-- Left Sidebar -->
<?php $this->load->view('admin/includes/left-sidebar');?>

<section class="content">
    <div class="block-header">
        <div class="row">
            <div class="col-lg-7 col-md-6 col-sm-12">
                <h2>All Slider
                
                </h2>
            </div>
            <div class="col-lg-5 col-md-6 col-sm-12">
                <ul class="breadcrumb float-md-right">
                    <li class="breadcrumb-item"><a href="<?php echo base_url('admin/dashboard');?>"><i class="zmdi zmdi-home"></i> Home</a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0);">slider</a></li>
                    <li class="breadcrumb-item active">All slider</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <!-- Exportable Table -->
        <div class="row clearfix">
            <div class="col-lg-12">
                <div class="card">
                    <div class="header">
                        <h2><strong>All</strong> slider </h2>
                      
                    </div>
                    <div class="body">
                        <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                            <thead>
                                <tr>
                                    <th width="">image</th>
                                    <th width="">url</th>
                                    <th width="">Heading</th>
                                    <th width="">Sub Heading</th>
                                    
									<th width="5%">Edit</th>
									<th width="5%">Delete</th>
                                    
                                </tr>
                            </thead>
							<?php foreach($RESULT as $data)
    {?>
                            
                            <tbody>
                                <tr>
                                    <td>
                                        <img src="<?php echo base_url(); ?>assets/slider/<?php echo $data->image; ?>" style="width:200px;">
                                    </td>

                                    <td><?php echo $data->url; ?></td>
                                    <td><?php echo $data->heading; ?></td>
                                    <td><?php echo $data->sheading; ?></td>

									<td><a href="<?php echo base_url('slider/edit/'.$data->id); ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></td>
                                    <td><a href="<?php echo base_url('slider/delete/'.$data->id); ?>"><i class="fa fa-trash-o" aria-hidden="true"></i></td>
                                </tr>
                                
                                
                                
                                
                                
                            </tbody>
	<?php }  ?>
	
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- #END# Exportable Table --> 
    </div>
</section>

<?php $this->load->view('admin/includes/js'); ?>
</body>
</html>