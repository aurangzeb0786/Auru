﻿<!doctype html>
<html class="no-js " lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<meta name="description" content="">
<title>Enquiry - Add</title>
<?php $this->load->view('admin/includes/css');?>
</head>
<body class="theme-cyan">
<!-- Overlay For Sidebars -->
<div class="overlay"></div>
<?php $this->load->view('admin/includes/topbar');?>

<?php $this->load->view('admin/includes/left-sidebar');?>

<section class="content">
    <div class="block-header">
        <div class="row">
            <div class="col-lg-7 col-md-6 col-sm-12">
                <h2>Add Enquiry
                <small class="text-muted">Welcome to Aliya Healthcare</small>
                </h2>
            </div>
            <div class="col-lg-5 col-md-6 col-sm-12">
                <ul class="breadcrumb float-md-right">
                    <li class="breadcrumb-item"><a href="index.html"><i class="zmdi zmdi-home"></i> Home</a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Enquiry</a></li>
                    <li class="breadcrumb-item active">Advanced Enquiry</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container-fluid">
      
        <!-- Masked Input -->
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="header">
                        <h2><strong>Add</strong> Enquiry</h2>
                       
                    </div>
                    <div class="body">
                        <div class="demo-masked-input">
						 <form method="post" >
                            <div class="row clearfix">
							    <div class="col-lg-6 col-md-6"> <b>First Name</b>
                                    <div class="input-group">
                                         <span class="input-group-addon"> </span>
                                        <input type="text" name="name"class="form-control" placeholder="first name">
                                    </div>
                                </div>
								
								   <div class="col-lg-6 col-md-6"> <b>Last Name</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"></span>
                                        <input type="text" name="lastname"class="form-control" placeholder="last name">
                                    </div>
                                </div>
								
								    <div class="col-lg-6 col-md-6"> <b>Date of Birth</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="zmdi zmdi-calendar"></i> </span>
                                        <input type="text" name="dob"class="form-control date" placeholder="Ex: 30/07/2016">
                                    </div>
                                </div>
								
								  <div class="col-lg-6 col-md-6"> <b>Email Address</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="zmdi zmdi-email"></i></span>
                                        <input type="text" name="email" class="form-control email" placeholder="Ex: example@example.com">
                                    </div>
                                </div>
								
								 <div class="col-lg-6 col-md-6"> <b>Mobile Number</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="zmdi zmdi-smartphone"></i></span>
                                        <input type="text" name="number" class="form-control mobile-phone-number" placeholder="Ex: +00 (000) 000-00-00">
                                    </div>
                                </div>
								
								 <div class="col-lg-6 col-md-6"> <b>Alternate Number</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="zmdi zmdi-smartphone"></i></span>
                                        <input type="text" name="altnumber"
										class="form-control mobile-phone-number" placeholder="Ex: +00 (000) 000-00-00">
                                    </div>
                                </div>
								
								
								
                                 <div class="col-lg-6 col-md-6">
                                <b>Gender</b>
                                <select class="form-control show-tick" name="gender">
                                    <option>Select Gender</option>
                                    <option>Ketchup</option>
                                    <option>Relish</option>
                                </select>
                            </div>
                               
							    <div class="col-lg-6 col-md-6">
                                <b>Services</b>
                                <select class="form-control show-tick z-index" data-live-search="true" name="services">
								 <option>Select Service</option>
                                    <option>Trained Attendants</option>
                                    <option>Baby Care</option>
                                    <option>Elder Care</option>
                                </select>
                            </div>
							   
							   <div class="col-sm-12">
                                <div class="form-group">
                                    <div class="form-line">
                                        <textarea rows="4" class="form-control no-resize" name="message" placeholder="Please type what you want..."></textarea>
                                    </div>
                                </div>
                            </div>
							  
							<div class="col-sm-12">
                                <button type="submit" name="submit" class="btn btn-primary btn-round">Submit</button>
                                <button type="reset" class="btn btn-default btn-round btn-simple">Cancel</button>
                            </div>
							  
                            </div>
                        </div>
                    </div>
                </div>
				</div>
            </div>
        </div>
        <!-- #END# Masked Input -->        
       
    </div>
</section>
<?php $this->load->view('admin/includes/js');?>
</body>
</html>