<!doctype html>
<html class="no-js " lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<meta name="description" content="">
<title>Testimonial</title>
<?php $this->load->view('admin/includes/css');?>
</head>
<body class="theme-cyan">
<!-- Overlay For Sidebars -->
<div class="overlay"></div>
<?php $this->load->view('admin/includes/topbar');?>

<?php $this->load->view('admin/includes/left-sidebar');?>

<section class="content">
    <div class="block-header">
        <div class="row">
            <div class="col-lg-7 col-md-6 col-sm-12">
                <h2>Edit Testimonial
                <small class="text-muted"></small>
                </h2>
            </div>
            <div class="col-lg-5 col-md-6 col-sm-12">
                <ul class="breadcrumb float-md-right">
                    <li class="breadcrumb-item"><a href="<?php echo base_url('admin/dashboard');?>"><i class="zmdi zmdi-home"></i> Home</a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Edit Testimonial</a></li>

                </ul>
            </div>
        </div>
    </div>
    <div class="container-fluid"> 
      
        <!-- Masked Input -->
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="header">
                        <h2><strong>Edit</strong> Testimonial</h2>
                       
                    </div>
                    <div class="body">
                        <div class="demo-masked-input">
                        
						 <form method="post" enctype="multipart/form-data">
						
						
						<div class="row clearfix">
						
						
						
						
						<img src="<?php echo base_url(); ?>assets/testimonial/<?php echo $EDITTESTOMINAL[0]->image; ?>" style="width:150px; height:150px;">
						  <input type="hidden" name="old-image" class="form-control" value="<?php echo $EDITTESTOMINAL[0]->image; ?>">
                           
							    <div class="col-lg-12 col-md-12"> <b>Image</b>
                                    <div class="input-group">
                                         <span class="input-group-addon"> </span>
                                        <input type="file" name="image" class="form-control" >
                                    </div>
                                </div>

                                <div class="col-lg-12 col-md-12"> <b>Name</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"></span> 
                                        <input type="text" name="name" class="form-control" value="<?php echo $EDITTESTOMINAL[0]->name; ?>" onkeyup="getUrl(this.value);" required>
                                    </div>
                                </div>
                                 <div class="col-lg-12 col-md-12"> <b>Country Name</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"></span> 
                                        <input type="text" name="cname" class="form-control" value="<?php echo $EDITTESTOMINAL[0]->cname; ?>" onkeyup="getUrl(this.value);" required>
                                    </div>
                                </div>
                                <div class="col-lg-12 col-md-12"> <b>Description</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"></span>  
                                        <textarea class="form-control" name="discription"><?php echo $EDITTESTOMINAL[0]->discription; ?></textarea>
                                    </div>
                                </div>
                                <div class="col-lg-12 col-md-12">
                                <b>Status</b>
                                <select class="form-control show-tick" name="status">
                                    <option <?= ($EDITTESTOMINAL[0]->status=="1")?"selected":""; ?> value="1">Active</option>
                                    <option <?= ($EDITTESTOMINAL[0]->status=="0")?"selected":""; ?> value="0">Deactive</option>
                                </select>
                            </div>	
                            <div class="col-sm-12">
                                <button type="submit" name="submit" class="btn btn-primary btn-round">Submit</button>
                               
                            </div>
							  
                            </div>
                        </div>
                    </div>
                </div>
				</div>
            </div>
        </div>
        <!-- #END# Masked Input -->        
       
    </div>
</section>
<?php $this->load->view('admin/includes/js');?>
</body>
</html>