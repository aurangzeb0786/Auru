<!doctype html>
<html class="no-js " lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<meta name="description" content="">
<title>Contact Detail</title>
<?php $this->load->view('admin/includes/css');?>
</head>
<body class="theme-cyan">
<!-- Overlay For Sidebars -->
<div class="overlay"></div>
<?php $this->load->view('admin/includes/topbar');?>

<?php $this->load->view('admin/includes/left-sidebar');?>

<section class="content">
    <div class="block-header">
        <div class="row">
            <div class="col-lg-7 col-md-6 col-sm-12">
                <h2>Contact Details
                <small class="text-muted"></small>
                </h2>
            </div>
            <div class="col-lg-5 col-md-6 col-sm-12">
                <ul class="breadcrumb float-md-right">
                    <li class="breadcrumb-item"><a href="<?php echo base_url('admin/dashboard');?>"><i class="zmdi zmdi-home"></i> Home</a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Contact Detail</a></li>

                </ul>
            </div>
        </div>
    </div>
    <div class="container-fluid">
      
        <!-- Masked Input -->
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="header">
                        <h2><strong>Contact </strong> Details</h2>
                       
                    </div>
                    <div class="body">
                        <div class="demo-masked-input">
                         
						
						
						
						
						 <form method="post" enctype="multipart/form-data">
						 <input type="hidden" name="id" class="form-control" >
						 
						 
                            <div class="row clearfix">
								
								
								<div class="col-lg-12 col-md-12"> <b>Address  Heading</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-address-card-o" aria-hidden="true"></i></span>	
                                        <input type="text" name="addresshead[]" class="form-control" placeholder="Your Address"  required>
                                    </div>
                                </div>
												
								
								
								<div class="col-lg-12 col-md-12"> <b>Address</b>
                                    <div class="input-group">
                                       
                                         <textarea class="form-control" rows="5"  name="address[]"></textarea>
                                    </div>
                                </div>
								
								<div class="col-lg-12 col-md-12"> <b>Address Map</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-map-marker" aria-hidden="true"></i></span>	
                                         <textarea class="form-control" rows="5" id="comment" name="map[]"></textarea>
                                    </div>
                                </div>								
								 
								
                               <div class="col-md-12" id="appenddays"></div>
							   <a class="btn btn-primary addmor" style="padding: 0 1rem;" onclick="ADD();">Add More Address</a>								
								
								
								
                                 
                               
							    
							   
							   
							  
							<div class="col-sm-12">
                                <button type="submit" name="submit" class="btn btn-primary btn-round">Submit</button>
                               
                            </div>
							  
                            </div>
                        </div>
                    </div>
                </div>
				</div>
            </div>
        </div>
        <!-- #END# Masked Input -->        
       
    </div>
</section>
<?php $this->load->view('admin/includes/js');?>


<script>
function ADD()
{
var x=$('#hdvalueinc').val();
//var str=$('#appenddays').html();

var str='<div id="'+x+'"><div class="col-lg-12 col-md-12"> <b>Address Heading</b><div class="input-group"><span class="input-group-addon"><i class="fa fa-address-card-o" aria-hidden="true"></i></span><input type="text" name="addresshead[]" class="form-control" placeholder="Your Address"  required></div></div><div class="col-lg-12 col-md-12"> <b>Address</b><div class="input-group"><span class="input-group-addon"><i class="fa fa-map-marker" aria-hidden="true"></i></span><textarea class="form-control" rows="5" id="comment" name="address[]"></textarea></div></div><div class="col-lg-12 col-md-12"> <b>Address Map</b><div class="input-group"><span class="input-group-addon"><i class="fa fa-map-marker" aria-hidden="true"></i></span><textarea class="form-control" rows="5" id="comment" name="map[]"></textarea></div></div>	<a class="btn" style="color:#fff;padding:10px; font-size:14px !important; background-color:red" onclick=remove('+x+')>Remove</a></div>';


$('#appenddays').append(str);

x++;
$('#hdvalueinc').val(x);
}


function remove(str)
{

$('#'+str).remove();
}
</script>


</body>
</html>