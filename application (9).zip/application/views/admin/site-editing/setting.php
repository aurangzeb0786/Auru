<!doctype html>
<html class="no-js " lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<meta name="description" content="">
<title>Site Setting</title>
<?php $this->load->view('admin/includes/css');?>
</head>
<body class="theme-cyan">
<!-- Overlay For Sidebars -->
<div class="overlay"></div>
<?php $this->load->view('admin/includes/topbar');?>

<?php $this->load->view('admin/includes/left-sidebar');?>

<section class="content">
    <div class="block-header">
        <div class="row">
            <div class="col-lg-7 col-md-6 col-sm-12">
                <h2>Site Setting
                <small class="text-muted"></small>
                </h2>
            </div>
            <div class="col-lg-5 col-md-6 col-sm-12">
                <ul class="breadcrumb float-md-right">
                    <li class="breadcrumb-item"><a href="<?php echo base_url('admin/dashboard');?>"><i class="zmdi zmdi-home"></i> Home</a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Site Setting</a></li>

                </ul>
            </div>
        </div>
    </div>
    <div class="container-fluid">
      
        <!-- Masked Input -->
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12"> 
                <div class="card">
                    <div class="header">
                        <h2><strong>Site</strong> Setting</h2>
                       
                    </div>
                    <div class="body">
                        <div class="demo-masked-input">
                         
						<?= $this->session->flashdata('message'); ?>
						
						
						
						 <form method="post" enctype="multipart/form-data">
						 <input type="hidden" name="id" class="form-control" value="<?php echo $EDITINVOICE[0]->id; ?>">

						 <img src="<?php echo base_url(); ?>assets/logo/<?php echo $EDITINVOICE[0]->logo ?>" style="width:200px; padding: 15px 0;">

						  <input type="hidden" name="old-logo" class="form-control" value="<?php echo $EDITINVOICE[0]->logo ; ?>">
                            <div class="row clearfix">
							    <div class="col-lg-6 col-md-6"> <b>Logo</b>
                                    <div class="input-group">
                                         <span class="input-group-addon"> </span>
                                        <input type="file" name="logo" class="form-control" >
                                    </div>
                                </div>
								

								
								    <div class="col-lg-6 col-md-6"> <b>Facebook Link</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="zmdi zmdi-facebook"></i> </span>
                                        <input type="text" name="facebook"class="form-control" placeholder="Your Facebook Link" value="<?php echo $EDITINVOICE[0]->facebook; ?>" >
                                    </div>
                                </div>
								
								  <div class="col-lg-6 col-md-6"> <b>Twitter</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="zmdi zmdi-twitter"></i></span>
                                        <input type="text" name="twitter" class="form-control" placeholder="Your Twitter Link" value="<?php echo $EDITINVOICE[0]->twitter; ?>" >
                                    </div>
                                </div>
								
								 <div class="col-lg-6 col-md-6"> <b>Youtube</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="zmdi zmdi-youtube"></i></span>	
                                        <input type="text" name="youtube" class="form-control" placeholder="Your Youtube Link" value="<?php echo $EDITINVOICE[0]->youtube; ?>" >
                                    </div>
                                </div>
								
								 <div class="col-lg-6 col-md-6"> <b>Instagram</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="zmdi zmdi-instagram"></i></span>	
                                        <input type="text" name="instagram" class="form-control" placeholder="Your Instagram Link" value="<?php echo $EDITINVOICE[0]->instagram; ?>" >
                                    </div>
                                </div>
								 <div class="col-lg-6 col-md-6"> <b>WhatsApp No</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="zmdi zmdi-whatsapp"></i></span>	
                                        <input type="text" name="whatsapp" class="form-control" placeholder="Your WhatsApp Number" value="<?php echo $EDITINVOICE[0]->whatsapp; ?>" >
                                    </div>
                                </div>
								
								<div class="col-lg-6 col-md-6"> <b>Telegram</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-telegram"></i></span>	
                                        <input type="text" name="telegram" class="form-control" placeholder="Your Telegram Link" value="<?php echo $EDITINVOICE[0]->telegram; ?>" >
                                    </div>
                                </div>
								
								<div class="col-lg-6 col-md-6"> <b>Linkdin</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-linkedin" aria-hidden="true"></i></span>	
                                        <input type="text" name="linkdin" class="form-control" placeholder="Your Linkdin Link" value="<?php echo $EDITINVOICE[0]->linkdin; ?>" >
                                    </div>
                                </div>
<!-- 								<div class="col-lg-6 col-md-6"> <b>Primary Color</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-paint-brush"></i></span>	
                                        <input type="color" name="pcolor" value="<?php echo $EDITINVOICE[0]->pcolor; ?>" class="form-control" placeholder="select Primary Color" >
                                    </div>
                                </div>
								<div class="col-lg-6 col-md-6"> <b>Secondary Color</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-paint-brush"></i></span>	
                                        <input type="color" name="scolor" class="form-control" placeholder="select Secondary Color " value="<?php echo $EDITINVOICE[0]->scolor; ?>" >
                                    </div>
                                </div> -->
								
								 
								
								
								
								
								
                                 
                               
							    
							   
							   
							  
							<div class="col-sm-12">
                                <button type="submit" name="submit" class="btn btn-primary btn-round">Submit</button>
                               
                            </div>
							  
                            </div>
                        </div>
                    </div>
                </div>
				</div>
            </div>
        </div>
        <!-- #END# Masked Input -->        
       
    </div>
</section>
<?php $this->load->view('admin/includes/js');?>
</body>
</html>