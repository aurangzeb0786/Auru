<!doctype html>
<html class="no-js " lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<meta name="description" content="">
<title>Contact- All</title>
<?php $this->load->view('admin/includes/css');?>
</head>
<body class="theme-cyan">

<!-- Overlay For Sidebars -->
<div class="overlay"></div>
<?php $this->load->view('admin/includes/topbar');?>
<!-- Left Sidebar -->
<?php $this->load->view('admin/includes/left-sidebar');?>

<section class="content">
    <div class="block-header">
        <div class="row">
            <div class="col-lg-7 col-md-6 col-sm-12">
                <h2>All Contact Details
                <small class="text-muted">Welcome to </small>
                </h2>
            </div>
            <div class="col-lg-5 col-md-6 col-sm-12">
                <ul class="breadcrumb float-md-right">
                    <li class="breadcrumb-item"><a href="index.html"><i class="zmdi zmdi-home"></i> Home</a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Enquiry</a></li>
                    <li class="breadcrumb-item active">All Enquiry</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <!-- Exportable Table -->
        <div class="row clearfix">
            <div class="col-lg-12">
                <div class="card">
                    <div class="header">
                        <h2><strong>All</strong> Enquiry </h2>
                      
                    </div>
                    <div class="body">
                        <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                            <thead>
                                <tr>
                                    <th>Address Heading</th>
                                    <th>Address</th>
                                    
									<th>Edit</th>
									<th>Delete</th>
                                    
                                </tr>
                            </thead>
                            <?php foreach($RESULT as $data)
    { ?>
                            <tbody>
                                <tr>
                                    <td><?php echo $data->addresshead; ?></td>
                                    <td><?php echo $data->address; ?></td>

									<td><a href="<?php echo base_url('contactdetail/editdetails/'.$data->id);?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></td>
                                    <td><a href="<?php echo base_url('contactdetail/delete/'.$data->id);?>"><i class="fa fa-trash-o" aria-hidden="true"></i></td>
                                </tr>
                                
                                
                                
                                
                                
                            </tbody>
	<?php } ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- #END# Exportable Table --> 
    </div>
</section>

<?php $this->load->view('admin/includes/js'); ?>
</body>
</html>