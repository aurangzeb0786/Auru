
<!-- Top Bar -->
<nav class="navbar">
    <div class="col-12">        
        <div class="navbar-header custumclrss">
            <a href="javascript:void(0);" class="bars"></a>
            <a class="navbar-brand" href="index.html"><span class="m-l-10 custumclr">Dushyant World</span></a>
        </div>
        <ul class="nav navbar-nav navbar-left">
            <!--<li><a href="javascript:void(0);" class="ls-toggle-btn" data-close="true"><i class="zmdi zmdi-swap"></i></a></li>            -->
            <!--<li class="hidden-sm-down">-->
            <!--    <div class="input-group">-->
            <!--        <input type="text" class="form-control" placeholder="Search...">-->
            <!--        <span class="input-group-addon">-->
            <!--            <i class="zmdi zmdi-search"></i>-->
            <!--        </span>-->
            <!--    </div>-->
            <!--</li>-->
        </ul>
        <ul class="nav navbar-nav navbar-right">
            
            
            <li>
                <a href="javascript:void(0);" class="fullscreen hidden-sm-down" data-provide="fullscreen" data-close="true"><i class="zmdi zmdi-fullscreen"></i></a>
            </li>
            <li><a href="<?php echo base_url('admin/logout');?>" class="mega-menu" data-close="true"><i class="zmdi zmdi-power"></i></a></li>
             </ul>
    </div>
</nav>

