 <!-- Left Sidebar -->
<aside id="leftsidebar" class="sidebar">
    <div class="menu">
        <ul class="list">
           
        
            <li> <a href="<?php echo base_url('admin/dashboard');?>"><i class="zmdi zmdi-home"></i><span>Dashboard</span></a>
            </li>
			<li> <a href="<?php echo base_url('siteediting/setting');?>"><i class="zmdi zmdi-calendar-check"></i><span>Site Setting</span></a>
            </li>
		    <!--<li> <a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-calendar-check"></i><span>Contact Details</span> </a>-->
      <!--          <ul class="ml-menu">-->
      <!--              <li><a href="<?php echo base_url('contactdetail/contact');?>">Add Details</a></li>-->
      <!--              <li><a href="<?php echo base_url('contactdetail/alldetails');?>">All Details</a></li>-->
      <!--          </ul>-->
      <!--      </li>-->
			
			 <li> <a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-calendar-check"></i><span>Page</span> </a>
                <ul class="ml-menu">
                    <li><a href="<?php echo base_url('page/add');?>">Add Page</a></li>
                    <li><a href="<?php echo base_url('page/pagelist');?>">All Page</a></li>
                </ul>
            </li>


       	

<!-- <li> <a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-calendar-check"></i><span>Country</span> </a>
               <ul class="ml-menu">
                  <li><a href="<?php echo base_url('country/add'); ?>">Add Country</a></li>
				  <li><a href="<?php echo base_url('country/countrylist');?>">All Country</a></li>
				<li><a href="<?php echo base_url('allcountrydetail/allcountrydetails');?>">Add Country Details</a></li>
			<li><a href="<?php echo base_url('allcountrydetail/allcountrylist');?>">All Country Details</a></li>
            </ul>
          </li>-->
            
            
            
            <li> <a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-calendar-check"></i><span>Courses</span> </a>
                <ul class="ml-menu">
                    <li><a href="<?php echo base_url('service/add'); ?>">Add Courses</a></li>
                    <li><a href="<?php echo base_url('service/list'); ?>">All Courses</a></li>
                </ul>
            </li>
			
	
            
            
        
            
            
            
            

			
			 <li> <a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-calendar-check"></i><span>Blog</span> </a>
                <ul class="ml-menu">
                    <li><a href="<?php echo base_url('blog/add');?>">Add Blog</a></li>
                    <li><a href="<?php echo base_url('blog/bloglist');?>">All Blog</a></li>
                </ul>
            </li>
		
			
				<li> <a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-calendar-check"></i><span>Gallery</span> </a>
                <ul class="ml-menu">
                    <li><a href="<?php echo base_url('gallery/add');?>">Add Gallery</a></li>
                    <li><a href="<?php echo base_url('gallery/listing');?>">All Gallery</a></li>
                </ul>
            </li>
			
			
			 <li> <a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-calendar-check"></i><span>Testimonial</span> </a>
                <ul class="ml-menu">
                    <li><a href="<?php echo base_url('testimonial/add');?>">Add Testimonial</a></li>
                    <li><a href="<?php echo base_url('testimonial/list');?>">All Testimonial</a></li>
                </ul>
            </li>
			
			
			
			
			
			<li> <a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-calendar-check"></i><span>Enquiry</span> </a>
                <ul class="ml-menu">
                    <li><a href="<?php echo base_url('homeenquary/list');?>">Home Enquiry</a></li>
                    <li><a href="<?php echo base_url('contactdetail/enquirylist');?>">Contact Enquiry</a></li>
					 <li><a href="<?php echo base_url('Sidebarenquiry/enquirylist');?>">Sidebar Enquiry</a></li>
				
					  
				 
                </ul>
            </li>

			
            
	
		
            </li>
			
			
			
			
          
            
           
        </ul>
    </div>
</aside>
