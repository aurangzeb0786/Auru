<!doctype html>
<html class="no-js " lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<meta name="description" content="">
<title>Blog list</title>
<?php $this->load->view('admin/includes/css');?>
</head>
<body class="theme-cyan">

<!-- Overlay For Sidebars -->
<div class="overlay"></div>
<?php $this->load->view('admin/includes/topbar');?>
<!-- Left Sidebar -->
<?php $this->load->view('admin/includes/left-sidebar');?>

<section class="content">
    <div class="block-header">
        <div class="row">
            <div class="col-lg-7 col-md-6 col-sm-12">
                <h2>All Blog
              
                </h2>
            </div>
            <div class="col-lg-5 col-md-6 col-sm-12">
                <ul class="breadcrumb float-md-right">
                    <li class="breadcrumb-item"><a href="<?php echo base_url('admin/dashboard');?>"><i class="zmdi zmdi-home"></i> Home</a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Blog News</a></li>
                    <li class="breadcrumb-item active">All Blog News</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <!-- Exportable Table -->
        <div class="row clearfix">
            <div class="col-lg-12">
                <div class="card">
                    <div class="header">
                        <h2><strong>All</strong> Blog List </h2>
                      
                    </div>
                    <div class="body">
                         <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                            <thead>
                                <tr>
								    <th>Image</th>
                                    <th>heading</th>
                                    <th>url</th>
                                    <th>SEO Title</th>
									<th>SEO Keyword</th>
									<th>SEO Description</th>
									<th>Status</th>
									<th>Edit</th>
									<th>Delete</th>
                                    
                                </tr>
                            </thead>
<?php foreach($RESULT as $data)
    {?>
                            <tbody>
                                <tr>
								    <td><img src="<?php echo base_url();?>assets/blog/<?php echo $data->image; ?>"></td>
									  <td><?php echo $data->heading; ?></td>
                                    <td><?php echo $data->url; ?></td>
                                  
									
									
<?php

$seo=$this->pages->selectallseopage($data->url); 

?>									
									
									
									
									<td><?php echo $seo[0]->seotitle; ?></td>
									<td><?php echo $seo[0]->keyword; ?></td>
									<td><?php echo $seo[0]->seodescription; ?></td>
									
									<td><?php echo $data->status; ?></td>

									<td><a href="<?php echo base_url('blog/edit/'.$data->url);?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></td>
                                    <td><a href="<?php echo base_url('blog/delete/'.$data->url);?>" onclick="return confirm('are you sure do you want to delete this record')"><i class="fa fa-trash-o" aria-hidden="true"></i></td>
                                </tr>
                                
                                
                                
                                
                                
                            </tbody>
	<?php  }  ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- #END# Exportable Table --> 
    </div>
</section>

<?php $this->load->view('admin/includes/js'); ?>
</body>
</html>