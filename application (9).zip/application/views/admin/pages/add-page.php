<!doctype html>
<html class="no-js " lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<meta name="description" content="">
<title>Add Page</title>
<?php $this->load->view('admin/includes/css');?>
</head>
<body class="theme-cyan">
<!-- Overlay For Sidebars -->
<div class="overlay"></div>
<?php $this->load->view('admin/includes/topbar');?>

<?php $this->load->view('admin/includes/left-sidebar');?>

<section class="content">
    <div class="block-header">
        <div class="row">
            <div class="col-lg-7 col-md-6 col-sm-12">
                <h2>Add Page
                <small class="text-muted"></small>
                </h2>
            </div>
            <div class="col-lg-5 col-md-6 col-sm-12">
                <ul class="breadcrumb float-md-right">
                    <li class="breadcrumb-item"><a href="<?php echo base_url('admin/dashboard');?>"><i class="zmdi zmdi-home"></i> Home</a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Add Page</a></li>

                </ul>
            </div>
        </div>
    </div>
    <div class="container-fluid">
      
        <!-- Masked Input -->
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="header">
                        <h2><strong>Add </strong> Page</h2>
                       
                    </div>
                    <div class="body">
                        <div class="demo-masked-input">
                         
						
						
						
						
						 <form method="post" enctype="multipart/form-data">
					
						 
						 
                            <div class="row clearfix">
								
								
								<div class="col-lg-12 col-md-12"> <b>Name</b> 
                                    <div class="input-group">
                                        <span class="input-group-addon"></span>	
                                        <input type="text" name="name" onkeyup="getUrl(this.value);" onkeyup="getUrl(this.value);" class="form-control"   required>
                                    </div>
                                </div>
								
								<div class="col-lg-12 col-md-12"> <b>URL</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"></span>	
                                        <input type="text" name="url" id="urlkey" class="form-control"  required>
                                    </div>
                                </div>
								
								<div class="col-lg-12 col-md-12"> <b>Heading</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"></span>	
                                        <input type="text" name="heading" class="form-control"  required>
                                    </div>
                                </div>
								
								<div class="col-lg-12 col-md-12"> <b>Description</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"></span>	
                                        <textarea class="form-control" rows="5"   name="description"  ></textarea>
                                    </div>
                                </div>
								
                            <div class="col-md-12">
                               <div class="header1">
                                 <h2><strong>SEO</strong></h2>
                               </div>
							</div>	 
							
							
		
							<div class="col-lg-12 col-md-12"> <b>Seo Title</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"></span>	
                                        <input type="text" name="seotitle" class="form-control"  >
                                    </div>
                            </div>
							<div class="col-lg-12 col-md-12"> <b>Keyword</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"></span>	
                                        <input type="text" name="keyword" class="form-control"  >
                                    </div>
                            </div>
							<div class="col-lg-12 col-md-12"> <b>Seo Description</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"></span>	
                                        <textarea class="form-control" rows="5"  name="seodescription"  ></textarea>
                                    </div>
                                </div>
								
                               
								
								
                                 
                               
							    <div class="col-lg-12 col-md-12">
                                <b>Status</b>
                                <select class="form-control show-tick" name="status">
                                    <option value="1">Active</option>
                                    <option value="0">Deactive</option>
                                </select>
                            </div>
							   
							   
							  
							<div class="col-sm-12">
                                <button type="submit" name="submit" class="btn btn-primary btn-round">Submit</button>
                               
                            </div>
							  
                            </div>
							</form>
                        </div>
                    </div>
                </div>
				</div>
            </div>
        </div>
        <!-- #END# Masked Input -->        
       
    </div>
</section>
<?php $this->load->view('admin/includes/js');?>


<script>
function ADD()
{
var x=$('#hdvalueinc').val();
//var str=$('#appenddays').html();

var str='<div id="'+x+'"><div class="col-lg-12 col-md-12"> <b>Address Heading</b><div class="input-group"><span class="input-group-addon"><i class="fa fa-address-card-o" aria-hidden="true"></i></span><input type="text" name="addresshead[]" class="form-control" placeholder="Your Address"  required></div></div><div class="col-lg-12 col-md-12"> <b>Address</b><div class="input-group"><span class="input-group-addon"><i class="fa fa-map-marker" aria-hidden="true"></i></span><textarea class="form-control" rows="5" id="comment" name="address[]"></textarea></div></div><div class="col-lg-12 col-md-12"> <b>Address Map</b><div class="input-group"><span class="input-group-addon"><i class="fa fa-map-marker" aria-hidden="true"></i></span><textarea class="form-control" rows="5" id="comment" name="map[]"></textarea></div></div>	<a class="btn" style="color:#fff;padding:10px; font-size:14px !important; background-color:red" onclick=remove('+x+')>Remove</a></div>';


$('#appenddays').append(str);

x++;
$('#hdvalueinc').val(x);
}


function remove(str)
{

$('#'+str).remove();
}
</script>


</body>
</html>