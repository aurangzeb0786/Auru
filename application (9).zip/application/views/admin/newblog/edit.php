<!doctype html>
<html class="no-js " lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<meta name="description" content="">
<title>Edit Blog</title>
<?php $this->load->view('admin/includes/css');?>
</head>
<body class="theme-cyan">
<!-- Overlay For Sidebars -->
<div class="overlay"></div>
<?php $this->load->view('admin/includes/topbar');?>

<?php $this->load->view('admin/includes/left-sidebar');?>

<section class="content">
    <div class="block-header">
        <div class="row">
            <div class="col-lg-7 col-md-6 col-sm-12">
                <h2>Edit Blog
                <small class="text-muted"></small>
                </h2>
            </div>
            <div class="col-lg-5 col-md-6 col-sm-12">
                <ul class="breadcrumb float-md-right">
                    <li class="breadcrumb-item"><a href="<?php echo base_url('admin/dashboard');?>"><i class="zmdi zmdi-home"></i> Home</a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Edit Blog</a></li>

                </ul>
            </div>
        </div>
    </div>
    <div class="container-fluid">  
      
        <!-- Masked Input -->
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="header">
                        <h2><strong>Edit</strong> Blog</h2>
                       
                    </div>
                    <div class="body">
                        <div class="demo-masked-input">

						
						 <form method="post" enctype="multipart/form-data">
						
<?php $COMMON=$this->crud->selectcommonbyurl($EDITNEWBLOG[0]->url); ?> 
<input type="hidden" name="commonurl" value="<?= $COMMON[0]->url; ?>">  



						<div class="col-lg-12 col-md-12">
                                <b>Select Parent Menu</b>
                                <select class="form-control show-tick" name="pmenu">
                                    <option <?= ($EDITNEWBLOG[0]->pmenu=="None")?"selected":""; ?> value="None">None</option>
									
									<?php foreach($RESULT as $data)
									{
									?>
									<option <?= ($EDITNEWBLOG[0]->pmenu==$data->url)?"selected":""; ?> value="<?php echo $data->name;?>"><?php echo $data->name;?></option>
									
									<?php
									}
									?>
                                   
                                </select>
                            </div>
						

                                <div class="col-lg-12 col-md-12"> <b>Name</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"></span> 
                                        <input type="text" name="name" class="form-control" value="<?php echo $EDITNEWBLOG[0]->name; ?>" onkeyup="getUrl(this.value);" required>
                                    </div>
                                </div>
                                 <div class="col-lg-12 col-md-12"> <b>heading</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"></span> 
                                        <input type="text" name="heading" class="form-control" value="<?php echo $EDITNEWBLOG[0]->heading; ?>" onkeyup="getUrl(this.value);" required>
                                    </div>
                                </div>
                                
                                <div class="col-lg-12 col-md-12"> <b>URL</b> 
                                    <div class="input-group">
                                        <span class="input-group-addon"></span> 
                                        <input type="text" name="url" class="form-control" value="<?php echo $EDITNEWBLOG[0]->url; ?>" id="urlkey" required>
                                    </div>
                                </div>                        		
 
                          <div class="col-lg-12 col-md-12">
                                <b>Show Home page</b>
                                <select class="form-control show-tick" name="shomepage">
                                    <option <?= ($EDITNEWBLOG[0]->shomepage=="No")?"selected":""; ?> value="No">NO</option>
									<option <?= ($EDITNEWBLOG[0]->shomepage=="Yes")?"Footer":""; ?> value="Yes">Yes</option>
									
                                   
                                </select>
                            </div>


                             
                              
                               <img src="<?php echo base_url(); ?>assets/newblog/<?php echo $EDITNEWBLOG[0]->image; ?>" style="width:150px; height:150px;">
						  <input type="hidden" name="old-image" class="form-control" value="<?php echo $EDITNEWBLOG[0]->image; ?>">
                            <div class="row clearfix">
							    <div class="col-lg-12 col-md-12"> <b>Image</b>
                                    <div class="input-group">
                                         <span class="input-group-addon"> </span>
                                        <input type="file" name="image" class="form-control" >
                                    </div>
                                </div>
                                
                                
                                <div class="col-lg-12 col-md-12"> <b>Alt</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"></span>	
                                        <input type="text" name="alt" class="form-control" value="<?php echo $EDITNEWBLOG[0]->alt; ?>" >
                                    </div>
                                </div>
                                
                                
                                
                                  <img src="<?php echo base_url(); ?>assets/newblog/<?php echo $EDITNEWBLOG[0]->bimage; ?>" style="width:150px; height:150px;">
						  <input type="hidden" name="old-bimage" class="form-control" value="<?php echo $EDITNEWBLOG[0]->bimage; ?>">
                            <div class="row clearfix">
							    <div class="col-lg-12 col-md-12"> <b>Background Image</b>
                                    <div class="input-group">
                                         <span class="input-group-addon"> </span>
                                        <input type="file" name="bimage" class="form-control" >
                                    </div>
                                </div>
                              
                              
                              
                              
                              
                              
                              
                              
							
                                <div class="col-lg-12 col-md-12"> <b>Description</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"></span>  
                                        <textarea class="form-control" name="description"><?php echo $EDITNEWBLOG[0]->description; ?></textarea>
                                    </div>
                                </div>      





                            <div class="col-lg-12 col-md-12">
                                <b>Status</b>
                                <select class="form-control show-tick" name="status">
                                    <option <?= ($EDITNEWBLOG[0]->status=="1")?"selected":""; ?> value="1">Active</option>
                                    <option <?= ($EDITNEWBLOG[0]->status=="0")?"selected":""; ?> value="0">Deactive</option>
                                </select>
                            </div>								 
																
						


								 
								
								 
                            <div class="col-md-12">
                               <div class="header1">
                                 <h2><strong>SEO</strong></h2>
                               </div>
                            </div>   
                            
<input type="hidden" name="seoid" value="<?= $EDITSEO[0]->id; ?>">                            
        
                            <div class="col-lg-12 col-md-12"> <b>Seo Title</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"></span> 
                                        <input type="text" name="seotitle" class="form-control"  value="<?= $EDITSEO[0]->seotitle; ?>">
                                    </div>
                            </div>
                            <div class="col-lg-12 col-md-12"> <b>Keyword</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"></span> 
                                        <input type="text" name="keyword" class="form-control" value="<?= $EDITSEO[0]->keyword; ?>" >
                                    </div>
                            </div>
                            <div class="col-lg-12 col-md-12"> <b>Seo Description</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"></span> 
                                        <textarea class="form-control" rows="5" id="comment"  name="seodescription"  ><?= $EDITSEO[0]->seodescription; ?></textarea>  
                                    </div>
                            </div>
                                
                          <!--<div class="col-lg-12 col-md-12">
                            <b>Meta Tag</b>
                            <select class="form-control show-tick" name="meta-tag">

                                 <option <?= ($EDITSEO[0]->metatag=="INDEX, FOLLOW")?"selected":""; ?> value="INDEX, FOLLOW">INDEX, FOLLOW</option>
                                 <option <?= ($EDITSEO[0]->metatag=="NOINDEX, NOFOLLOW")?"selected":""; ?> value="NOINDEX, NOFOLLOW">NOINDEX, NOFOLLOW</option>

                                </select>
                            </div>-->
                                
                                
                                 
                               
								
								
								
								
								
								 
								
								
								
								
								
                                 
                               
							    
							   
							   
							  
							<div class="col-sm-12">
                                <button type="submit" name="submit" class="btn btn-primary btn-round">Submit</button>
                               
                            </div>
							  
                            </div>
                        </div>
                    </div>
                </div>
				</div>
            </div>
        </div>
        <!-- #END# Masked Input -->        
       
    </div>
</section>
<?php $this->load->view('admin/includes/js');?>
</body>
</html>