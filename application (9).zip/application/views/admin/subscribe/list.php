<!doctype html>
<html class="no-js " lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<meta name="description" content="">
<title>Suscribe</title>
<?php $this->load->view('admin/includes/css');?>
</head>
<body class="theme-cyan">

<!-- Overlay For Sidebars -->
<div class="overlay"></div>
<?php $this->load->view('admin/includes/topbar');?>
<!-- Left Sidebar -->
<?php $this->load->view('admin/includes/left-sidebar');?>

<section class="content">
    <div class="block-header">
        <div class="row">
            <div class="col-lg-7 col-md-6 col-sm-12">
                <h2>All Suscribe
               
                </h2>
            </div>
            <div class="col-lg-5 col-md-6 col-sm-12">
                <ul class="breadcrumb float-md-right">
                    <li class="breadcrumb-item"><a href="<?php echo base_url('admin/dashboard');?>"><i class="zmdi zmdi-home"></i> Home</a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Suscribe</a></li>
                    <li class="breadcrumb-item active">All Suscribe</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <!-- Exportable Table -->
        <div class="row clearfix">
            <div class="col-lg-12">
                <div class="card">
                    <div class="header">
                        <h2><strong>All</strong> Suscribe List </h2>
                      
                    </div>
                    <div class="body">
                         <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                            <thead>
                                <tr>
								    <th>s.no</th>
                                    <th>Email</th>
                                    
                                    
									<th>Delete</th>
                                    
                                </tr>
                            </thead>
                             <?php foreach($RESULT as $data)
     { ?>
                   <tbody>
                      
                                <tr>
                                    
								    
									  
                                  
                                    
                                   <td><?php echo $data->id; ?></td>
                                    <td><?php echo $data->email; ?></td>
                                    
                           
									
                                    <td><a href="<?php echo base_url('subscribes/delete/'.$data->id);?>"><i class="fa fa-trash" aria-hidden="true"></i></a></td>
                                </tr>
                                
                                
                                
                                
                                
                            </tbody>
		<?php  }  ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- #END# Exportable Table --> 
    </div>
</section>

<?php $this->load->view('admin/includes/js'); ?>
</body>
</html>