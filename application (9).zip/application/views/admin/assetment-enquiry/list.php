<!doctype html>
<html class="no-js " lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<meta name="description" content="">
<title>Sidebar Enquiry</title>
<?php $this->load->view('admin/includes/css');?>
</head>
<body class="theme-cyan">

<!-- Overlay For Sidebars -->
<div class="overlay"></div>
<?php $this->load->view('admin/includes/topbar');?>
<!-- Left Sidebar -->
<?php $this->load->view('admin/includes/left-sidebar');?>

<section class="content">
    <div class="block-header">
        <div class="row">
            <div class="col-lg-7 col-md-6 col-sm-12">
                <h2>All Sidebar Enquiry
               
                </h2>
            </div>
            <div class="col-lg-5 col-md-6 col-sm-12">
                <ul class="breadcrumb float-md-right">
                    <li class="breadcrumb-item"><a href="<?php echo base_url('admin/dashboard');?>"><i class="zmdi zmdi-home"></i> Home</a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Sidebar</a></li>
                    <li class="breadcrumb-item active">All Sidebar Enquiry</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <!-- Exportable Table -->
        <div class="row clearfix">
            <div class="col-lg-12">
                <div class="card">
                    <div class="header">
                        <h2><strong>All</strong> Sidebar Enquiry </h2>
                      
                    </div>
                    <div class="body" style="overflow-x:scroll;">
                        <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                            <thead>
                                <tr>
                                    
                                    <th>Title</th>
                                    <th>First Name</th>
                                    <th>Country of Residence</th>
									<th>Destination Country</th>
									<th>ISD Code</th>
									<th>Contact No</th>
									<th>Email ID</th>
									<th>Address</th>
									<th>City</th>
									<th>Pincode</th>
									<th>Age</th>
									<th>Highest Qualification</th>
									<th>Experince</th>
									<th>Purpose to Immigrate </th>
									
									<th>Delete</th>
                                    
                                </tr>
                            </thead>
                          <?php foreach($RESULT as $data)
    {?>
                            <tbody>
                                <tr>
                                    <td><?php echo $data->title; ?></td>
                                    <td><?php echo $data->fname; ?></td>
									<td><?php echo $data->rcountry; ?></td>
									<td><?php echo $data->dcountry; ?></td>
									<td><?php echo $data->Isdcode; ?></td>
									<td><?php echo $data->phone; ?></td>
									<td><?php echo $data->email; ?></td>
									<td><?php echo $data->address; ?></td>
									<td><?php echo $data->city; ?></td>
									<td><?php echo $data->pincode; ?></td>
									<td><?php echo $data->age; ?></td>
									<td><?php echo $data->hqualification; ?></td>
									<td><?php echo $data->experience; ?></td>
									<td><?php echo $data->pimmigrate; ?></td>
									<td><a href="<?php echo base_url('assestment/enquarydelete/'.$data->id);?>"><i class="fa fa-trash" aria-hidden="true"></i></a></td>
								</tr>
                          </tbody>
	<?php } ?>
	
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- #END# Exportable Table --> 
    </div>
</section>

<?php $this->load->view('admin/includes/js'); ?>
</body>
</html>