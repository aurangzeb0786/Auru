<!doctype html>
<html class="no-js " lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<meta name="description" content="">
<title>Edit</title>
<?php $this->load->view('admin/includes/css');?>
</head>
<body class="theme-cyan">
<!-- Overlay For Sidebars -->
<div class="overlay"></div>
<?php $this->load->view('admin/includes/topbar');?>

<?php $this->load->view('admin/includes/left-sidebar');?>

<section class="content">
    <div class="block-header">
        <div class="row">
            <div class="col-lg-7 col-md-6 col-sm-12">
                <h2>Edit Courses
                <small class="text-muted"></small>
                </h2>
            </div>
            <div class="col-lg-5 col-md-6 col-sm-12">
                <ul class="breadcrumb float-md-right">
                    <li class="breadcrumb-item"><a href="<?php echo base_url('admin/dashboard');?>"><i class="zmdi zmdi-home"></i> Home</a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0);">Edit Courses</a></li>

                </ul>
            </div>
        </div>
    </div>
    <div class="container-fluid"> 
      
        <!-- Masked Input -->
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="header">
                        <h2><strong>Edit</strong> Courses</h2>
                       
                    </div>
                    <div class="body">
                        <div class="demo-masked-input">

						
						 <form method="post" enctype="multipart/form-data">
						
<?php $COMMON=$this->crud->selectcommonbyurl($EDITSERVICE[0]->url); ?> 
<input type="hidden" name="commonurl" value="<?= $COMMON[0]->url; ?>">  						
						
						
						
						<div class="col-lg-12 col-md-12">
                                <b>Select Course Catgory</b>
                                <select class="form-control show-tick" name="catcourse" required>
                                    
                                    <option value="1">None</option>
                
                
                <option <?= ($EDITSERVICE[0]->catcourse=="spoken-english")?"selected":""; ?> value="spoken-english">SPOKEN ENGLISH</option> 
				<option <?= ($EDITSERVICE[0]->catcourse=="international-english-exams")?"selected":""; ?> value="international-english-exams">INTERNATIONAL ENGLISH EXAMS</option> 
				<option <?= ($EDITSERVICE[0]->catcourse=="personality-development")?"selected":""; ?> value="personality-development">PERSONALITY DEVELOPMENT</option> 
                
                
                 
                                </select>
                            </div>
						
						

                                <div class="col-lg-12 col-md-12"> <b>Name</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"></span> 
                                        <input type="text" name="name" class="form-control" value="<?php echo $EDITSERVICE[0]->name; ?>" onkeyup="getUrl(this.value);" required>
                                    </div>
                                </div>
                                 <div class="col-lg-12 col-md-12"> <b>heading</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"></span> 
                                        <input type="text" name="heading" class="form-control" value="<?php echo $EDITSERVICE[0]->heading; ?>" onkeyup="getUrl(this.value);" required>
                                    </div>
                                </div>
                                
                                <div class="col-lg-12 col-md-12"> <b>URL</b> 
                                    <div class="input-group">
                                        <span class="input-group-addon"></span> 
                                        <input type="text" name="url" class="form-control" value="<?php echo $EDITSERVICE[0]->url; ?>" id="urlkey" required>
                                    </div>
                                </div>  
								
								 <div class="col-lg-12 col-md-12"> <b>Duration</b> 
                                    <div class="input-group">
                                        <span class="input-group-addon"></span> 
                                        <input type="text" name="duration" class="form-control" value="<?php echo $EDITSERVICE[0]->duration; ?>" id="urlkey">
                                    </div>
                                </div> 
								
								
								    <div class="col-lg-12 col-md-12"> <b>Order By</b> 
                                    <div class="input-group">
                                        <span class="input-group-addon"></span> 
                                        <input type="number" name="order" class="form-control" value="<?php echo $EDITSERVICE[0]->orderby; ?>" id="urlkey">
                                    </div>
                                </div>   
                                
                                <div class="col-lg-12 col-md-12">
                                <b>Show Home Page</b>
                                <select class="form-control show-tick" name="shomepage">
                                    <option <?= ($EDITSERVICE[0]->shomepage=="1")?"selected":""; ?> value="1">Yes</option>
                                    <option <?= ($EDITSERVICE[0]->shomepage=="0")?"selected":""; ?> value="0">No</option>
                                </select>
                            </div>	
                                
                                
                                   <div class="col-lg-12 col-md-12">
                                <b>Show in menu</b>
                                <select class="form-control show-tick" name="smenu">
                                    <option <?= ($EDITSERVICE[0]->smenu=="1")?"selected":""; ?> value="1">Yes</option>
                                    <option <?= ($EDITSERVICE[0]->smenu=="0")?"selected":""; ?> value="0">No</option>
                                </select>
                            </div>	

                              
                              
                               <img src="<?php echo base_url(); ?>assets/services/<?php echo $EDITSERVICE[0]->image; ?>" style="width:150px; height:150px;">
						  <input type="hidden" name="old-image" class="form-control" value="<?php echo $EDITSERVICE[0]->image; ?>">
                            <div class="row clearfix">
							    <div class="col-lg-12 col-md-12"> <b>Image</b>
                                    <div class="input-group">
                                         <span class="input-group-addon"> </span>
                                        <input type="file" name="image" class="form-control" >
                                    </div>
                                </div>
                                
                                
                                
                                
                                
                                
                                  <img src="<?php echo base_url(); ?>assets/services/<?php echo $EDITSERVICE[0]->bimage; ?>" style="width:150px; height:150px;">
						  <input type="hidden" name="old-bimage" class="form-control" value="<?php echo $EDITSERVICE[0]->bimage; ?>">
                            <div class="row clearfix">
							    <div class="col-lg-12 col-md-12"> <b>Background Image</b>
                                    <div class="input-group">
                                         <span class="input-group-addon"> </span>
                                        <input type="file" name="bimage" class="form-control" >
                                    </div>
                                </div>
                              
                              
                              
                              
                              
                              
                              
                              
							
                                <div class="col-lg-12 col-md-12"> <b>Description</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"></span>  
                                        <textarea class="form-control" name="description"><?php echo $EDITSERVICE[0]->description; ?></textarea>
                                    </div>
                                </div>      								
								  
								
                        <!--<div class="col-lg-6 col-md-6">-->
                        <!--    <b>Show in Consultant</b>-->
                        <!--    <select class="form-control show-tick" name="show_consultant">-->
                        <!--        <option <?= ($EDITCOUNTRY[0]->show_consultant==0)?"selected":""; ?> value="0">No</option>-->
                        <!--        <option <?= ($EDITCOUNTRY[0]->show_consultant==1)?"selected":""; ?> value="1">YES</option> -->
                        <!--    </select>-->
                        <!--</div>-->


                        <!--<div class="col-lg-6 col-md-6">-->
                        <!--    <b>Show in Visa Immigration</b>-->
                        <!--    <select class="form-control show-tick" name="show_immigration">-->
                        <!--        <option <?= ($EDITCOUNTRY[0]->show_immigration=="0")?"selected":""; ?> value="0">No</option>-->
                        <!--        <option <?= ($EDITCOUNTRY[0]->show_immigration=="1")?"selected":""; ?> value="1">YES</option> -->
                        <!--    </select>-->
                        <!--</div>-->



								 
								
								 
                            <div class="col-md-12">
                               <div class="header1">
                                 <h2><strong>SEO</strong></h2>
                               </div>
                            </div>   
                            
<input type="hidden" name="seoid" value="<?= $EDITSEO[0]->id; ?>">                            
        
                            <div class="col-lg-12 col-md-12"> <b>Seo Title</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"></span> 
                                        <input type="text" name="seotitle" class="form-control"  value="<?= $EDITSEO[0]->seotitle; ?>">
                                    </div>
                            </div>
                            <div class="col-lg-12 col-md-12"> <b>Keyword</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"></span> 
                                        <input type="text" name="keyword" class="form-control" value="<?= $EDITSEO[0]->keyword; ?>" >
                                    </div>
                            </div>
                            <div class="col-lg-12 col-md-12"> <b>Seo Description</b>
                                    <div class="input-group">
                                        <span class="input-group-addon"></span> 
                                        <textarea class="form-control" rows="5" id="comment"  name="seodescription"  ><?= $EDITSEO[0]->seodescription; ?></textarea>  
                                    </div>
                            </div>
                                
                          <div class="col-lg-12 col-md-12" style="display:none;">
                            <b>Meta Tag</b>
                            <select class="form-control show-tick" name="meta-tag">

                                 <option <?= ($EDITSEO[0]->metatag=="INDEX, FOLLOW")?"selected":""; ?> value="INDEX, FOLLOW">INDEX, FOLLOW</option>
                                 <option <?= ($EDITSEO[0]->metatag=="NOINDEX, NOFOLLOW")?"selected":""; ?> value="NOINDEX, NOFOLLOW">NOINDEX, NOFOLLOW</option>

                                </select>
                            </div>
                                
                                
                                 
                               
                            <div class="col-lg-12 col-md-12">
                                <b>Status</b>
                                <select class="form-control show-tick" name="status">
                                    <option <?= ($EDITSERVICE[0]->status=="1")?"selected":""; ?> value="1">Active</option>
                                    <option <?= ($EDITSERVICE[0]->status=="0")?"selected":""; ?> value="0">Deactive</option>
                                </select>
                            </div>								 
								
								
								
								
								
								
								 
								
								
								
								
								
                                 
                               
							    
							   
							   
							  
							<div class="col-sm-12">
                                <button type="submit" name="submit" class="btn btn-primary btn-round">Submit</button>
                               
                            </div>
							  
                            </div>
                        </div>
                    </div>
                </div>
				</div>
            </div>
        </div>
        <!-- #END# Masked Input -->        
       
    </div>
</section>
<?php $this->load->view('admin/includes/js');?>
</body>
</html>