﻿<!doctype html>
<html class="no-js " lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<meta name="description" content="Responsive Bootstrap 4 and web Application ui kit.">
<title>Dashboard</title>
<?php $this->load->view('admin/includes/css');?>
</head>
<body class="theme-cyan">
<?php $this->load->view('admin/includes/topbar');?>
<!-- Left Sidebar -->
<?php $this->load->view('admin/includes/left-sidebar');?>
<!-- Main Content -->
<section class="content home">
    <div class="block-header">
        <div class="row">
            <div class="col-lg-7 col-md-6 col-sm-12">
                <h2>Dashboard
                <small class="text-muted">Welcome to Visamount</small>
                </h2>
            </div>
            <div class="col-lg-5 col-md-6 col-sm-12">                
                <button class="btn btn-primary btn-icon btn-round hidden-sm-down float-right m-l-10" type="button">
                    <i class="zmdi zmdi-plus"></i>
                </button>
                <ul class="breadcrumb float-md-right">
                    <li class="breadcrumb-item"><a href="index.html"><i class="zmdi zmdi-home"></i> home</a></li>
                    <li class="breadcrumb-item active">Dashboard </li>
                </ul>                
            </div>
        </div>
    </div>
    
</section>

<?php $this->load->view('admin/includes/js'); ?>
</body>
</html>