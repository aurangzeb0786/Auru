<!doctype html>
<html lang="en">
  <head>
     <title><?php echo $SEODATA[0]->seotitle; ?></title>
      <meta name="description" content="<?php echo $SEODATA[0]->seodescription; ?>" />
    <meta name="keywords" content="<?php echo $SEODATA[0]->keyword; ?>" />
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 <?php $this->load->view('include/css.php');?>
</head>

<body>

<?php $this->load->view('include/header');?>
<!--------------------------------------------------- country-head -------------------------->

<section style="background-image:url(<?php echo base_url(); ?>assets/services/bg3.jpg);" class="bgheadpic">
    <div class="headclr">
<div class="container">
<div class="row">
<div class="col-md-12">

<h1 class="text-center text-white h3 mb-0"><?= $BLOGDATAS[0]->heading; ?></h1> 

</div>
</div>
</div>
</div>
</section>


<section class="pt-5">
<div class="container">
<div class="row">


<div class="col-md-8">
<div class="row"> 

<div class="col-md-12 immigration-new-style service">

<img class="blog-img" src="<?php echo base_url();?>assets/blog/<?php echo $BLOGDATAS[0]->image; ?>" >

<h5 class="font-weight-bold mb-2"><?= $BLOGDATAS[0]->heading; ?></h5>

<p><?= $BLOGDATAS[0]->description; ?> </p>

 
</div>


</div>
</div>









<?php $this->load->view('include/sidebar');?>







</div>
</div>
</section>

<?php $this->load->view('include/footer');?>