<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 <?php $this->load->view('include/css.php');?>
</head>

<body>

<?php $this->load->view('include/header');?>
<!--------------------------------------------------- country-head -------------------------->

<section style="background-image:url(<?php echo base_url(); ?>assets/services/bg3.jpg);" class="bgheadpic">
    <div class="headclr">
<div class="container">
<div class="row">
<div class="col-md-12">

<h1 class="text-center text-white h3 mb-0">BLOG</h1>

</div>
</div>
</div>
</div>
</section>




<section class="pt-5" style="background-color: #f8f8f8;">
<div class="container">
<div class="row">


<div class="col-md-8">
<div class="row">

<?php foreach ($ALLBLOG as $blog) { ?>

<div class="col-md-12 immigration-new-style">

<a href="<?= base_url($blog->url); ?>">

<img class="blog-img" src="<?php echo base_url();?>assets/blog/<?php echo $blog->image; ?>" >

<h5 class="font-weight-bold"><?= $blog->heading; ?></h5>
</a>
<p><?= word_limiter($blog->description,25); ?> </p>

 
<a class="btn btn-first " href="<?= base_url($blog->url); ?>">Read more</a> 

</div>

<?php } ?>

</div>
</div>




<?php $this->load->view('include/sidebar');?>

</div>
</section>


<?php $this->load->view('include/footer');?>