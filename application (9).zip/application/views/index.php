<!doctype html>
<html lang="en">
  <head>
  <title>Dushyant World</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 <?php $this->load->view('include/css.php');?>
</head>

<body>

<?php $this->load->view('include/header');?>


<!-- Start secound slider --->

<!-- end secound slider -->








<section style="background-image:url(<?php echo base_url('media/images/slide/bg5.jpg');?>)" class="front-bgi">
    <div class="overlay">
<div class="container">
<div class="row">



<div class="col-lg-8 col-12 slide-left">
<h1><span class="slide-heading">DUSHYANT </span> WORLD</h1>
<div class="col-lg-12   p-0">
<div class="col-lg-6 col-6   p-0 slide-alignr">
<div class="col-lg-12 col-12  p-0 slide-mrg">
<div class="col-lg-2  col-12 slide-align p-0">
<div class="slide-round">
<i class="fa fa-graduation-cap" aria-hidden="true"></i>
</div>
</div>
<div class="col-lg-10 col-12 slide-text slide-align p-0">
<p>70+ Families have been taught.</p>
</div>
</div>

<div class="col-lg-12 col-12 p-0 slide-mrg">
<div class="col-lg-2 col-12  slide-align p-0">
<div class="slide-round">
<i class="fa fa-graduation-cap" aria-hidden="true"></i>
</div>
</div>
<div class="col-lg-10 col-12 slide-text slide-alignr p-0">
<p>Special Voice 'n' Accent Training.</p>
</div>
</div>

</div>
<div class="col-lg-6 col-6 p-0 slide-align">
<div class="col-lg-12  col-12  p-0 slide-mrg">
<div class="col-lg-2 col-12  slide-align p-0">
<div class="slide-round">
<i class="fa fa-graduation-cap" aria-hidden="true"></i>
</div>
</div>
<div class="col-lg-10 col-12  slide-text slide-alignr p-0">
<p>Extra Discount for March 2020</p>
</div>
</div>

<div class="col-lg-12 col-12 p-0 slide-mrg">
<div class="col-lg-2  col-12 slide-align p-0">
<div class="slide-round">
<i class="fa fa-graduation-cap" aria-hidden="true"></i>
</div>
</div>
<div class="col-lg-10 col-12  slide-text slide-alignr p-0">
<p>Specially Designed Methodology.</p>
</div>
</div>

</div>


</div>
<ul class="slide-button btn-sm-center ">

<li class="slide-clrbtn"><a href="<?php echo base_url('welcome/allcourses');?>"><button type="button" class="btn btn-primary ">Read More</button></a></li>
<li class="slide-clrbtn2 "><a href="<?php echo base_url('contact-us');?>"><button type="button" class="btn btn-primary">Contact Now</button></a></li>
</ul>

</div>




<div class="col-lg-4  col-12 slide-left ">
<div class="col-lg-12 col-12  slide-form ">
<form id="home_appointment_form" name="home_appointment_form" class="booking-form form-home bg-white p-30" method="post" action="" novalidate="novalidate">
                  <h3 class="mt-0  request">Request <span class="clrhead">for Free Trial Classes</span></h3>
                  <div class="row mt-3">
                    <div class="col-sm-12">
                      <div class="form-group mb-10">
                        <input name="name" class="form-control" type="text" required="" placeholder="Enter Name" aria-required="true">
                      </div>
                    </div>
                 
                    <div class="col-sm-12">
                      <div class="form-group mb-10">
                        <input name="phone" class="form-control required" type="text" placeholder="Enter Mobile No" maxlength="10" aria-required="true">
                      </div>
                    </div>
                    
                       <div class="col-sm-12">
                      <div class="form-group mb-10">
                        <input name="email" class="form-control required email" type="email" placeholder="Enter Email" aria-required="true">
                      </div>
                    </div>
                    
                  <div class="col-sm-12">
                    <div class="form-group mb-20">
                      <div class="styled-select">
                        <select id="person_select" name="course" class="form-control" required="" aria-required="true">
                          <option value="">Choose Courses</option>
						   <?php foreach($SHOWMENU as $data)
            		   {
            		   ?>
                          <option value="<?php echo $data->name; ?>"><?php echo $data->name; ?></option>
					   <?php } ?>
                         
                        </select>
                      </div>
                    </div>
                  </div>
                 
                   
                  </div>
                  <div class="form-group mb-10">
                    <textarea name="message" class="form-control required" placeholder="Enter Message" rows="3" aria-required="true"></textarea>
                  </div>
                  <div class="form-group mb-0 mt-20">
                  
                    <button type="submit" name="submit" class="btn btn-colored btn-theme-color-2 text-white btn-lg btn-block" data-loading-text="Please wait...">Submit Request</button>
                  </div>
                </form>
</div>
</div>
</div>
</div>
</div>
</section>





<section> 
<div class="container">
<div class="row">
<div class="col-md-4 p-0">
<div class="card card-img ">
<div class="card-top-color bgcred">
<a href="<?php echo base_url('welcome/categorypage/spoken-english');?>"><i class="fa fa-graduation-cap" aria-hidden="true"></i>
<h3>Spoken <br/>English</h3></a>
  </div>
	
</div>
</div>


<div class="col-md-4 p-0">
<div class="card card-img ">
<div class="card-top-color bgcblu">
<a href="<?php echo base_url('welcome/categorypage/international-english-exams');?>"><i class="fa fa-graduation-cap" aria-hidden="true"></i>
<h3>International <br/>English Exams</h3></a>
 </div>
 
</div>
</div>

<div class="col-md-4 p-0">
<div class="card card-img ">
<div class="card-top-color bgcred">
<a href="<?php echo base_url('welcome/categorypage/personality-development');?>"><i class="fa fa-graduation-cap" aria-hidden="true"></i>
<h3>Personality Development</h3></a>
  </div>

</div>
</div>



</div>
</div>
</section>



<!-- start courses section-->
<section class="bgcclr111 py-5">
<div class="container">
<div class="row">
<div class="col-lg-12 testomnal testomnal22 ">

<h2 class="text-center coursehead">Courses</h2>
<div class="em-bar"></div>
</div>

</div>
<div class="row mt-5 ">


<?php foreach($SELECTCOURSES as $data) 
{  ?>




<div class="col-lg-4 coursesheight">
<div class="col-lg-12 p-0">
<div class="course-img" style="background-image:url(<?php echo base_url();?>assets/services/<?php echo $data->image; ?>)">
<div class="course-clr">
<h5><a href="<?php echo $data->url;?>"><?php echo $data->name; ?></a></h5>
<p><?php echo word_limiter($data->description,8); ?></p>
</div>
</div>
</div>
<div class="col-lg-12">
<div class="row p-0">
<div class="col-lg-9  p-0">
<div class="duration">
<p><b>Duration : <?php echo $data->duration; ?></b></p>
</div>
</div>
<div class="col-lg-3  p-0 ">
<div class="vicon">
<a href="<?php echo $data->url;?>"><i class="fa fa-play" aria-hidden="true"></i></a>
</div>
 </div>
</div>
</div>
</div>


<?php } ?>
</div>
</div>
</section>
<!-- end courses section-->






<section class="offerback " style="background-image:url(<?php echo base_url();?>media/images/business.jpg) ">
    <div class="overlay py-5">
        <div class="container">
        <div class="row">
        <div class="col-md-12">
       <h2 class="text-white h1 text-center" style="font-size:50px;"> SPECIAL OFFER </h2>
    
    <p class="text-center h1 mt-4 text-white" >   
Get 30% Discount On  'Absolute English' Course</p>
        
        </div>
        </div>
        
        </div>
    </div>
</section>

<!-- start about section -->


<section class="py-4">
<div class="container">
<div class="row">
<div class="col-lg-6 col-md-6 m-none about-img"> 

  <img class="img-fluid" src="<?php echo base_url();?>media/uploads/gallery/event4.jpg">

</div>

<div class="col-lg-6 col-12 col-sm-12 col-md-12 about-text"><h1>ABOUT US</h1><hr class="line-color">
<p class="text-justify"><?php echo word_limiter($ABOUTUSDETAILS[0]->description,90);?>
</p>

 <a href="<?= base_url('about-us'); ?>" class="btn btn-danger abread">Read More…</a>
</div>


</div>


					

</div>

</section>
<!-- end about section -->



<!-- start testimonial section -->



<section class="bgcclr" style="background-image:url(<?php echo base_url('media/images/testimonial/banner-1.jpg');?>); background-size:cover;     background-repeat: no-repeat;">
<div class="bgcrgba">
<div class="container">
<div class="row">
<div class="col-lg-4 pt-5 ">
<h2 class="text-right textiminia-heading" style="color:#fff;">"The people who made their career, candidature and life better by developing their potential at <span class="textiminia-text" style="text-transform:uppercase;"> <span style="color:#f00; ">Dushyant</span> World" </span></h2>


</div>
<div class="col-lg-8">
<div class="row">

<div id="demo" class="carousel slide" data-ride="carousel">


  <div class="carousel-inner">
<?php 
$i=1;
foreach ($SELECTTESTOMINAL as $testo) {
?>

    <div class="carousel-item <?= ($i==1)?"active":""; ?>">
     
	  
 <div class="col-lg-12 col-12">
<div class="col-lg-12 testowht">
<div class="text-center qut"><i class="fa fa-quote-left" aria-hidden="true"></i></div>
<p class="text-center"><?php echo word_limiter($testo->discription,60);?></p>
</div>
<div class="col-lg-12 picture">
<img src="<?php echo base_url();?>assets/testimonial/<?php echo $testo->image; ?>" class="img-fluid"> 
<h5 class="mt-10 text-white"><?php echo $testo->name; ?></h5>
<p class="text-white"><strong> ( <?php echo $testo->cname?> ) </strong> </p>
 </div>
</div>		  
	  
    </div>

<?php $i++;} ?>



  </div>

  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>

  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>

</div>
</div>
</div>
</div>
</div>
</div>

</section>







<!-- end testimonial section --->




<!-- start  gallery -->
<section class="greyback padd50 ">
<div class="container">
<div class="row whiteback package"> 
<div class="col-lg-12 testomnal testomnal22 ">

<h2 class="text-center">OUR GALLERY</h2>
<div class="em-bar"></div>
</div> 
<div class="col-md-12 pad10" style=" border-right: 1px solid #e4e4e4;">
<div class="Inclusions_pkg">

         

   
<div class="home galleryimg">

  <div class="demo-gallery">
      <ul id="lightgallery" class="list-unstyled row">

<?php foreach ($ALLGALLERY as $gallery) { ?>

          <li class="col-md-3 col-xs-6 galleryimg" data-src="<?= base_url('media/uploads/gallery').'/'.$gallery->image; ?>">
              <a href="">
                  <img class="img-fluid" src="<?= base_url('media/uploads/gallery').'/'.$gallery->image; ?>">
              </a>
              
          </li>

<?php  }  ?>

      </ul>
  </div>


</div>

     

 
 
 

</div>
</div>
</div>
</div>
</section>

<!-- end gallry -->
<!---------------------------- start counter -------------------------->

<!---------------------------- End counter -------------------------->

<!---------------------------------------------  foam    ---------------------------------------------->





<?php $this->load->view('include/footer');?>




<script type="text/javascript">
 
        $(document).ready(function(){
            $('#lightgallery').lightGallery();
        });
        //Light Gallary    



$('#lightgallery li').click(function(){ 

  

})



</script>











<script>
	$(document).ready(function () {
$('.dmenu').hover(function () {
        $(this).find('.sm-menu').slideDown(150);
    }, function () {
        $(this).find('.sm-menu').slideUp(105)
    });
});

$(window).scroll(function(){
    if ($(window).scrollTop() >= 300) {
        $('.menu').addClass('fixed-header');
    }
    else {
        $('.menu').removeClass('fixed-header');
    }
});

</script>








