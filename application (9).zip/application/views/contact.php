<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 <?php $this->load->view('include/css.php');?>
</head> 

<body>

<?php $this->load->view('include/header');?>

<!--------------------------------------------------- contact-head -------------------------->

<section style="background-image:url(<?php echo base_url(); ?>assets/services/bg3.jpg);" class="bgheadpic">
<div class="headclr">
    <div class="bgclr">
<div class="container">
<div class="row">
<div class="col-md-12">

<h1 class="text-center text-white h3 mb-0">CONTACT US</h1> 

</div>
</div>
</div>
</div>
</div>
</section>

<!--------------------------------------------------- Have Questions? Get in Touch -------------------------->
<section class="contact-question"> 
<div class="container"> 
<div class="row">
<div class="col-md-12 text-center my-4"><h1 class="fntsz">Have Questions? Get in Touch</h1>

</div>
<div class="col-md-5 contact-box">




<div class="loctio-border">

<div class="location-icon text-center">
<div class="inner-location-icon">
<i class="fa fa-map-marker" aria-hidden="true"></i></div></div>
<div class="location-text"><h4>Office</h4><p>141, RG Mall Sector 9, Delhi, Near Rohini West Metro Station</p></div>
</div>



<div class="loctio-border">
<div class="location-icon text-center">
<div class="inner-location-icon">
<i class="fa fa-phone" aria-hidden="true"></i></div></div>
<div class="location-text"><h4>‭8826552277</h4><p>Let's Talk</p></div>
</div>

<div class="location-icon text-center">
<div class="inner-location-icon">
<i class="fa fa-envelope" aria-hidden="true"></i></div></div>
<div class="location-text"><h4>dushyantworldonline@gmail.com </h4><p>Drop a Line</p></div>

</div>


<div class="col-md-7 mrgcntct">
   
<form method="post" enctype="multipart/form-data">
  <div class="form-group">

    <input name="name" class="form-control" type="text" required="" placeholder="Enter Name" aria-required="true">
	
	
  </div>
  

  <div class="form-group">
   <input name="email" class="form-control" type="text" required="" placeholder="Enter Email" aria-required="true">

  </div>

  <div class="form-group">
   <input name="phone" class="form-control" type="text" required="" placeholder="Enter Phone" aria-required="true">


  </div> 
  <div class="form-group">
  <select id="person_select" name="course" class="form-control" required="" aria-required="true">
                          <option value="">Choose Courses</option>
						   <?php foreach($SHOWMENU as $data)
            		   {
            		   ?>
                          <option value="<?php echo $data->name; ?>"><?php echo $data->name; ?></option>
					   <?php } ?>
                         
                        </select>
  <?php echo form_error('country');?>
 
  </div>

 
  <div class="form-group">
    <textarea class="form-control" id="exampleFormControlTextarea1" placeholder="Your Massage..." rows="5" name="message"  value="<?php echo set_value('message');?>"></textarea>
	<?php echo form_error('message');?>
  </div>
  
  <button type="submit" name="submit" class="btn btn-primary massage-btn clrbtn">Send Your Message</button>
  
</form>
</div>
</div>
</div>
</section>




<!--------------------------------------------------- map -------------------------->
<section class="google-map" style="display:none;">
<div class="container-fluid">
<div class="row">

<?php foreach ($ADDRDATA as $address) { ?>

<div class="col-md-12 contact-maps">
    <?= $address->map; ?>
    </div>

<?php } ?>





</div></div>
</section>
<!--------------------------------------------------- foam footer -------------------------->


<?php $this->load->view('include/footer');?>