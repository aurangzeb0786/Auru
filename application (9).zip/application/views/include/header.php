<section class="top-header">
<div class="container">
<div class="row">
<div class="col-sm-12 col-lg-6 col-md-6  d-sm-none d-md-block">
<ul class="margicon">
<li><i class="fa fa-phone" aria-hidden="true"></i> +91-8826552277 , +91-8826552244</li>
</ul>
</div>

   

    
<div class="col-lg-6 col-6 d-none d-sm-none d-md-blockd-sm-none d-md-block">
<ul class="social">
<li><a href="#" target="_blank"><i class="fa fa-facebook mr-2" aria-hidden="true"></i></a></li>
<li><a href="#" target="_blank"><i class="fa fa-twitter mr-2" aria-hidden="true"></i></a></li>

<li><a href="#" target="_blank"><i class="fa fa-instagram mr-2" aria-hidden="true"></i></a></li>
<li><a href="#" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
</ul>
</div>

</div>
</div>
</section>



<section class="menusecound">
<div class="container">
<div class="row">
<div class="col-lg-3 col-md-12">
<div class="col-lg-12 paddmq">
 <a class="navbar-brand" href="<?= base_url(); ?>">
    <img src ="<?= base_url(); ?>assets/logo/<?= $SITEDATA[0]->logo; ?>" class="img-fluid logohead">
  </a>
  
</div>
</div>

<div class="col-lg-9 paddsecound d-none d-sm-none d-md-none d-lg-block">
<div class="row">
<div class="col-lg-4 secoundbrdr">
<i class="fa fa-clock-o" aria-hidden="true"></i>
<h5>Enquiry Timing</h5>
<p style="margin: 0 0 5px 40px;">Mon-Sat:10:00 AM To 7:30 PM</p>
<h5 style="font-size:15px; font-weight:bold">Batch Timings</h5>
<p>Mon-Sat:9:00 AM To 9:00 PM</p>
</div>
<div class="col-lg-4 secoundbrdr1">
<i class="fa fa-envelope-o" aria-hidden="true"></i>
<h5>Mail</h5>
<p style="margin:0">info@dushyantworld.com</p>
<p>dushyantworldonline@gmail.com</p>

</div>
<div class="col-lg-4 ">
<i class="fa fa-map-marker" aria-hidden="true"></i>
<h5>Reach Us at </h5>
<p> 141, 1st Floor, RG Mall, Sector-9, Rohini, Delhi-110085</p>
</div>
</div>
</div>

</div>
</div>
</section>
<section class="thirdbrdr dmenu">
<div class="container">
<div class="row">
    
    
    <nav class="navbar navbar-expand-lg navbar-dark col-lg-8 col-12 paddmq">

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

	<button type="button" class="btn btn-danger d-block d-sm-none d-md-none d-lg-none"><i class="fa fa-phone" aria-hidden="true"></i>+91-8826552277</button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="<?= base_url(); ?>">Home</a>
      </li>
      

      <li class="nav-item dropdown dmenu">
        <a class="nav-link" href="<?= base_url('about-us'); ?>">  
         About Us
        </a>
       
      </li>
      
      
      
      
    
    
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Courses
        </a>
        <div class="dropdown-menu mega-menu-onerow" aria-labelledby="navbarDropdown">
            <div class="row">
            
            	<div class="col-md-12 megamenuhead">
            		
            		<ul>
            		   <?php foreach($SHOWMENU as $data)
            		   {
            		   ?>
            		<li><a href="<?php echo base_url($data->url);?>"><?php echo $data->name; ?></a></li>
    	<?php } ?>
		           
				   <li class="vcourse"><a href="<?php echo base_url('welcome/allcourses');?>">View All Courses</a></li>
		
		
					</ul>
				
            	</div>
            
            	
            </div> 
        </div>
      </li>
	  
	  <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('welcome/gallery');?>">Gallery</a>
      </li>
	  
	  
	
	  <li class="nav-item">
        <a class="nav-link" href="<?= base_url('immigration') ?>">Blog</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="<?= base_url('contact-us'); ?>">Contact</a>
      </li>

	  
    
    </ul>
  </div>


</nav>
    
 <div class="col-lg-4 col-5 btnsecound mpaddzero d-none d-sm-block">
	<a href="<?php echo base_url('welcome/index/#callback');?>"><button type="button" class="btn btn-danger" >Request for Free Trial Classes</button></a>
 </div>

<!-- Black with white text -->


</div>
</div>
</section>


  
  