


<div class="col-md-4 px-5 mb-4"> 
<div class="row">
<div class="col-md-12 contryform">
<div class=" bod">
<div class="side-head mrgn">
<h3>Request CallBack</h3>
</div>

<form method="post" enctype="multipart/form-data" class="frmp" action="<?php echo base_url('welcome/sidebar');?> ">
  <div class="form-group">

    <input name="name" class="form-control" type="text" required="" placeholder="Enter Name" aria-required="true">
	
	
  </div>
   <div class="form-group">
   <input name="phone" class="form-control" type="text" required="" placeholder="Enter Mobile No" aria-required="true">


  </div> 

  <div class="form-group">
   <input name="email" class="form-control" type="text" required="" placeholder="Enter Email" aria-required="true">

  </div>

 
  <div class="form-group">
  <select id="person_select" name="course" class="form-control" required="" aria-required="true">
                          <option value="">Choose Courses</option>
						   <?php foreach($SHOWMENU as $data)
            		   {
            		   ?>
                          <option value="<?php echo $data->name; ?>"><?php echo $data->name; ?></option>
					   <?php } ?>
                         
                        </select>
  <?php echo form_error('country');?>
 
  </div>

  <div class="form-group">
    <textarea class="form-control" id="exampleFormControlTextarea1" placeholder="Your Massage..." rows="5" name="message"  value="<?php echo set_value('message');?>"></textarea>
	<?php echo form_error('message');?>
  </div>
  
  <button type="submit" name="submit" class="btn btn-primary massage-btn clrbtn">Send Your Message</button>
  
</form>
</div>
</div>
</div>

<div class="row">
<div class="col-md-12 bod ">

<div class="side-head">
<h3>Courses</h3>
</div>


<ul class="sidelist">
    <?php foreach($SERVIC as $service)
    {?>
  <li>
    <a href="<?php echo base_url($service->url);?>"><?php echo $service->name;?></a>
  </li>

 <?php } ?>
</ul>















<div class="side-head">
<h3>TESTIMONIAL</h3>
</div>





<div id="demo" class="carousel slide" data-ride="carousel">


  <div class="carousel-inner">
<?php 
$i=1;
foreach ($SELECTTESTOMINAL as $testo) {
?>

    <div class="carousel-item <?= ($i==1)?"active":""; ?>">
     
	  
 <div class="col-lg-12 col-12">
<div class="col-lg-12 testowht">
<div class="text-center qut"><i class="fa fa-quote-left" aria-hidden="true"></i></div>
<p class="text-center" style="color:#000;"><?php echo word_limiter($testo->discription,60);?></p>
</div>
<div class="col-lg-12 picture">
<img src="<?php echo base_url();?>assets/testimonial/<?php echo $testo->image; ?>" class="img-fluid"> 
<h5 class="mt-10"><?php echo $testo->name; ?></h5>
<p><strong> ( <?php echo $testo->cname?> ) </strong> </p>
 </div>
</div>		  
	  
    </div>

<?php $i++;} ?>



  </div>

  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>

  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>

</div>




</div>
</div>


</div>




