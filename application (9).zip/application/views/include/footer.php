

<section class="bgccontact" id="callback">
<div class="container">
<div class="row">
<div class="col-lg-12 footercontact">
<p class="text-center"><i class="fa fa-mobile" aria-hidden="true"></i>  Request For Free Trial Classes : +91-8826552244 , +91-8826552277</p>



</div>
<div class="col-lg-6 d-none">
<div class="row">
<div class="col-lg-8 p-0  conctftr">
<input type="text" value="" name="EMAIL" placeholder="Your Mobile Number" class="form-control input-lg font-16" data-height="45px" id="mce-EMAIL-footer" style="height: 45px;">
</div>
<div class="col-lg-4 p-0 conctftr">
<button data-height="45px" class="btn bg-theme-colored text-white btn-xs m-0 font-14" type="submit" style="height: 45px; background-color:#202C45;">Submit</button>
</div>
</div>
</div>
</div>
</div>
</section>
<!---------------------------------------------  top-footer    ---------------------------------------------->
<section class="bottom-footer-bg py-5">  
<div class="container"> 
<div class="row">
<div class="col-md-12 bottom-footer-head">
<div class="row">


<div class="col-md-3">
<h5>Our Location</h5> 
<ul>


<li><p> 141, 1st Floor, RG Mall, Sector-9, Rohini, Delhi-110085</p></li> 



</ul>
</div>


<div class="col-md-3">
<h5>Contact Details</h5>
<ul>
<li><h6> Office :</h6> <p><a href="tel:-8826552244">‭+91-8826552244
</a></p></li>
<li><h6> office :</h6> <p><a href="tel:-8826552277">‭+91-8826552277</a></p></li>
<li><p><a href="mailto: info@dushyantworld.com">Email: info@dushyantworld.com</a><br/>
<a href="mailto: dushyantworldonline@gmail.com">dushyantworldonline@gmail.com</a></p></li>

</ul>
</div>


<div class="col-md-3">
<h5>Our Courses</h5>
<ul>
            		   <?php foreach($SHOWMENU as $data)
            		   {
            		   ?>
            		<li><a href="<?php echo base_url($data->url);?>"><?php echo $data->name; ?></a></li>
    	<?php } ?>
					</ul>
</div>

<div class="col-md-3">
<h5>Useful Links</h5>
<ul>


<li><a href="<?= base_url('about-us'); ?>">About Us</a></li>
<li><a href="<?php echo base_url('blog');?>">Blog</a></li>
<li><a href="<?php echo base_url('welcome/gallery'); ?>">Gallery</a></li>
<li><a href="<?= base_url('contact-us'); ?>">Contact Us</a></li>
</ul>
</div>




</div>
</div>

</div>
</div>
</section>
<!---------------------------------------------  bottom-footer    ---------------------------------------------->

<section class="footer-bg">
<div class="container">
<div class="row">
<div class="col-md-6 top-footer-head">
<p>All right Reserved © 2020  Dushyant World</p>
</div>

<div class="col-md-6 top-footer-heads">
<p>Design and Developed by <a href="https://www.nextgeducation.com" target="_blank">Next-G</a> and <a href="https://web-services.co.in" target="_blank">Web Services</a></p>
</div>

</div>
</div>
</section>


<section class="bgcclrftr d-block d-sm-none" >
<div class="container">
<div class="row">

<div class="col-3">
<div class="brdrphn">
<a href="tel:8826552277"><i class="fa fa-phone " aria-hidden="true"></i></a>
</div>
</div>
<div class="col-6 btnclrful">

<button type="button" class="btn btn-info" data-toggle="modal" data-target="#loadModal" id="">Free Counselling</button>
</div>
<div class="col-3">
<div class="brdrphn1">
<a href="https://wa.me/918826552277?text= " onclick="gtag('event', 'WhatsApp', {'event_action': 'whatsapp_chat', 'event_category': 'Chat', 'event_label': 'Chat_WhatsApp'});"><i class="fa fa-whatsapp" aria-hidden="true"></i></a>

</div>
</div>

</div>
</div>
</section>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
 <script src="<?php echo base_url('media/js/lightgallery-all.js');?>"></script>
 <script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

<!--<script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>-->


      
      <script>
$(window).scroll(function(){
    if ($(window).scrollTop() >= 300) {
        $('.menu').addClass('fixed-header');
    }
    else {
        $('.menu').removeClass('fixed-header');
    }
});

</script>
      
      <script>
      $(document).ready(function() {
 // executes when HTML-Document is loaded and DOM is ready

// breakpoint and up  
$(window).resize(function(){
	if ($(window).width() >= 980){	

      // when you hover a toggle show its dropdown menu
      $(".navbar .dropdown-toggle").hover(function () {
         $(this).parent().toggleClass("show");
         $(this).parent().find(".dropdown-menu").toggleClass("show"); 
       });

        // hide the menu when the mouse leaves the dropdown
      $( ".navbar .dropdown-menu" ).mouseleave(function() {
        $(this).removeClass("show");  
      });
  
		// do something here
	}	
});  
  
  

// document ready  
});
      </script>
	  
	  <script>
$(".testominal").slick({
		    slidesToShow:1,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 2000,
        infinite: true,
	responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 600,
      settings: {
              arrows: false,
        slidesToShow: 1,
        slidesToScroll: 1
      }
    },
    {
      breakpoint: 480,
      settings: {
              arrows: false,
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]     
      });
      
      
      
    
     
</script>
      
      
      
      
</body>
</html>