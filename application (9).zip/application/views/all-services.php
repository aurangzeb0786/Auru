<!doctype html>
<html lang="en">
  <head>
       <title><?php echo $SEODATA[0]->seotitle; ?></title>
      <meta name="description" content="<?php echo $SEODATA[0]->seodescription; ?>" />
    <meta name="keywords" content="<?php echo $SEODATA[0]->keyword; ?>" />
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 <?php $this->load->view('include/css.php');?>
</head>

<body>

<?php $this->load->view('include/header');?>
<!---------------------------------------------        Start services          --------------------------------->
<section class="bgcclr111">
<div class="container">
<div class="row">
<div class="col-lg-12 testomnal">
<p class="text-center">OUR SERVICE</p>
<h2 class="text-center">Services We Provide</h2>
<div class="em-bar"></div>
</div>

<?php foreach($SELECTSERVICE as $data) 
{  ?>
<div class="col-lg-4 serve">
                
<img src="<?php echo base_url();?>assets/services/<?php echo $data->image; ?>">
<div class="col-lg-12 serves2">
<div class="serves">
<h4><a href="<?php echo base_url('welcome/servicedetails/').$data->url;?>"><?php echo $data->name; ?></a></h4>
<p><?php echo $data->description; ?></p>
</div>
</div>
</div>

<?php  }  ?>





</div>
</div>
</section>


<?php $this->load->view('include/footer');?>


<script>
	$(document).ready(function () {
$('.dmenu').hover(function () {
        $(this).find('.sm-menu').slideDown(150);
    }, function () {
        $(this).find('.sm-menu').slideUp(105)
    });
});

$(window).scroll(function(){
    if ($(window).scrollTop() >= 300) {
        $('.menu').addClass('fixed-header');
    }
    else {
        $('.menu').removeClass('fixed-header');
    }
});

</script>