<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <title>Gallery</title>
    <meta name="description" content="">
  <meta name="keywords" content="">
 <?php $this->load->view('include/css.php');?>
</head>



<body>

<?php $this->load->view('include/header');?>
<!--------------------------------------------------- country-head -------------------------->

<section  style="background-image:url(<?php echo base_url(); ?>assets/services/bg3.jpg); " class="bgheadpic">
<div class="headclr">
<div class="container">
<div class="row">
<div class="col-md-12">

<h1 class="text-center text-white h3 mb-0">GALLERY</h1> 

</div>
</div>
</div>
</div>
</section>
<!--------------------------------------------------- Australia Visitor Visa -------------------------->


<section class="pt-4">
<div class="container">
<div class="row">



<div class="col-md-12 pad10" style=" border-right: 1px solid #e4e4e4;">
<div class="Inclusions_pkg">

         

   
<div class="home galleryimg">

  <div class="demo-gallery">
      <ul id="lightgallery" class="list-unstyled row">

<?php foreach ($ALLGALLERY as $gallery) { ?>

          <li class="col-md-3 col-xs-6 galleryimg" data-src="<?= base_url('media/uploads/gallery').'/'.$gallery->image; ?>">
              <a href="">
                  <img class="img-fluid" src="<?= base_url('media/uploads/gallery').'/'.$gallery->image; ?>">
              </a>
              
          </li>

<?php  }  ?>

      </ul>
  </div>


</div>

     

 
 
 

</div>
</div>


</div>
</div>
</section>



<?php $this->load->view('include/footer');?>

