<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <title><?php echo $SEODATA[0]->seotitle;?></title>
    <meta name="description" content="<?php echo $SEODATA[0]->seodescription;?>">
  <meta name="keywords" content="<?php echo $SEODATA[0]->keyword;?>">
 <?php $this->load->view('include/css.php');?>
</head>

<style type="text/css">
  span{
    color: #F96921;
  }
</style>

<body>

<?php $this->load->view('include/header');?>
<!--------------------------------------------------- country-head -------------------------->

<section  style="background-image:url(<?php echo base_url(); ?>assets/services/bg3.jpg); " class="bgheadpic">
<div class="headclr">
<div class="container">
<div class="row">
<div class="col-md-12">

<h1 class="text-center text-white h3 mb-0"><?php echo $DETAILSPAGES[0]->heading;?></h1> 

</div>
</div>
</div>
</div>
</section>
<!--------------------------------------------------- Australia Visitor Visa -------------------------->


<section class="pt-4">
<div class="container">
<div class="row">



<div class="col-md-12">
<div class="row"> 

<div class="col-md-12 immigration-new-style py-4 px-4 service">
<?php echo $DETAILSPAGES[0]->description;?>
</div>

</div>
</div>


</div>
</div>
</section>



<?php $this->load->view('include/footer');?>

